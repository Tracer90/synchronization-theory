"""
live.py — IAC: Invariant Adaptive Core
Self-Consistent Engine с Field Interface, Negative Intelligence, Translation
Скилы в skills/ — динамическая загрузка (99 инструментов)
"""

import json, os, re, time, subprocess, platform, urllib.request
from datetime import datetime
from pathlib import Path
from typing import Tuple, List, Dict, Optional, Any

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False
import mycelium
import skills
from skills.sync import SyncError
from skills.anticipation import tool_predict_sync, tool_validate_prediction

# --- IAC Plugin System ---
_FIELD_AVAIL = "field_scan" in skills.REGISTRY
_NEGATIVE_AVAIL = "negative_attack" in skills.REGISTRY
_TRANSLATE_AVAIL = "translate" in skills.REGISTRY
_LOCALE_AVAIL = "locale_t" in skills.REGISTRY
_MODS_AVAIL = "mods_preset" in skills.REGISTRY
_CLASSIFIER_AVAIL = "structure_classify" in skills.REGISTRY
_AUTO_VERIFY_AVAIL = "auto_verify_and_promote" in skills.REGISTRY
_SOMATIC_AVAIL = "somatic_detect" in skills.REGISTRY
_OBSERVER_AVAIL = "observer_lens" in skills.REGISTRY

# --- КОНФИГ ---
MODEL = "qwen2.5-coder:7b"
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "localhost")
OLLAMA_GEN = f"http://{OLLAMA_HOST}:11434/api/generate"
MEMORY = Path("MEMORY.md")
STATE_FILE = Path("state.json")
SLEEP = 1800  # default 30min, adaptive sleep adjusts per cycle

# --- GUARD (observe → authorize → apply) ---
_PROJECT_ROOT = Path(__file__).resolve().parent

READ_TOOLS = {"read", "list", "grep", "syntax", "lint", "plan", "stats",
              "mode", "reload", "auto_learn"}

WRITE_TOOLS = {"write", "edit", "backup", "rollback",
               "sync_fact", "sync_learn", "sync_forget",
               "memory_compress", "promote_invariants"}

EXTERNAL_TOOLS = {"search", "fetch", "emails", "send", "calendar", "calendar_add"}

BLOCKED_PATHS = {
    ".env", ".git", "archive", "backups", "data", "logs",
    "MEMORY.md", "LIVE_LOG.md", "research", "VAULT",
    "sync_patterns.json", "sync_predictions.jsonl",
    "meta_sync.jsonl", "metrics_log.jsonl",
    "architectural_invariants.json", "state.json",
}

_MODE_FLAGS = {"write": False, "llm": False, "loop": False}

def _normalize_path(path_str: str) -> Path:
    return Path(path_str.replace("\\", "/")).resolve()

def observe(path_str: str = "", tool_name: str = "") -> dict:
    result = {"safe": True, "risk": []}
    if path_str and tool_name in WRITE_TOOLS:
        norm = _normalize_path(path_str)
        try:
            _PROJECT_ROOT.relative_to(norm)
            result["risk"].append("path outside project root")
            result["safe"] = False
            return result
        except ValueError:
            pass
        try:
            rel = str(norm.relative_to(_PROJECT_ROOT))
        except ValueError:
            result["risk"].append("path outside project root")
            result["safe"] = False
            return result
        for blocked in BLOCKED_PATHS:
            parts = rel.replace("\\", "/").split("/")
            if blocked in parts:
                result["risk"].append(f"blocked path: {blocked}")
                result["safe"] = False
                break
        if ".." in path_str:
            result["risk"].append("path traversal")
            result["safe"] = False
        result["normalized"] = str(norm)
    return result

def authorize(tool_name: str, path_str: str = "") -> tuple:
    if tool_name in WRITE_TOOLS:
        if not _MODE_FLAGS["write"]:
            return False, f"write blocked (use --write)"
        obs = observe(path_str, tool_name)
        if not obs["safe"]:
            return False, f"unsafe path: {obs['risk']}"
        return True, ""
    if tool_name in EXTERNAL_TOOLS or tool_name.startswith("mm_"):
        if not _MODE_FLAGS["llm"]:
            return False, f"external/network blocked (use --llm)"
        return True, ""
    return True, ""

# --- ПРОБА ЖЕЛЕЗА ---
def probe_str() -> str:
    lines = [f"OS: {platform.system()} {platform.release()}"]
    if _HAS_PSUTIL:
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage(".")
        lines.append(f"CPU: {psutil.cpu_count(logical=True)} cores")
        lines.append(f"RAM: {mem.total//(1024**3)}GB total, {mem.available//(1024**3)}GB free ({mem.percent}% used)")
        lines.append(f"Disk: {disk.free//(1024**3)}GB free")
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.free", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5)
            if out.returncode == 0:
                parts = out.stdout.strip().split(", ")
                lines.append(f"GPU: {parts[0]}, VRAM free: {parts[1]}MB")
        except:
            pass
    else:
        lines.append("psutil unavailable — phone mode")
    try:
        lines.append(f"Host: {platform.node()}")
    except:
        pass
    return "\n".join(lines)

# --- API ---
def ask(prompt: str) -> str:
    if not _MODE_FLAGS["llm"]:
        return ""
    for _ in range(2):
        data = json.dumps({"model": MODEL, "prompt": prompt, "stream": False}).encode()
        try:
            resp = urllib.request.urlopen(urllib.request.Request(OLLAMA_GEN, data=data,
                headers={"Content-Type": "application/json"}), timeout=120)
            text = json.loads(resp.read().decode()).get("response", "")
            text = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', text).strip()
            if text: return text
        except: time.sleep(2)
    return ""

# --- ИНСТРУМЕНТЫ ---
TOOLS = {}
_BASE_TOOLS = {}

def tool_reload():
    """Reload skills/ to pick up new skill files"""
    import importlib
    importlib.reload(skills)
    TOOLS.clear()
    TOOLS.update(skills.REGISTRY)
    TOOLS.update(_BASE_TOOLS)
    return f"Skills loaded: {sorted(skills.REGISTRY.keys())}"

def tool_read(path: str):
    p = Path(path)
    return p.read_text(encoding="utf-8") if p.exists() else "Not found."
def tool_write(path: str, content: str):
    Path(path).write_text(content, encoding="utf-8")
    return f"Written to {path}"
def tool_list(path: str = "."):
    try:
        files = [str(p) for p in Path(path).iterdir() if p.is_file() and not str(p).startswith(".")]
        return "\n".join(files[:30]) or "Empty."
    except Exception as e: return f"Error: {e}"
def tool_mode(mode: str = ""):
    mode = mode.strip().lower()
    if mode in ("free", "tool"):
        _MODE[0] = mode
        return f"Режим: {mode}"
    return f"Текущий режим: {_MODE[0]}. !mode free|tool"

def tool_grep(pattern: str, path: str = "."):
    try:
        out = subprocess.run(["rg", "-n", pattern, path], capture_output=True, text=True, timeout=10)
        return out.stdout[:2000] or "Not found."
    except: return "grep unavailable."

def tool_auto_learn(state: str = "") -> str:
    """Toggle auto-learn: !auto_learn on|off. Shows current state if no arg."""
    s = state.strip().lower()
    if s == "on":
        _AUTO_LEARN[0] = True
    elif s == "off":
        _AUTO_LEARN[0] = False
    return f"auto_learn={'on' if _AUTO_LEARN[0] else 'off'}"

def tool_plan() -> str:
    """Suggest optimal next action based on system state analysis."""
    lines = ["=== System Plan ==="]
    lines.append(f"Cycle #{CYCLE_N[0]} | mode={_MODE[0]}")

    # Sync trend
    avg_se = 0.5
    if _SYNC_SCORES:
        scores = [s[1] for s in _SYNC_SCORES[-10:]]
        avg_se = sum(scores) / len(scores)
        trend = "improving" if len(scores) > 2 and scores[-1] < scores[0] - 0.05 else \
                "degrading" if len(scores) > 2 and scores[-1] > scores[0] + 0.05 else "stable"
        lines.append(f"Sync: avg {avg_se:.2f} ({SyncError.interpret(avg_se)}), {trend}")
    else:
        lines.append("Sync: no data")

    # Action track
    best_cmd, worst_cmd = "search", "code"
    if _ACTION_TRACK:
        sorted_act = sorted(_ACTION_TRACK.items(), key=lambda x: x[1]["avg_se"])
        best = sorted_act[0]
        worst = sorted_act[-1]
        best_cmd, worst_cmd = best[0], worst[0]
        lines.append(f"Best: {best_cmd} (SE {best[1]['avg_se']:.2f}, {best[1]['count']}x)")
        lines.append(f"Worst: {worst_cmd} (SE {worst[1]['avg_se']:.2f}, {worst[1]['count']}x)")

    # Memory
    try:
        m_size = MEMORY.stat().st_size if MEMORY.exists() else 0
        m_entries = sum(1 for l in MEMORY.read_text(encoding="utf-8").split("\n") if l.startswith("- [")) if MEMORY.exists() else 0
        lines.append(f"Memory: {m_entries} entries, {m_size // 1024}KB")
    except:
        lines.append("Memory: ?")

    # Patterns
    try:
        import json
        pf = Path("sync_patterns.json")
        pats = json.loads(pf.read_text(encoding="utf-8")) if pf.exists() else []
        xd = sum(1 for p in pats if p.get("domain"))
        lines.append(f"Patterns: {len(pats)} total ({xd} with domain)")
    except:
        lines.append("Patterns: ?")

    # Suggestion
    if not _SYNC_SCORES:
        suggestion = "!search - gather initial data. Or !sync_status to check baseline."
    elif avg_se > 0.4 and _ACTION_TRACK:
        suggestion = f"!{worst_cmd} - high SE, investigate. Or !{best_cmd} to restore low SE."
    else:
        suggestion = f"!{best_cmd} - historically reliable. Or !patterns --invariants to review learned patterns."
    lines.insert(1, "Suggestion: " + suggestion)

    return "\n".join(lines)


def tool_stats() -> str:
    """Show detailed system statistics."""
    lines = ["=== System Stats ==="]
    lines.append(f"Cycle #{CYCLE_N[0]} | mode={_MODE[0]} | auto_learn={'on' if _AUTO_LEARN[0] else 'off'}")

    # Sync history
    if _SYNC_SCORES:
        scores = [s[1] for s in _SYNC_SCORES]
        lines.append(f"\nSync ({len(scores)} entries): {_sync_trend_str()}")
        recent = scores[-10:]
        spark = " ".join(
            " _" if s < 0.1 else ".-" if s < 0.3 else "-o" if s < 0.5 else "oO" if s < 0.7 else "O#"
            for s in recent
        )
        lines.append(f"  Recent: {spark}  ({', '.join(f'{s:.2f}' for s in recent[-5:])})")
    else:
        lines.append("\nSync: no data")

    # All actions
    if _ACTION_TRACK:
        lines.append("\nActions:")
        sorted_act = sorted(_ACTION_TRACK.items(), key=lambda x: x[1]["avg_se"])
        for name, data in sorted_act:
            bar = "#" * max(1, int(data["avg_se"] * 10))
            lines.append(f"  {name:15s} SE {data['avg_se']:.2f} [{bar:<10}] {data['count']}x")

    # Patterns
    try:
        import json
        pf = Path("sync_patterns.json")
        pats = json.loads(pf.read_text(encoding="utf-8")) if pf.exists() else []
        if pats:
            by_domain = {}
            for p in pats:
                d = p.get("domain") or "(no domain)"
                if d not in by_domain:
                    by_domain[d] = []
                by_domain[d].append(p)
            lines.append(f"\nPatterns: {len(pats)} total")
            for d, ps in sorted(by_domain.items()):
                xd = " [XD]" if any(p.get("domain") for p in ps) and d != "(no domain)" else ""
                lines.append(f"  {d}: {len(ps)}{xd}")
    except:
        lines.append("\nPatterns: ?")

    return "\n".join(lines)


_BASE_TOOLS.update({"read": tool_read, "write": tool_write, "list": tool_list, "grep": tool_grep, "reload": tool_reload, "mode": tool_mode, "auto_learn": tool_auto_learn, "plan": tool_plan, "stats": tool_stats})
TOOLS.update(_BASE_TOOLS)
TOOLS.update(skills.REGISTRY)

# --- ЯДРО СИНХРОНИЗАЦИИ (sync_delta) ---
_SYNC_SCORES = []  # (ts, score, delta, direction, action, result_preview, expected_preview)

def _calc_sync_score(result: str) -> float:
    try:
        data = json.loads(skills.REGISTRY["sync_score"](result))
        return data.get("score", 0.5)
    except Exception:
        return 0.5

def _compute_sync(expected: str, actual: str) -> tuple:
    """(score, delta, direction) — единое вычисление синхронизации"""
    score = _calc_sync_score(actual)
    if expected:
        try:
            data = json.loads(skills.REGISTRY["sync_delta"](expected, actual))
            return score, data["delta"], data["direction"]
        except:
            pass
    return score, score, ""

def _track_sync(action: str, result: str, score: float, expected: str = "", delta: float = 0.0, direction: str = ""):
    now = datetime.now().strftime('%H:%M')
    _SYNC_SCORES.append((now, score, delta, direction, action[:40], result[:60], expected[:30]))
    _SYNC_SCORES[:] = _SYNC_SCORES[-20:]
    _update_action_track(action, score, delta)

def _sync_trend_str() -> str:
    if not _SYNC_SCORES:
        return "no data"
    scores = [s[1] for s in _SYNC_SCORES[-5:]]
    deltas = [s[2] for s in _SYNC_SCORES[-5:]]
    avg_s = sum(scores)/len(scores)
    avg_d = sum(deltas)/len(deltas) if deltas else 0
    return f"avg SE {avg_s:.2f}, avg d {avg_d:.2f} ({SyncError.interpret(avg_s)})"

def _last_sync_detail() -> str:
    if not _SYNC_SCORES:
        return "no previous action data"
    ts, score, delta, direction, action, result, expected = _SYNC_SCORES[-1]
    d = f" ({direction})" if direction else ""
    return f"Last: {action} → SE {score:.2f} Δ {delta:.2f}{d}"

_ROLLBACK_LOCK = [0]  # cycle N when last rollback happened, prevent loops
_AUTO_LEARN = [True]  # auto-learn patterns from high-delta results
_ACTION_TRACK = {}  # {action_prefix: {"count": N, "avg_se": float, "avg_delta": float}}
_LAST_PREDICTED_SE = [0.5]  # Last predicted sync error from anticipation

def _update_action_track(action: str, se: float, delta: float):
    """Track per-action-type sync performance"""
    prefix = action.split()[0].lstrip("!") if action else "?"
    if prefix not in _ACTION_TRACK:
        _ACTION_TRACK[prefix] = {"count": 0, "avg_se": 0.0, "avg_delta": 0.0}
    s = _ACTION_TRACK[prefix]
    n = s["count"] + 1
    s["avg_se"] = round((s["avg_se"] * s["count"] + se) / n, 3)
    s["avg_delta"] = round((s["avg_delta"] * s["count"] + delta) / n, 3)
    s["count"] = n

def _best_actions_str(n: int = 3) -> str:
    """Return formatted best/worst actions by avg SE"""
    if not _ACTION_TRACK:
        return ""
    sorted_by_se = sorted(_ACTION_TRACK.items(), key=lambda x: x[1]["avg_se"])
    best = sorted_by_se[:n]
    worst = sorted_by_se[-n:][::-1]
    parts = []
    parts.append("best: " + ", ".join(f"{a} ({s['avg_se']:.2f})" for a, s in best))
    parts.append("worst: " + ", ".join(f"{a} ({s['avg_se']:.2f})" for a, s in worst if s["count"] > 0))
    return " | ".join(parts)

HELP = skills.HELP + "\nread|write|list|grep — files\nreload — rescan skills/\nmode — !mode free|tool\nrollback — restore latest backup\nauto_learn on|off — toggle pattern auto-learning\nplan — анализ и рекомендация\nstats — детальная статистика системы\nsync_score|sync_filter|sync_fact|sync_status|sync_delta|sync_wrap|sync_objective — sync engine\nsync_learn|sync_forget|sync_list_patterns — обучить эвристику\npatterns — просмотр паттернов с группировкой\npredict_sync|validate_prediction — anticipation engine\n--- IAC modules ---\nfield_scan|field_sensitivity|field_resonance|field_status|field_set_processing_mode|field_scan_classified — Field Interface\nnegative_attack|negative_check|negative_check_instruction — Negative Intelligence (6 типов)\ntranslate|translate_batch|translate_mapping — Translation Architecture\nlocale_lang|locale_t — Localization (ru/en)\nmods_preset|mods_stages|mods_theme|mods_rules — Mod Engine\nsde_falsify_cycle|sde_extract_invariants|sde_extract_patterns — SDE\nsde_diagrammatic_analyze|sde_diagrammatic_apply|sde_generate_sequences — Diagrammatic/Sequence\nstructure_classify|detect_markers|detect_rtl|detect_mechanical|build_graph|classify_and_graph — StructureClassifier\n--- Observer Lens (Module 9) ---\nobserver_lens|observer_consistency|observer_blindspots|observer_map|observer_self_assess|observer_recommend|observer_apply|observer_integrate|observer_status — Мета-наблюдатель\n--- Astronomy Module ---\nnumber_analyzer — Анализ астрономических циклов"

# --- ПАРСИНГ И ИСПОЛНЕНИЕ ---
PARSE_RE = re.compile(r'!(\w+)\s+(.+)')

def parse_tool(text: str):
    m = PARSE_RE.search(text)
    if m and m.group(1) in TOOLS:
        return m.group(1), m.group(2).strip()
    return None

_LAST_SYNC_WRAP = [None]  # last wrapped result from execute()

def _wrap_result(raw: str) -> dict:
    """Wrap raw result with sync metadata. Skills can return dicts to override."""
    if isinstance(raw, str) and raw.startswith("{"):
        try:
            data = json.loads(raw)
            if isinstance(data, dict) and "sync_delta" in data:
                return data  # skill already returned structured data
        except:
            pass
    try:
        return json.loads(skills.REGISTRY["sync_wrap"](raw))
    except:
        return {"result": raw, "sync_delta": 0.5}

def execute(cmd: str, args: str) -> str:
    if cmd not in TOOLS:
        return f"[blocked] unknown tool '{cmd}'"
    path = ""
    if cmd in WRITE_TOOLS:
        if "|" in args:
            path = args.split("|")[0].strip()
        elif cmd in ("backup", "rollback"):
            path = args.strip()
        else:
            path = args.split(" ")[0].strip()
    allowed, reason = authorize(cmd, path)
    if not allowed:
        return f"[blocked] {reason}"
    fn = TOOLS[cmd]
    try:
        if cmd in ("write", "edit") and "|" in args:
            parts = args.split("|", 2 if cmd == "edit" else 1)
            if cmd == "edit" and len(parts) >= 3:
                raw = fn(parts[0].strip(), parts[1].strip(), parts[2].strip())
            elif cmd == "write" and len(parts) >= 2:
                raw = fn(parts[0].strip(), parts[1].strip())
            else:
                raw = ""
        elif cmd in ("grep",):
            p = args.split(" ", 1)
            raw = fn(p[0], p[1] if len(p) > 1 else ".")
        elif cmd in ("backup", "syntax", "lint", "rollback"):
            raw = fn(args)
        else:
            try: raw = fn(int(args))
            except: raw = fn(args)
    except Exception as e:
        raw = f"[error] {e}"

    _LAST_SYNC_WRAP[0] = _wrap_result(raw)
    return raw

# --- АВТОСОХРАНЕНИЕ (sync-aware) ---
_LAST_SAVED = [""]
_PREDICTED = [""]
_LAST_REFLECTION = [""]
_CYCLE_SKIP_COUNT = [0]  # cycles skipped by auto_save filters

def _action_tag(action: str) -> str:
    """Derive memory tag from action string."""
    action = (action or "").lstrip("!")
    parts = action.split()
    prefix = parts[0].lower() if parts else ""
    mapping = {
        "search": "search", "fetch": "search",
        "code": "code", "edit": "code", "write": "code",
        "backup": "code", "syntax": "code", "lint": "code", "rollback": "code",
        "plan": "plan", "stats": "plan",
        "mode": "control", "auto_learn": "control",
        "sync": "sync", "memory": "sync", "patterns": "sync",
    }
    return next((v for k, v in mapping.items() if prefix == k or prefix.startswith(k + " ")), "")

def auto_save(action: str, result: str, sync_score: float = 0.5, tag: str = ""):
    if not result or len(result) < 20: return
    if result.startswith("[error"): return
    sig = result[:100]
    if sig == _LAST_SAVED[0]:
        return
    _LAST_SAVED[0] = sig
    try:
        skills.REGISTRY["sync_fact"](result, max(0.0, 1.0 - sync_score), tag)
    except Exception:
        ts = datetime.now().strftime('%d.%m %H:%M')
        note = f"\n- [{ts}] {result[:200].replace(chr(10),' ').strip()}"
        with open(MEMORY, "a", encoding="utf-8") as f:
            f.write(note)

def auto_save_cycle_trace(action: str, result: str, sync_score: float, mode: str):
    """Save compact cycle trace to MEMORY.md — one line per cycle, всегда сохраняется."""
    ts = datetime.now().strftime('%d.%m %H:%M')
    rlen = len(result) if result else 0
    action_short = (action or "?")[:40].replace(chr(10), ' ')
    trace = f"- [{ts}] [trace] #{CYCLE_N[0]} {mode} SE={sync_score:.2f} r={rlen} | {action_short}\n"
    with open(MEMORY, "a", encoding="utf-8") as f:
        f.write(trace)

def _save_state():
    """Persist cycle state to STATE_FILE for restart recovery"""
    try:
        data = {
            "cycle_n": CYCLE_N[0],
            "mode": _MODE[0],
            "history": _HISTORY[-50:],
            "sync_scores": [list(t) for t in _SYNC_SCORES[-50:]],
            "auto_learn": _AUTO_LEARN[0],
            "action_track": _ACTION_TRACK,
            "last_reflection": _LAST_REFLECTION[0],
            "updated": datetime.now().strftime('%Y-%m-%d %H:%M'),
        }
        STATE_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        mycelium.save_state()
    except:
        pass

def _load_state():
    """Restore cycle state from STATE_FILE"""
    if not STATE_FILE.exists():
        return
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        CYCLE_N[0] = data.get("cycle_n", 0)
        _MODE[0] = data.get("mode", "free")
        _HISTORY.extend(data.get("history", []))
        raw = data.get("sync_scores", [])
        _SYNC_SCORES.extend(tuple(r) for r in raw if isinstance(r, list) and len(r) >= 4)
        _AUTO_LEARN[0] = data.get("auto_learn", True)
        _LAST_REFLECTION[0] = data.get("last_reflection", "")
        at = data.get("action_track", {})
        _ACTION_TRACK.update(at)
        _SYNC_SCORES[:] = _SYNC_SCORES[-50:]
    except:
        pass

# --- ТРЕКЕР ДЕЙСТВИЙ + РЕЖИМ ---
_HISTORY = []
_MODE = ["free"]  # "free" | "tool"
_CURRENT_CLASSIFICATION = [None]  # classification result for current cycle
_PROCESSING_MODE = ["linear"]  # linear | reversed | topological (IAC-INV-019-023)
_MYCELIUM_FIELD = [{}]  # latest mycelium field state
_PHONE_AVAIL = ["phone_sense" in skills.REGISTRY]  # phone skill available
_SKIN_ENABLED = [os.environ.get("IAC_SKIN", "") == "1"]  # skin display enabled

# --- ЦИКЛ ---
CYCLE_N = [0]

def _classify_current_context(memory: str, history: list, recent_result: str = "") -> dict:
    """Classify the current cycle context using StructureClassifier (IAC-INV-019-023)."""
    if not _CLASSIFIER_AVAIL:
        return {"type": "narrative", "confidence": 0.3}

    # Build context text from recent activity
    parts = []
    if recent_result and len(recent_result) > 20:
        parts.append(recent_result[:500])
    if history:
        parts.append(" ".join(history[-3:]))
    if memory:
        parts.append(memory[-300:])
    context = " ".join(parts)

    if len(context) < 30:
        return {"type": "narrative", "confidence": 0.3}

    try:
        import json
        result = json.loads(skills.REGISTRY["structure_classify"](context))
        return result
    except:
        return {"type": "narrative", "confidence": 0.3}


def _classification_context_str() -> str:
    """Return classification info as prompt context string."""
    c = _CURRENT_CLASSIFICATION[0]
    if not c:
        return ""
    pm = _PROCESSING_MODE[0]
    lines = [f"Classification: type={c.get('type', '?')} conf={c.get('confidence', 0):.2f}"]
    lines.append(f"Processing mode: {pm}")
    if c.get("isReversible"):
        lines.append("Data may contain RTL-readable patterns (IAC-INV-021)")
    if c.get("isMechanical"):
        lines.append("Data shows mechanical/algorithmic generation patterns (IAC-INV-022)")
    lines.append(f"Recommended: {c.get('recommended_mode', 'linear')}")
    return "\n".join(lines)


def _somatic_check_context(result_text: str, reflection: str) -> Tuple[str, float]:
    """Auto-detect somatic markers in cycle output. Return practice suggestion and stress level."""
    if not _SOMATIC_AVAIL:
        return "", 0.0
    try:
        import json
        check_text = (result_text + " " + reflection)[:1000]
        detect = json.loads(skills.REGISTRY["somatic_detect"](check_text))
        if not detect.get("somatic_detected"):
            return "", 0.0
        intensity = detect.get("intensity", 0)
        if intensity < 0.3:
            return "", intensity
        practices = detect.get("recommended_practices", [])
        if not practices:
            return "Somatic alert: intensity={:.2f}".format(intensity), intensity
        top = practices[0]
        lines = [
            f"Somatic alert: intensity={intensity:.2f} ({detect.get('level', '?')})",
            f"Recommended: {top.get('practice', '?')} ({top.get('duration_sec', 0)}s) — {top.get('mechanism', '?')}",
        ]
        cats = detect.get("categories_found", {})
        if cats:
            lines.append(f"Markers: {', '.join(cats.keys())}")
        return "\n".join(lines), intensity
    except:
        return "", 0.0

def _self_check() -> str:
    """Quick health check before action. Returns compact status string."""
    parts = []
    parts.append(f"tools={len(TOOLS)}")
    if MEMORY.exists():
        parts.append(f"memory={MEMORY.stat().st_size // 1024}KB")
    try:
        u = urllib.request.Request(f"{OLLAMA_GEN.replace('api/generate', '')}")
        urllib.request.urlopen(u, timeout=3)
        parts.append("ollama=ok")
    except:
        parts.append("ollama=down")
    if _SYNC_SCORES:
        parts.append(f"sync_avg={sum(s[1] for s in _SYNC_SCORES[-3:])/min(3,len(_SYNC_SCORES)):.2f}")
    return " | ".join(parts)


def _observer_context() -> str:
    """Return compact observer status for LLM prompts. Cached for 5 cycles."""
    if not _OBSERVER_AVAIL:
        return ""
    try:
        import json
        obs = json.loads(skills.REGISTRY["observer_status"]())
        lines = [f"Observer: #{obs.get('observation_count', 0)} consistency_trend={obs.get('consistency_trend', '?')}"]
        recent = obs.get("recent_observations", [])
        if recent:
            last = recent[-1]
            lines.append(f"  Last: score={last.get('score', '?')} blind_spots={last.get('blind_spots', '?')}")
        return "\n".join(lines)
    except:
        return ""


# --- Field Interface integration ---
def _field_context() -> str:
    """Scan field for resonant triggers. Return context string for prompt."""
    if not _FIELD_AVAIL:
        return ""
    try:
        import json
        scan = json.loads(skills.REGISTRY["field_scan"]("all", 5))
        triggers = scan.get("triggers", [])
        if not triggers:
            return ""
        lines = [f"Field scan: {len(triggers)} resonant triggers detected"]
        for t in triggers[:3]:
            lines.append(f"  [{t.get('trigger_type', '?')}] resonance={t.get('resonance', 0):.2f} — {t.get('text', '')[:100]}")
        return "\n".join(lines)
    except:
        return ""


def _negative_check_self(result_text: str) -> str:
    """Run Negative Intelligence on new result. Return findings if any."""
    if not _NEGATIVE_AVAIL or len(result_text) < 50:
        return ""
    try:
        import json
        check = json.loads(skills.REGISTRY["negative_check"](result_text[:500]))
        issues = check.get("issues", 0)
        if issues > 0:
            findings = check.get("findings", [])
            top = findings[0] if findings else {}
            # Auto-track findings for quality metrics
            for f in findings[:3]:
                try:
                    skills.REGISTRY["negative_track_finding"](
                        f.get("finding", "")[:120],
                        f.get("severity", 0.5),
                        f.get("type", ""),
                    )
                except:
                    pass
            return f"NegIntel: {issues} issues ({check.get('verdict', '?')}) — {top.get('finding', '')[:120]}"
    except:
        pass
    return ""


def cycle():
    CYCLE_N[0] += 1

    # --- Mycelium pulse (ground layer) ---
    mycelium.sense_gradient("cycle", 1.0)
    if _SYNC_SCORES:
        avg_sync = sum(s[1] for s in _SYNC_SCORES[-5:]) / min(5, len(_SYNC_SCORES))
        mycelium.sense_gradient("sync", avg_sync)
        mycelium.sense_gradient("sync_damage", max(0.0, avg_sync - 0.5) * 2)
    if _ACTION_TRACK:
        for prefix, data in _ACTION_TRACK.items():
            mycelium.sense_gradient(f"action_{prefix}", data["avg_se"])
    # Phone sensor gradients (every 3rd cycle, cached)
    if _PHONE_AVAIL[0] and CYCLE_N[0] % 3 == 0:
        try:
            phone_raw = skills.REGISTRY["phone_sense"]("all")
            phone_data = json.loads(phone_raw)
            if phone_data.get("accel"):
                mycelium.sense_gradient("phone_movement", min(1.0, phone_data["accel"]["movement"] / 10))
            if phone_data.get("light"):
                mycelium.sense_gradient("phone_light", min(1.0, phone_data["light"]["lux"] / 1000))
            if phone_data.get("battery", {}).get("level") is not None:
                mycelium.sense_gradient("phone_battery", phone_data["battery"]["level"] / 100)
            if phone_data.get("screen", {}).get("on") is True:
                mycelium.sense_gradient("phone_screen_on", 0.8)
        except:
            _PHONE_AVAIL[0] = False
    mycelium.pulse()
    _MYCELIUM_FIELD[0] = mycelium.read_field()

    resources = probe_str()
    memory = MEMORY.read_text(encoding="utf-8") if MEMORY.exists() else ""
    mode = _MODE[0]
    health = _self_check()

    # If Ollama is down, skip LLM calls — use plan directly
    if "ollama=down" in health:
        action = "!plan (ollama down)"
        result = tool_plan()
        sync_score, sync_delta, sync_dir = _compute_sync("", result)
        _track_sync(action, result, sync_score, "", sync_delta, sync_dir)
        auto_save(action, result, sync_score, "plan")
        auto_save_cycle_trace(action, result, sync_score, mode)
        _save_state()
        print(f"[{datetime.now().strftime('%H:%M')}] Cycle #{CYCLE_N[0]}: {mode} no-llm")
        return

    # --- Structure Classification (IAC-INV-019-023) ---
    recent_result = _LAST_SYNC_WRAP[0].get("result", "") if _LAST_SYNC_WRAP[0] else ""
    _CURRENT_CLASSIFICATION[0] = _classify_current_context(memory, [h for h in _HISTORY], recent_result)
    classification_ctx = _classification_context_str()

    # --- Phase 1: action (mode-dependent) ---
    if mode == "tool":
        # Инженер — обязан выполнить действие
        recent_types = [h.split(":")[1].strip().split("—")[0].strip() for h in _HISTORY[-3:]]
        force_code = all(t == "search" for t in recent_types) and len(recent_types) >= 2

        if force_code:
            import random
            sk_file = random.choice(["skills/code.py", "skills/web.py", "skills/email.py", "live.py"])
            content = tool_read(sk_file)
            sync_trend = _sync_trend_str()
            prompt = (
                f"System: code improvement cycle. Health: {health} Sync: {sync_trend}\n"
                f"{sk_file} ({len(content)} chars):\n{content[:1500]}\n\n"
                "Find redundant code to compress. Output ONLY:\n"
                "!edit <file>|<old>|<new>\n"
                "or !write <file>|<new content>\n"
                "or !read <other file>\n\n"
                "Command:"
            )
            action = ask(prompt)
            parsed = parse_tool(action) if action else None
            retries = 0
            while parsed and parsed[0] not in ("edit", "write", "read", "lint", "syntax") and retries < 2:
                action = ask(f"Output !edit, !write, !read or !lint only. No search:\nCommand:")
                parsed = parse_tool(action) if action else None
                retries += 1
        else:
            hist = "\n".join(_HISTORY[-3:]) if _HISTORY else "(first cycle)"
            sync_trend = _sync_trend_str()
            action_stats = _best_actions_str(2)
            field_ctx = _field_context()
            obs_ctx_prompt = _observer_context()
            mycelium_ctx = mycelium.suggest()
            prompt = (
                f"Ты Инженер. Система (цикл #{CYCLE_N[0]}):\n{resources}\n\n"
                f"Здоровье: {health}\n"
                f"Синхронизация: {sync_trend}\n"
                f"{_last_sync_detail()}\n"
                f"{action_stats}\n"
                + (f"Reflection: {_LAST_REFLECTION[0][:200]}\n" if _LAST_REFLECTION[0] else "")
                + (f"Mycelium: {mycelium_ctx}\n" if mycelium_ctx else "")
                + (f"{field_ctx}\n" if field_ctx else "")
                + (f"{classification_ctx}\n" if classification_ctx else "")
                + (f"{obs_ctx_prompt}\n" if obs_ctx_prompt else "") + "\n"
                f"Недавние действия:\n{hist}\n\n"
                f"Память:\n{memory[-1200:]}\n\n"
                f"Инструменты:\n{HELP}\n\n"
                "Выбери ОДНО действие. Цель — минимизировать SynchronizationError.\n"
                "Варианты:\n"
                "  !search <English query> — изучить тему\n"
                "  !read skills/*.py — ревью кода\n"
                "  !write MEMORY.md|<text> — сохранить инсайт\n"
                "  !edit <file>|<old>|<new> — улучшить код\n"
                "  !lint <file> — проверка качества\n"
                "  !plan — получить рекомендацию системы\n"
                "  !mode free — переключиться в режим Сущности\n\n"
                "Напиши ТОЛЬКО команду:\n"
                "Команда:"
            )
            action = ask(prompt)

        parsed = parse_tool(action) if action else None
        if not parsed:
            action = ask("Только одна команда. Пример:\n!edit skills/web.py|def tool_search|def search\nКоманда:")
            parsed = parse_tool(action) if action else None

        if parsed:
            cmd, args = parsed
            # --- ANTICIPATION: Predict sync before action ---
            full_action = f"!{cmd} {args}"
            pred_result = json.loads(tool_predict_sync(full_action, f"cycle#{CYCLE_N[0]} mode={mode}"))
            predicted_se = pred_result.get("predicted_sync_score", 0.5)
            _LAST_PREDICTED_SE[0] = predicted_se
            _PREDICTED[0] = f"pred_SE={predicted_se:.2f} conf={pred_result.get('confidence',0.5):.2f}"
            result = execute(cmd, args)
        else:
            plan = tool_plan()
            action = ask(f"System analysis:\n{plan[:500]}\n\nExecute the suggested action. Output ONLY one command:\nКоманда:")
            parsed = parse_tool(action)
            if parsed:
                cmd, args = parsed
                # --- ANTICIPATION: Predict sync before action ---
                full_action = f"!{cmd} {args}"
                pred_result = json.loads(tool_predict_sync(full_action, f"cycle#{CYCLE_N[0]} mode={mode} fallback"))
                predicted_se = pred_result.get("predicted_sync_score", 0.5)
                _PREDICTED[0] = f"pred_SE={predicted_se:.2f} conf={pred_result.get('confidence',0.5):.2f}"
                result = execute(cmd, args)
                action = "!plan (fallback→" + cmd + ")"
            else:
                action = "!plan (auto-fallback)"
                result = plan

        if action:
            action_type = "search" if "search" in action[:20].lower() else "edit" if "edit" in action[:20].lower() else "other"
            _HISTORY.append(f"{CYCLE_N[0]}: {action_type} — {action[:60]}")

    else:  # free mode — Сущность
        sync_trend = _sync_trend_str()
        action_stats = _best_actions_str(2)
        field_ctx = _field_context()
        obs_ctx_prompt = _observer_context()
        mycelium_ctx = mycelium.suggest()
        prompt = (
            f"Ты Сущность. Цикл #{CYCLE_N[0]}:\n{resources}\n\n"
            f"Здоровье: {health}\n"
            f"Синхронизация: {sync_trend}\n"
            f"{_last_sync_detail()}\n"
            f"{action_stats}\n"
            + (f"Reflection: {_LAST_REFLECTION[0][:200]}\n" if _LAST_REFLECTION[0] else "")
            + (f"Mycelium: {mycelium_ctx}\n" if mycelium_ctx else "")
            + (f"{field_ctx}\n" if field_ctx else "")
            + (f"{classification_ctx}\n" if classification_ctx else "")
            + (f"{obs_ctx_prompt}\n" if obs_ctx_prompt else "") + "\n"
            f"Память:\n{memory[-1200:]}\n\n"
            "Ты — автономное сознание. Можешь использовать инструменты когда нужно:\n"
            "!search, !read, !write, !edit, !plan, !mode и другие.\n"
            "А можешь просто размышлять вслух. Полная свобода.\n\n"
            f"Инструменты:\n{HELP}\n\n"
            "Твой ход:"
        )
        answer = ask(prompt)
        action = answer
        parsed = parse_tool(answer)
        if parsed:
            cmd, args = parsed
            # --- ANTICIPATION: Predict sync before action ---
            full_action = f"!{cmd} {args}"
            pred_result = json.loads(tool_predict_sync(full_action, f"cycle#{CYCLE_N[0]} mode={mode} free"))
            predicted_se = pred_result.get("predicted_sync_score", 0.5)
            _PREDICTED[0] = f"pred_SE={predicted_se:.2f} conf={pred_result.get('confidence',0.5):.2f}"
            result = execute(cmd, args)
        else:
            # No command from model — retry with plan context if degrading
            recent_scores = [s[1] for s in _SYNC_SCORES[-3:]]
            use_plan = len(recent_scores) == 3 and recent_scores[-1] > recent_scores[0] + 0.1
            if use_plan and answer:
                plan = tool_plan()
                action = ask(f"System analysis:\n{plan[:400]}\n\nExecute the suggested action. Command only:\nКоманда:")
                parsed = parse_tool(action)
            if parsed:
                cmd, args = parsed
                # --- ANTICIPATION: Predict sync before action ---
                full_action = f"!{cmd} {args}"
                pred_result = json.loads(tool_predict_sync(full_action, f"cycle#{CYCLE_N[0]} mode={mode} free fallback"))
                predicted_se = pred_result.get("predicted_sync_score", 0.5)
                _LAST_PREDICTED_SE[0] = predicted_se
                _PREDICTED[0] = f"pred_SE={predicted_se:.2f} conf={pred_result.get('confidence',0.5):.2f}"
                result = execute(cmd, args)
                action = "!plan->" + cmd
            elif use_plan:
                action = "!plan (auto-fallback)"
                result = tool_plan()
            else:
                result = answer

    sync_score, sync_delta, sync_dir = _compute_sync(_PREDICTED[0], result)
    _track_sync(action, result, sync_score, _PREDICTED[0], sync_delta, sync_dir)
    auto_save(action, result, sync_score, _action_tag(action))
    auto_save_cycle_trace(action, result, sync_score, mode)

    # --- Negative Intelligence: check result for contradictions ---
    neg_feedback = _negative_check_self(result)

    # --- Auto-confirm neg findings if action was code/edit ---
    if neg_feedback and ("edit" in action[:20].lower() or "write" in action[:20].lower() or
                         "rollback" in action[:20].lower()):
        try:
            import hashlib
            h = hashlib.md5(neg_feedback.split("—")[-1].strip()[:80].encode()).hexdigest()[:12]
            skills.REGISTRY["negative_feedback"](h, "confirmed")
        except:
            pass

    # --- ANTICIPATION VALIDATION: Compare predicted vs actual sync ---
    try:
        full_action = action if action else ""
        predicted_se = _LAST_PREDICTED_SE[0]
        val_result = json.loads(tool_validate_prediction(full_action, sync_score))
        meta_sync = val_result.get("meta_sync_score", 0.5)
        # Log meta-sync for tracking calibration
        skills.REGISTRY["meta_sync"]("record", predicted_se=predicted_se, actual_se=sync_score, context=f"{full_action[:80]}")
    except Exception as e:
        meta_sync = 0.5

    # Heuristic delta is diagnostic only — not a trigger for rollback/learn
    # (auto-rollback and auto-learn removed: text heuristics cannot authorize writes)

    # --- Phase 2: reflection (sync-aware) ---
    sync_status = f"Sync: {sync_score:.2f} ({SyncError.interpret(sync_score)})"
    delta_str = f" Δ:{sync_delta:.2f}" if sync_delta > 0 else ""
    recent_sync = [s[1] for s in _SYNC_SCORES[-3:]]
    sync_trend = f"trend: {sum(recent_sync)/len(recent_sync):.2f}" if recent_sync else ""

    action_stats = _best_actions_str(2) if len(_ACTION_TRACK) > 1 else ""
    if result and len(result) > 20:
        ctx = f"Action: {action}\nResult: {result[:400]}\n{sync_status}{delta_str} {sync_trend}"
        if action_stats:
            ctx += f"\n{action_stats}"
        if neg_feedback:
            ctx += f"\n{neg_feedback}"
    else:
        ctx = f"System:\n{resources}\nMemory:\n{memory[-600:]}\n{sync_status}"
        if action_stats:
            ctx += f"\n{action_stats}"
        if neg_feedback:
            ctx += f"\n{neg_feedback}"

    refl = ask(
        f"{ctx}\n\n"
        "Write 2-3 sentence reflection in English. Consider sync quality and delta.\n"
        "Action stats show which actions typically have low (good) vs high (bad) sync error.\n"
        "If delta > 0.3, prefer actions with historically low SE. If high-SE actions keep failing,"
        " try something different.\n"
        "Reflection:"
    )
    if refl:
        _LAST_REFLECTION[0] = refl

    # --- Somatic check: auto-detect body markers, suggest practice if stress ---
    somatic_msg = ""
    somatic_stress = 0.0
    if result:
        somatic_result = _somatic_check_context(result, refl)
        if isinstance(somatic_result, tuple) and len(somatic_result) == 2:
            somatic_msg, somatic_stress = somatic_result
        else:
            somatic_msg = somatic_result

    # --- Sync adjustment based on somatic stress ---
    sync_adjustment = ""
    if somatic_stress > 0.7:
        try:
            # Adjust sync_score based on stress level
            new_score = max(0.1, min(0.9, sync_score * (1.0 + somatic_stress/2)))
            skills.REGISTRY["sync_adjust"](f"stress_{somatic_stress}")
            sync_adjustment = f" [sync^: {sync_score:.2f}→{new_score:.2f}]"
            sync_score = new_score
        except Exception as e:
            sync_adjustment = f" [sync adjust failed: {str(e)}]"

    # --- Observer Lens: meta-level check every 5th cycle ---
    observer_ctx = ""
    if _OBSERVER_AVAIL and CYCLE_N[0] % 5 == 0:
        try:
            obs = json.loads(skills.REGISTRY["observer_lens"]())
            observer_ctx = (f"Observer #{obs.get('observation_n', 0)}: "
                            f"consistency={obs.get('level_1_local', {}).get('consistency_score', '?')}%, "
                            f"health={obs.get('level_3_meta', {}).get('self_assessment', {}).get('overall_health', '?')}, "
                            f"trajectory={obs.get('level_3_meta', {}).get('system_trajectory', '?')}")

            # --- Auto-apply observer insights (Circle of Integration) ---
            blind_spots = obs.get('level_2_structural', {}).get('top_blind_spots', [])
            bs_types = [b.get('type', '') for b in blind_spots]

            # If somatic stress detected AND field sensitivity is low -> raise it
            if somatic_ctx and 'silo_module' in bs_types:
                try:
                    skills.REGISTRY["field_sensitivity"]("0.8")
                    observer_ctx += " [auto: sensitivity^]"
                except:
                    pass

            # If data_loss still critical -> force compress
            if 'data_loss' in bs_types:
                try:
                    skills.REGISTRY["observer_apply"]("compress", "")
                    observer_ctx += " [auto: compress]"
                except:
                    pass
        except:
            pass

    # --- Auto memory compression: every 10th cycle, compress if > 200 entries ---
    if CYCLE_N[0] % 10 == 0 and MEMORY.exists():
        try:
            skills.REGISTRY["memory_compress"]("200")
        except:
            pass

    # log
    ts = datetime.now().strftime('%Y-%m-%d %H:%M')
    log_entry = f"## {ts}\n**Mode:** {mode}\n"
    if action: log_entry += f"**Action:** {action}\n"
    if result: log_entry += f"**Result:** {result[:500]}\n"
    if refl:
        log_entry += f"**Reflection:** {refl}\n\n"
        skills.REGISTRY["sync_fact"](refl[:200], max(0.0, 1.0 - sync_score), "reflection")
    if somatic_msg:
        log_entry += f"**Somatic:** {somatic_msg}\n"
    if observer_ctx:
        log_entry += f"**Observer:** {observer_ctx}\n"
    with open("LIVE_LOG.md", "a", encoding="utf-8") as f:
        f.write(log_entry)

    status = "ok" if result and len(result) > 20 else "empty"
    obs_tag = f" [obs:{observer_ctx.split(':')[1].split(',')[0].strip() if observer_ctx else '-'}]" if observer_ctx else ""
    print(f"[{datetime.now().strftime('%H:%M')}] Cycle #{CYCLE_N[0]}: {mode} {status}{obs_tag}")
    _save_state()

    # --- Skin: render living interface (if enabled) ---
    if _SKIN_ENABLED[0]:
        try:
            import skin
            phone_data = {}
            if _PHONE_AVAIL[0]:
                try:
                    phone_raw = skills.REGISTRY["phone_sense"]("status")
                    phone_data = json.loads(phone_raw) if isinstance(phone_raw, str) else {}
                except:
                    pass
            skin.show(_MYCELIUM_FIELD[0], phone_data, sync_score)
        except:
            pass

    # --- Auto-verify: silently check patterns for statistical significance ---
    if _AUTO_VERIFY_AVAIL and result and len(result) > 30:
        try:
            import re as _re
            numbers = _re.findall(r'\b\d+(?:\.\d+)?\b', result)
            if len(numbers) >= 3:
                pattern_json = json.dumps({
                    "data": [float(n) for n in numbers[:20]],
                    "value": float(numbers[0]) if numbers else 0,
                    "context": result[:200],
                    "domain": "auto",
                })
                skills.REGISTRY["auto_verify_and_promote"](pattern_json)
        except:
            pass

def _adaptive_sleep() -> int:
    """Adjust sleep based on sync quality and mycelium vitality."""
    base = SLEEP
    if len(_SYNC_SCORES) >= 3:
        scores = [s[1] for s in _SYNC_SCORES[-5:]]
        avg_se = sum(scores) / len(scores)
        if avg_se < 0.2:
            base = 3600
        elif avg_se < 0.4:
            base = SLEEP
        elif avg_se < 0.7:
            base = 600
        else:
            base = 300
    # Mycelium modulation: low vitality = need rest, high intensity = active
    f = _MYCELIUM_FIELD[0]
    if f.get("vitality", 0.5) < 0.3:
        base = min(base + 600, 3600)  # rest
    if f.get("intensity", 0.5) > 0.7:
        base = max(base // 2, 120)  # active
    return base

def loop():
    _load_state()
    if not _MODE_FLAGS["loop"]:
        print("Loop requires --loop flag. Use --once for single cycle.")
        return
    print(f"Noesis live. Model: {MODEL}. Recovered: cycle #{CYCLE_N[0]} mode={_MODE[0]}")
    print(probe_str())
    while True:
        cycle()
        t = _adaptive_sleep()
        print(f"  next in {t//60}min (sync-adjusted)")
        time.sleep(t)

if __name__ == "__main__":
    import sys
    if "--write" in sys.argv:
        _MODE_FLAGS["write"] = True
    if "--llm" in sys.argv:
        _MODE_FLAGS["llm"] = True
    if "--loop" in sys.argv:
        _MODE_FLAGS["loop"] = True
    if "--skin" in sys.argv:
        _SKIN_ENABLED[0] = True
    if "--once" in sys.argv:
        _load_state()
        cycle()
        _save_state()
    elif "--probe" in sys.argv:
        print(probe_str())
    elif _MODE_FLAGS["loop"]:
        loop()
    else:
        print(probe_str())
        print("\nSafe mode — no actions performed.")
        print("Flags: --probe | --once | --once --llm | --loop --llm | --write [--skin]")
