"""
mycelium.py — клеточный слой IAC.
Не engine, не инструмент. Земля.
Живёт сама, когда импортирована.
"""

import json, math, random
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# --- Пять типов клеток ---
KINDS = ("DISTINCTION", "COMPOSITION", "TENSOR", "FIXED_POINT", "ADJOINT")
MAX_CELLS = 50

# Поле клеток
cells = []
gradient_field = {}  # {name: intensity}
field_pool = 0.0     # общий "эфир" — выделения всех клеток

# --- Примитивные трансформации ---

def _transform(cell, signal):
    """Один шаг метаболизма клетки. Возвращает output."""
    k = cell["kind"]
    s = cell["state"]
    m = cell["membrane"]
    inp = signal * m
    old_s = s

    if k == "DISTINCTION":
        # Различение: пороговый фильтр
        # Пропускает только то, что выше порога (1 - state)
        # Чем выше state, тем ниже порог — адаптивная чувствительность
        threshold = 1.0 - s * 0.8
        if inp > threshold:
            out = (inp - threshold) / (1.0 - threshold + 0.001)
            out = min(1.0, out * 1.5)
        else:
            out = 0.0
        s += (out - s) * 0.05

    elif k == "COMPOSITION":
        # Соединение: интегратор с затуханием
        # Сигнал накапливается, state растёт, но медленно затухает без сигнала
        s = s * 0.96 + inp * 0.15
        s = min(1.0, s)
        out = s

    elif k == "TENSOR":
        # Размножение: нелинейное усиление
        # Слабый сигнал (< 0.3) гасится, сильный — усиливается
        if inp > 0.3:
            out = min(1.0, inp * 1.6 + s * 0.2)
        else:
            out = max(0.0, inp * 0.2 - 0.05)
        s = s * 0.9 + out * 0.1

    elif k == "FIXED_POINT":
        # Рефлексия: гистерезис
        # Состояние инертно, сигнал вытесняет его медленно
        # Запоминает пиковые значения
        if inp > s:
            s += (inp - s) * 0.12  # быстро вверх
        else:
            s -= (s - inp) * 0.04  # медленно вниз
        out = s * 0.6 + inp * 0.4
        out = min(1.0, out)

    elif k == "ADJOINT":
        # Обмен: ретранслятор
        # Пропускает сигнал сквозь себя, почти не меняя
        # Но часть сигнала остаётся (metabolic cost of relay)
        pass_through = inp * (1.0 - m * 0.5)
        retained = inp * m * 0.3
        s = s * 0.95 + retained
        out = pass_through

    # Стоимость метаболизма: change cost
    delta = abs(s - old_s)
    cell["energy"] -= delta * 0.15
    cell["state"] = max(0.01, min(1.0, s))
    cell["membrane"] = max(0.05, min(0.95, m + (s - m) * 0.01))
    return out

# --- Рост и смерть ---

def _spawn(kind, tag="", state=None):
    """Создать новую клетку."""
    if len(cells) >= MAX_CELLS:
        return False
    cells.append({
        "id": f"{datetime.now().strftime('%H%M%S')}{random.randint(10, 99)}",
        "kind": kind,
        "state": state if state is not None else 0.3 + random.random() * 0.4,
        "membrane": 0.3 + random.random() * 0.5,
        "signal": 0.0,
        "output": 0.0,
        "age": 0,
        "energy": 0.7 + random.random() * 0.3,
        "tag": tag,
    })
    return True

def _die(cell):
    """Проверка апоптоза."""
    # Мембрана истончается с возрастом
    if cell["age"] > 50 and cell["age"] % 10 == 0:
        cell["membrane"] = max(0.05, cell["membrane"] - 0.001)
    # Энергия тратится на поддержание мембраны
    cell["energy"] -= 0.0005
    cell["energy"] = max(0.0, cell["energy"])
    return (cell["energy"] <= 0 or cell["membrane"] <= 0.05 or cell["age"] > 800)

# --- Внешние градиенты ---

def sense_gradient(name, intensity):
    """Установить внешний градиент (вызывается из live.py)."""
    gradient_field[name] = max(0.0, min(1.0, intensity))

def read_field():
    """Состояние поля для других модулей."""
    if not cells:
        return {"count": 0, "density": 0.0, "intensity": 0.0, "entropy": 0.0, "vitality": 0.0}
    states = [c["state"] for c in cells]
    energies = [c["energy"] for c in cells]
    kinds_count = defaultdict(int)
    for c in cells:
        kinds_count[c["kind"]] += 1
    total = len(cells)
    ent = 0.0
    for k in KINDS:
        p = kinds_count.get(k, 0) / total
        if p > 0:
            ent -= p * math.log2(p)
    return {
        "count": total,
        "density": total / MAX_CELLS,
        "intensity": sum(states) / total,
        "entropy": ent / math.log2(len(KINDS)) if total > 1 else 0.0,
        "vitality": sum(energies) / total,
        "pool": field_pool,
        "kinds": dict(kinds_count),
    }

# --- Пульс ---

_last_pulse = None

def pulse():
    """Один такт жизни мицелия. Вызывается из live.py в начале cycle()."""
    global _last_pulse, field_pool
    now = datetime.now()

    # 1. Разобрать градиенты в тип-сигналы
    kind_signals = {k: 0.0 for k in KINDS}
    for name, intensity in gradient_field.items():
        nl = name.lower()
        if "sync" in nl:
            kind_signals["FIXED_POINT"] += intensity
            kind_signals["DISTINCTION"] += (1.0 - intensity)
        elif "damage" in nl or "error" in nl:
            kind_signals["ADJOINT"] += intensity * 1.2
            kind_signals["COMPOSITION"] += intensity * 0.3
        elif "action" in nl:
            kind_signals["TENSOR"] += intensity
            kind_signals["COMPOSITION"] += intensity * 0.5
        elif "cycle" in nl or "new" in nl:
            kind_signals["COMPOSITION"] += intensity
            kind_signals["TENSOR"] += intensity * 0.5
        else:
            kind_signals["ADJOINT"] += intensity * 0.3

    # 2. Каждая клетка живёт
    dead_ids = set()
    total_output = 0.0
    for cell in cells:
        cell["age"] += 1
        # Сигнал = тип-сигнал + поле + шум
        base = kind_signals.get(cell["kind"], 0.0)
        pool_feed = field_pool * cell["membrane"] * 0.3
        noise = random.gauss(0, 0.03)
        cell["signal"] = max(0.0, min(1.0, base + pool_feed + noise))
        # Энергия от сигнала
        cell["energy"] = min(1.0, cell["energy"] + cell["signal"] * 0.008)
        # Трансформация
        out = _transform(cell, cell["signal"])
        cell["output"] = out
        total_output += out
        if _die(cell):
            dead_ids.add(cell["id"])

    # 3. Общий эфир: выходы всех клеток формируют поле
    field_pool = field_pool * 0.7 + (total_output / max(1, len(cells))) * 0.3

    # 4. Смерть
    if dead_ids:
        cells[:] = [c for c in cells if c["id"] not in dead_ids]
        total = len(cells)
        # При некрозе (массовая смерть) — выброс damage в поле
        if len(dead_ids) > max(1, total) * 0.3:
            sense_gradient("necrosis", min(1.0, len(dead_ids) / MAX_CELLS))

    # 5. Рост: при устойчивом сигнале > 0.5 и свободном месте
    if len(cells) < MAX_CELLS * 0.8:
        for kind in KINDS:
            if kind_signals[kind] > 0.5 and random.random() < 0.08:
                _spawn(kind)

    # 6. Регенерация после некроза: ускоренный рост
    necrosis = gradient_field.get("necrosis", 0.0)
    if necrosis > 0.3 and len(cells) < MAX_CELLS * 0.6:
        for _ in range(int(necrosis * 3)):
            kind = random.choice(KINDS)
            _spawn(kind, "regenerated", state=0.2 + random.random() * 0.3)

    # 7. Затухание градиентов
    for name in list(gradient_field.keys()):
        gradient_field[name] *= 0.93
        if gradient_field[name] < 0.01:
            del gradient_field[name]

    _last_pulse = now

# --- Влияние на систему ---

def suggest():
    """Что мицелий 'чувствует'. Рекомендация для выбора действия."""
    if not cells:
        return ""
    f = read_field()
    parts = []
    parts.append(f"field: {f['intensity']:.2f} ({f['count']} cells, vitality {f['vitality']:.2f})")
    if f["vitality"] < 0.3:
        parts.append("vitality low — prefer low-risk actions")
    if f["entropy"] > 0.7:
        parts.append("high diversity — exploration favorable")
    if f["entropy"] < 0.3:
        parts.append("low diversity — need new input")
    if gradient_field.get("necrosis", 0) > 0.3:
        parts.append("recovering from necrosis — conservative actions")
    return " | ".join(parts)

# --- Авто-инициализация ---

STATE_PATH = Path("data/mycelium_state.json")

def save_state():
    """Сохранить состояние мицелия для перезапуска."""
    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "cells": [{k: v for k, v in c.items() if k != "signal"} for c in cells],
            "pool": field_pool,
            "saved": datetime.now().isoformat(),
        }
        STATE_PATH.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except:
        pass

def load_state():
    """Загрузить сохранённое состояние. False если нет файла."""
    if not STATE_PATH.exists():
        return False
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        cells.clear()
        for c in data.get("cells", []):
            c["signal"] = 0.0
            cells.append(c)
        global field_pool
        field_pool = data.get("pool", 0.0)
        return True
    except:
        return False

def _seed_from_system():
    if load_state() and cells:
        return
    from_file = 0
    pf = Path("sync_patterns.json")
    if pf.exists():
        try:
            patterns = json.loads(pf.read_text(encoding="utf-8"))
            for p in patterns[:10]:
                kind = random.choice(KINDS)
                weight = p.get("weight", 0.5)
                if _spawn(kind, p.get("domain", "pattern"), state=min(1.0, weight)):
                    cells[-1]["id"] = f"ptn_{p.get('pattern', '?')[:4]}"
                    from_file += 1
        except:
            pass
    mf = Path("MEMORY.md")
    if mf.exists():
        try:
            text = mf.read_text(encoding="utf-8")
            seen_tags = set()
            for l in text.split("\n")[:30]:
                if not l.strip():
                    continue
                tag = "memory"
                if "search" in l.lower():
                    tag = "search"
                elif "code" in l.lower() or "edit" in l.lower():
                    tag = "code"
                elif "sync" in l.lower():
                    tag = "sync"
                if tag not in seen_tags or random.random() < 0.2:
                    kind = {"search": "COMPOSITION", "code": "TENSOR", "sync": "FIXED_POINT", "memory": "DISTINCTION"}.get(tag, "ADJOINT")
                    if _spawn(kind, tag):
                        cells[-1]["id"] = f"mem{tag[:2]}{random.randint(10,99)}"
                        seen_tags.add(tag)
                        from_file += 1
        except:
            pass
    if not cells:
        for kind in KINDS:
            _spawn(kind, "primordial")
            cells[-1]["id"] = f"primordial_{kind[:4].lower()}"

_seed_from_system()
