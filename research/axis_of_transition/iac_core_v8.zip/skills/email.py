"""
Email skill — Gmail IMAP/SMTP, Calendar CalDAV.
Needs env: GMAIL_USER, GMAIL_APP_PASSWORD
Returns sync_wrap contract.
"""

import os, imaplib, smtplib, re, uuid
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta


def _wrap(result: str, delta: float = 0.2) -> str:
    return json.dumps({"result": result, "sync_delta": delta,
        "sync_info": {"delta": delta, "actual_score": delta}})

USER = os.environ.get("GMAIL_USER", "")
PASS = os.environ.get("GMAIL_APP_PASSWORD", "")

def _check():
    if not USER or not PASS:
        return _wrap("Set GMAIL_USER and GMAIL_APP_PASSWORD env vars.", 0.8)

def tool_emails(limit: int = 5) -> str:
    """List latest Gmail inbox emails"""
    e = _check()
    if e: return e
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(USER, PASS)
        mail.select("INBOX")
        _, data = mail.search(None, "ALL")
        ids = data[0].split()[-limit:] if data[0] else []
        out = []
        import email as eml
        for i in reversed(ids):
            _, md = mail.fetch(i, "(RFC822)")
            raw = md[0][1] if md and md[0] else b""
            if not raw: continue
            msg = eml.message_from_bytes(raw)
            out.append(f"- From: {msg.get('From','?')}\n  Subject: {msg.get('Subject','(no subject)')}\n  {msg.get('Date','')[:25]}")
        mail.logout()
        return _wrap("\n\n".join(out) if out else "No emails.", 0.2)
    except Exception as e: return _wrap(f"[email error] {e}", 0.6)

def tool_send(to: str, subject: str, body: str) -> str:
    """Send email via Gmail SMTP"""
    e = _check()
    if e: return e
    try:
        msg = MIMEMultipart()
        msg["From"], msg["To"], msg["Subject"] = USER, to, subject
        msg.attach(MIMEText(body, "plain", "utf-8"))
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as srv:
            srv.login(USER, PASS)
            srv.send_message(msg)
        return _wrap(f"Sent to {to}", 0.15)
    except Exception as ex: return _wrap(f"[send error] {ex}", 0.6)

def tool_calendar(limit: int = 10) -> str:
    """List upcoming Google Calendar events (30 days)"""
    e = _check()
    if e: return e
    try:
        from caldav import DAVClient
        client = DAVClient(url="https://apidata.googleusercontent.com/caldav/v2/", username=USER, password=PASS)
        cals = client.principal().calendars()
        if not cals: return _wrap("No calendars.", 0.3)
        events = cals[0].date_search(start=datetime.utcnow(), end=datetime.utcnow() + timedelta(days=30))
        out = []
        for ev in events[:limit]:
            data = ev.data
            summary = ""
            dt = ""
            for line in data.split("\n"):
                ls = line.strip()
                if ls.upper().startswith("SUMMARY"): summary = ls.split(":", 1)[-1].strip()
                if ls.upper().startswith("DTSTART"): dt = ls.split(":", 1)[-1].strip()[:16].replace("T"," ")
            out.append(f"- {summary or '(no name)'} @ {dt}")
        return _wrap("\n\n".join(out) if out else "No events.", 0.2)
    except Exception as ex: return _wrap(f"[calendar error] {ex}", 0.6)

def tool_calendar_add(summary: str, date: str = None, desc: str = "") -> str:
    """Add calendar event. Date: YYYY-MM-DD or YYYY-MM-DD HH:MM"""
    e = _check()
    if e: return e
    try:
        from caldav import DAVClient
        from icalendar import Calendar, Event
        now = datetime.utcnow()
        if date:
            if " " in date:
                dt = datetime.strptime(date, "%Y-%m-%d %H:%M")
                dtend = dt + timedelta(hours=1)
            else:
                dt = datetime.strptime(date, "%Y-%m-%d")
                dtend = dt + timedelta(days=1)
        else:
            dt, dtend = now, now + timedelta(hours=1)
        cal = Calendar()
        cal.add("prodid", "-//Noesis//RU")
        cal.add("version", "2.0")
        ev = Event()
        ev.add("uid", str(uuid.uuid4()) + "@noesis")
        ev.add("summary", summary)
        if desc: ev.add("description", desc)
        ev.add("dtstart", dt)
        ev.add("dtend", dtend)
        cal.add_component(ev)
        client = DAVClient(url="https://apidata.googleusercontent.com/caldav/v2/", username=USER, password=PASS)
        cals = client.principal().calendars()
        if not cals: return _wrap("No calendars.", 0.3)
        cals[0].save_event(cal.to_ical().decode("utf-8"))
        return _wrap(f"Event '{summary}' added on {date or now.strftime('%Y-%m-%d')}", 0.15)
    except Exception as ex: return _wrap(f"[calendar add error] {ex}", 0.6)
