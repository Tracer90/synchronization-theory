"""
Code skill — edit, lint, backup, syntax. Returns sync_wrap contract.
"""

import json
import subprocess
from datetime import datetime
from pathlib import Path

_BACKUP_DIR = None


def _get_backup_dir():
    global _BACKUP_DIR
    if _BACKUP_DIR is None:
        _BACKUP_DIR = Path("backups")
        _BACKUP_DIR.mkdir(exist_ok=True)
    return _BACKUP_DIR

def _wrap(result: str, delta: float) -> str:
    return json.dumps({"result": result, "sync_delta": delta,
        "sync_info": {"delta": delta, "actual_score": delta}})

def tool_backup(path: str) -> str:
    """Backup a file before editing (timestamped)"""
    src = Path(path)
    if not src.exists():
        return _wrap("File not found.", 0.5)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    bd = _get_backup_dir()
    dst = bd / f"{src.name}.{ts}.bak"
    dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    return _wrap(f"Backup: {dst}", 0.1)

def tool_edit(path: str, old: str, new: str) -> str:
    """Find-replace with backup, syntax check, rollback on error"""
    src = Path(path)
    if not src.exists():
        return _wrap("File not found.", 0.5)
    content = src.read_text(encoding="utf-8")
    if old not in content:
        return _wrap("String not found.", 0.45)
    tool_backup(path)
    content = content.replace(old, new, 1)
    src.write_text(content, encoding="utf-8")
    try:
        compile(content, path, "exec")
        return _wrap(f"Edited {path}. Syntax OK.", 0.08)
    except SyntaxError as e:
        bd = _get_backup_dir()
        baks = sorted(bd.glob(f"{src.name}.*.bak"))
        if baks:
            src.write_text(baks[-1].read_text(encoding="utf-8"), encoding="utf-8")
        return _wrap(f"[SYNTAX ERROR at {e.lineno}:{e.offset}] {e.msg}. Rolled back.", 0.55)

def tool_syntax(path: str) -> str:
    """Check Python syntax via compile()"""
    src = Path(path)
    if not src.exists():
        return _wrap("File not found.", 0.5)
    try:
        compile(src.read_text(encoding="utf-8"), path, "exec")
        return _wrap("Syntax OK.", 0.08)
    except SyntaxError as e:
        return _wrap(f"[SYNTAX ERROR] {e}", 0.5)

def tool_lint(path: str) -> str:
    """Check Python code with ruff"""
    try:
        out = subprocess.run(["ruff", "check", "--no-cache", path], capture_output=True, text=True, timeout=15)
        if out.returncode == 0:
            return _wrap("Lint: clean.", 0.08)
        return _wrap(f"Lint:\n{out.stdout[:2000]}", 0.35)
    except FileNotFoundError:
        return _wrap("Install ruff: pip install ruff", 0.5)
    except Exception as e:
        return _wrap(f"[lint error] {e}", 0.6)

def tool_rollback(path: str) -> str:
    """Restore latest backup of a file (semantic rollback)"""
    src = Path(path)
    if not src.exists():
        return _wrap("File not found.", 0.5)
    bd = _get_backup_dir()
    baks = sorted(bd.glob(f"{src.name}.*.bak"))
    if not baks:
        return _wrap("No backups found.", 0.5)
    latest = baks[-1]
    src.write_text(latest.read_text(encoding="utf-8"), encoding="utf-8")
    return _wrap(f"Rolled back {path} to {latest.name}", 0.1)
