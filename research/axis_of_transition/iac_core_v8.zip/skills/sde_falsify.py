"""
sde_falsify.py — Falsification Engine for Scientific Discovery Engine
Designs and executes severe tests (Popper) to falsify hypotheses.
"""

import json
import random
import math
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any
from collections import defaultdict

SDE_GRAPH_FILE = Path("sde_hypothesis_graph.json")
MEMORY_FILE = Path("MEMORY.md")


def _load_graph() -> Dict:
    if SDE_GRAPH_FILE.exists():
        try:
            return json.loads(SDE_GRAPH_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"nodes": {}, "edges": []}


def _save_graph(graph: Dict):
    SDE_GRAPH_FILE.write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")


def _load_memory(limit: int = 500) -> List[Dict]:
    if not MEMORY_FILE.exists():
        return []
    import re
    content = MEMORY_FILE.read_text(encoding="utf-8")
    lines = content.strip().split("\n")
    entries = []
    for line in lines[-limit:]:
        m = re.match(r'- \[(.*?)\]\s*(?:\[(.*?)\])?\s*(.*?)\s*\{sync:\s*([\d.]+).*?\}', line)
        if m:
            entries.append({
                "timestamp": m.group(1),
                "tag": m.group(2) or "",
                "content": m.group(3).strip(),
                "sync_score": float(m.group(4))
            })
    return entries


def _design_severe_test(hypothesis: Dict) -> Dict:
    """
    Design a severe test following Popper:
    - Test prediction entailed by H (necessity)
    - Prediction unlikely under alternatives (specificity)
    - Prediction observable (measurability)
    - Test cheap to execute (efficiency)
    """
    predictions = hypothesis.get("falsifiable_predictions", [])
    if not predictions:
        return {"error": "no_falsifiable_predictions"}
    
    # Score each prediction
    scored = []
    for pred in predictions:
        necessity = pred.get("necessity", 0.8)  # How strongly H entails it
        specificity = pred.get("specificity", 0.7)  # How unlikely under ¬H
        measurability = pred.get("measurability", 0.9)
        cost = pred.get("cost", 1.0)  # Lower is better
        
        # Severity score: high necessity, high specificity, high measurability, low cost
        severity = (necessity * specificity * measurability) / cost
        
        scored.append({
            "prediction": pred,
            "severity_score": round(severity, 3),
            "necessity": necessity,
            "specificity": specificity,
            "measurability": measurability,
            "cost": cost
        })
    
    # Select most severe
    best = max(scored, key=lambda x: x["severity_score"])
    
    # Generate test design
    pred = best["prediction"]
    
    test_design = {
        "test_id": f"test_{hypothesis['id']}_{datetime.now().strftime('%H%M%S')}",
        "hypothesis_id": hypothesis["id"],
        "prediction_tested": pred,
        "severity": best["severity_score"],
        "test_type": _determine_test_type(pred),
        "procedure": _generate_procedure(pred, hypothesis),
        "expected_outcome_if_true": pred.get("prediction", "unknown"),
        "expected_outcome_if_false": pred.get("alternative", "different outcome"),
        "measurement": pred.get("measurement", "sync_score"),
        "threshold": pred.get("threshold", 0.2),
        "sample_size": pred.get("sample_size", 10),
        "created_at": datetime.now().isoformat()
    }
    
    return test_design


def _determine_test_type(prediction: Dict) -> str:
    """Determine what kind of test is needed."""
    condition = prediction.get("condition", "")
    if "cycle" in condition.lower() or "repeat" in condition.lower():
        return "time_series"
    elif "action" in condition.lower() or "tag" in condition.lower():
        return "action_intervention"
    elif "sync" in condition.lower():
        return "sync_measurement"
    return "observational"


def _generate_procedure(prediction: Dict, hypothesis: Dict) -> List[str]:
    """Generate concrete test procedure."""
    condition = prediction.get("condition", "")
    measurement = prediction.get("measurement", "sync_score")
    threshold = prediction.get("threshold", 0.2)
    n = prediction.get("sample_size", 10)
    
    procedures = []
    
    if "continue current dynamics" in condition.lower():
        procedures = [
            f"Run {n} cycles without intervention",
            f"Record {measurement} each cycle",
            f"Check if {measurement} {prediction.get('prediction', 'remains stable')}"
        ]
    elif "action" in condition.lower():
        procedures = [
            f"Execute target action {n} times",
            f"Measure {measurement} after each",
            f"Verify {prediction.get('prediction', 'outcome')}"
        ]
    else:
        procedures = [
            f"Observe system for {n} cycles",
            f"Measure {measurement}",
            f"Compare to threshold {threshold}"
        ]
    
    return procedures


def _execute_test(test: Dict) -> Dict:
    """Execute test by checking against existing memory or simulating."""
    # In real implementation, this would:
    # 1. Run actual intervention
    # 2. Measure outcome
    # 3. Compare to prediction
    
    # For now, simulate by checking memory
    memory = _load_memory(test["sample_size"])
    
    measurement = test["measurement"]
    threshold = test["threshold"]
    expected = test["expected_outcome_if_true"]
    
    if measurement == "sync_score":
        scores = [m["sync_score"] for m in memory[-test["sample_size"]:]]
        if scores:
            avg = sum(scores) / len(scores)
            passed = avg <= threshold if "low" in str(expected).lower() else avg >= threshold
            return {
                "test_id": test["test_id"],
                "executed": True,
                "measurements": scores,
                "avg_measurement": round(avg, 3),
                "threshold": threshold,
                "passed": passed,
                "result": "confirmed" if passed else "falsified",
                "executed_at": datetime.now().isoformat()
            }
    
    # Default: simulate
    return {
        "test_id": test["test_id"],
        "executed": True,
        "simulated": True,
        "result": "inconclusive",
        "note": "No matching measurement in memory, test simulated"
    }


def _update_hypothesis(graph: Dict, hyp_id: str, test: Dict, result: Dict):
    """Update hypothesis based on test result."""
    if hyp_id not in graph["nodes"]:
        return
    
    hyp = graph["nodes"][hyp_id]
    hyp["falsification_attempts"] = hyp.get("falsification_attempts", 0) + 1
    
    if result.get("result") == "confirmed":
        hyp["passed_tests"] = hyp.get("passed_tests", 0) + 1
        hyp["last_test_passed"] = True
    elif result.get("result") == "falsified":
        hyp["falsified"] = True
        hyp["falsified_at"] = datetime.now().isoformat()
        hyp["falsifying_test"] = test["test_id"]
        hyp["last_test_passed"] = False
    else:
        hyp["last_test_passed"] = None
    
    # Update cross-domain support
    if result.get("result") == "confirmed":
        hyp["cross_domain_support"] = hyp.get("cross_domain_support", 1) + 1
    
    # Update posterior (simple Bayesian update)
    prior = hyp.get("prior_plausibility", 0.5)
    if result.get("result") == "confirmed":
        likelihood = 0.8  # P(evidence | H)
    elif result.get("result") == "falsified":
        likelihood = 0.05  # P(evidence | H) if H false
    else:
        likelihood = 0.5
    alt_likelihood = 0.3  # P(evidence | ¬H)
    posterior = (likelihood * prior) / (likelihood * prior + alt_likelihood * (1 - prior))
    hyp["posterior_plausibility"] = round(posterior, 3)


def tool_sde_falsify_cycle(budget: int = 5) -> str:
    """
    Run falsification cycle: select hypotheses, design severe tests, execute, update.
    
    Args:
        budget: Maximum tests to run
    
    Returns:
        JSON with test results and updated hypotheses
    """
    graph = _load_graph()
    hypotheses = list(graph["nodes"].values())
    
    if not hypotheses:
        return json.dumps({"error": "no_hypotheses_to_test"})
    
    # Filter: not already falsified, have falsifiable predictions
    testable = [h for h in hypotheses 
                if not h.get("falsified", False) 
                and h.get("falsifiable_predictions")]
    
    if not testable:
        return json.dumps({"error": "no_testable_hypotheses"})
    
    # Prioritize: high prior * high falsifiability * low cost
    def priority(h):
        falsifiability = len(h.get("falsifiable_predictions", []))
        return h.get("posterior_plausibility", h.get("prior_plausibility", 0.5)) * falsifiability
    
    testable.sort(key=priority, reverse=True)
    
    results = []
    for h in testable[:budget]:
        # Design severe test
        test = _design_severe_test(h)
        if "error" in test:
            continue
        
        # Execute
        result = _execute_test(test)
        
        # Update hypothesis
        _update_hypothesis(graph, h["id"], test, result)
        
        results.append({
            "hypothesis": h["id"],
            "test": test,
            "result": result
        })
    
    _save_graph(graph)
    
    return json.dumps({
        "tests_run": len(results),
        "results": results,
        "surviving_hypotheses": sum(1 for h in graph["nodes"].values() if not h.get("falsified"))
    }, ensure_ascii=False, indent=2)


def tool_sde_falsification_frontier() -> str:
    """Show hypotheses with untested, precise, unique predictions."""
    graph = _load_graph()
    hypotheses = list(graph["nodes"].values())
    
    frontier = []
    for h in hypotheses:
        if h.get("falsified", False):
            continue
        preds = h.get("falsifiable_predictions", [])
        untested = [p for p in preds if not p.get("tested", False)]
        if untested:
            # Score precision and uniqueness
            for p in untested:
                precision = p.get("precision", 0.5)
                uniqueness = 1.0 / (1 + len([h2 for h2 in hypotheses if p.get("prediction", "") in str(h2.get("falsifiable_predictions", []))]))
                frontier.append({
                    "hypothesis": h["id"],
                    "prediction": p,
                    "frontier_score": round(precision * uniqueness * h.get("posterior_plausibility", 0.5), 3),
                    "prior": h.get("prior_plausibility", 0.5),
                    "falsifiability": len(preds)
                })
    
    frontier.sort(key=lambda x: x["frontier_score"], reverse=True)
    
    return json.dumps({
        "frontier_size": len(frontier),
        "top_candidates": frontier[:10]
    }, ensure_ascii=False, indent=2)