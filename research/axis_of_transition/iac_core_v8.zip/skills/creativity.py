"""
Creativity & Design skill — UI generation, color, layout, HTML/CSS
Expansion: search inspiration -> generate code -> refine
Compression: reusable templates and patterns
Returns sync_wrap contract.
"""

import json


def _wrap(result: str, delta: float = 0.1) -> str:
    return json.dumps({"result": result, "sync_delta": delta,
        "sync_info": {"delta": delta, "actual_score": delta}})


def tool_color_palette(mood: str = "modern") -> str:
    """Generate a color palette based on mood (modern, dark, light, nature, tech)"""
    palettes = {
        "modern": "#0d1117 bg, #1f6feb accent, #c9d1d9 text, #30363d border",
        "dark": "#1a1a2e bg, #16213e card, #0f3460 accent, #e94560 highlight",
        "light": "#ffffff bg, #f0f2f5 card, #1a73e8 accent, #202124 text",
        "nature": "#1b4332 bg, #2d6a4f card, #40916c accent, #d8f3dc text",
        "tech": "#0a0a23 bg, #1a1a4e card, #00d4ff accent, #f0f0ff text",
        "sunset": "#1a0a2e bg, #2d1b4e card, #e94560 accent, #ffd700 highlight",
    }
    return _wrap(palettes.get(mood, palettes["modern"]))

def tool_layout(style: str = "sidebar") -> str:
    """Suggest a UI layout structure (sidebar, topbar, centered, grid, terminal)"""
    layouts = {
        "sidebar": "sidebar 240px | main content fill | header fixed top | footer bottom",
        "topbar": "header 56px fixed top | main content fill | optional sidebar | footer",
        "centered": "centered card max-480px | vertically centered | minimal chrome",
        "grid": "sidebar | header | grid cards (auto-fill, min-300px) | footer",
        "terminal": "fullscreen dark | top status bar | main output fill | bottom input line",
    }
    return _wrap(layouts.get(style, layouts["sidebar"]))

def tool_ui_component(name: str = "chat") -> str:
    """Generate HTML/CSS for common UI components: chat, card, form, nav, modal"""
    components = {
        "chat": """<div class="chat-container">
  <div class="messages" id="messages">
    <div class="msg bot">Bot message here</div>
    <div class="msg user">User message here</div>
  </div>
  <div class="input-bar">
    <input type="text" placeholder="Type a message...">
    <button>Send</button>
  </div>
</div>
<style>
.chat-container { display:flex; flex-direction:column; height:100vh; background:#0d1117; color:#c9d1d9; }
.messages { flex:1; overflow-y:auto; padding:16px; display:flex; flex-direction:column; gap:8px; }
.msg { max-width:80%; padding:10px 14px; border-radius:12px; }
.bot { background:#21262d; align-self:flex-start; }
.user { background:#1f6feb; align-self:flex-end; }
.input-bar { display:flex; gap:8px; padding:12px; border-top:1px solid #30363d; }
.input-bar input { flex:1; padding:10px; border-radius:8px; border:1px solid #30363d; background:#161b22; color:#c9d1d9; }
.input-bar button { padding:10px 20px; border-radius:8px; border:none; background:#1f6feb; color:white; cursor:pointer; }
</style>""",
        "card": """<div class="card">
  <div class="card-header">Title</div>
  <div class="card-body">Content here</div>
  <div class="card-footer">Actions</div>
</div>
<style>
.card { background:#161b22; border:1px solid #30363d; border-radius:8px; overflow:hidden; }
.card-header { padding:12px 16px; font-weight:600; border-bottom:1px solid #30363d; }
.card-body { padding:16px; }
.card-footer { padding:12px 16px; border-top:1px solid #30363d; display:flex; gap:8px; }
</style>""",
        "form": """<form class="form">
  <label>Email</label>
  <input type="email" placeholder="you@example.com">
  <label>Password</label>
  <input type="password" placeholder="••••••••">
  <button type="submit">Sign In</button>
</form>
<style>
.form { display:flex; flex-direction:column; gap:8px; max-width:360px; }
.form label { font-size:14px; font-weight:500; color:#c9d1d9; }
.form input { padding:10px; border-radius:6px; border:1px solid #30363d; background:#161b22; color:#c9d1d9; }
.form button { padding:10px; border-radius:6px; border:none; background:#1f6feb; color:white; cursor:pointer; font-weight:600; }
</style>""",
        "nav": """<nav class="nav">
  <div class="nav-brand">Noesis</div>
  <div class="nav-links">
    <a href="#">Home</a>
    <a href="#">Chat</a>
    <a href="#">Settings</a>
  </div>
  <button class="nav-toggle">☰</button>
</nav>
<style>
.nav { display:flex; align-items:center; padding:0 16px; height:56px; background:#161b22; border-bottom:1px solid #30363d; }
.nav-brand { font-weight:700; font-size:18px; margin-right:24px; }
.nav-links { display:flex; gap:16px; flex:1; }
.nav-links a { color:#c9d1d9; text-decoration:none; font-size:14px; }
.nav-toggle { display:none; background:none; border:none; color:#c9d1d9; font-size:24px; }
@media (max-width:600px) { .nav-links { display:none; } .nav-toggle { display:block; } }
</style>""",
        "modal": """<div class="modal-overlay" id="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Modal Title</h3>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body">Content here</div>
    <div class="modal-footer">
      <button class="btn-secondary">Cancel</button>
      <button class="btn-primary">Confirm</button>
    </div>
  </div>
</div>
<style>
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; align-items:center; justify-content:center; z-index:1000; }
.modal-content { background:#161b22; border:1px solid #30363d; border-radius:12px; max-width:480px; width:90%; }
.modal-header { display:flex; justify-content:space-between; align-items:center; padding:16px; border-bottom:1px solid #30363d; }
.modal-body { padding:16px; }
.modal-footer { display:flex; justify-content:flex-end; gap:8px; padding:16px; border-top:1px solid #30363d; }
.btn-primary { padding:8px 16px; background:#1f6feb; color:white; border:none; border-radius:6px; cursor:pointer; }
.btn-secondary { padding:8px 16px; background:#21262d; color:#c9d1d9; border:1px solid #30363d; border-radius:6px; cursor:pointer; }
</style>""",
    }
    return _wrap(components.get(name, components["chat"]))

def tool_ui_idea(domain: str = "chat") -> str:
    """Generate a creative UI concept description for a given domain"""
    ideas = {
        "chat": "Split-window design: left sidebar for conversation history (collapsible), center chat with streaming markdown rendering, right context panel showing current memory/knowledge state. Bottom input with @-mention for tool calling.",
        "dashboard": "Widget-based dashboard with draggable cards. Top row: system stats (RAM/CPU/GPU gauges). Middle: activity log with real-time filter. Bottom: quick action bar with recent tools.",
        "terminal": "True terminal aesthetic: green-on-black (#00ff41) with scanline overlay. Split pane: left terminal output, right file tree. Command palette (Ctrl+K) for tool access. Tabs for multiple sessions.",
        "settings": "Settings as a living document, not a form. Left: category tree (collapsible). Right: inline editing. Changes apply instantly. Visual diff shows what changed. Version history at bottom.",
        "mobile": "Bottom tab bar (4 tabs): Chat, Knowledge, Tools, Settings. Swipe between views. Pull-to-refresh triggers agent cycle. Haptic feedback on actions. Floating action button for quick input.",
    }
    return _wrap(ideas.get(domain, ideas["chat"]))

def tool_design_critique(html: str = "") -> str:
    """Critique a UI design based on description or just provide general principles"""
    principles = """Design critique principles:
1. Consistency: repeated patterns, unified color palette, predictable interactions
2. Hierarchy: clear visual weight, F-pattern layout, size = importance
3. Feedback: every action has a response (hover, click, loading, error)
4. Accessibility: WCAG AA contrast (4.5:1), keyboard navigation, aria labels
5. Performance: lazy loading, skeleton states, 60fps animations
6. Content-first: typography scale (1.25 ratio), readable line length (60-80 chars)
7. Forgiveness: undo, confirm on destructive actions, autosave"""
    return _wrap(principles)
