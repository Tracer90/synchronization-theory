"""
phone.py — телефон как орган чувств IAC
ADB-сенсоры: акселерометр, свет, батарея, экран
"""

import json, re, subprocess
from pathlib import Path

ADB = "C:\\Users\\User\\AppData\\Local\\Android\\Sdk\\platform-tools\\adb.exe"
_DEVICE = "10AF2K14F5003U1"
_CACHE = {}
_CACHE_TTL = 5  # seconds

def _adb(var, timeout=5):
    try:
        r = subprocess.run([ADB, "-s", _DEVICE] + var.split(),
                           capture_output=True, text=True, timeout=timeout)
        return r.stdout
    except:
        return ""

def _sensor_value(sensor_name, label=""):
    """Extract last value from dumpsys sensorservice."""
    raw = _adb("shell dumpsys sensorservice")
    # Find sensor section
    lines = raw.split("\n")
    capture = False
    values = []
    for l in lines:
        if "last" in l and sensor_name in l:
            capture = True
            continue
        if capture:
            if l.strip().startswith(">") and sensor_name not in l:
                break
            m = re.search(r'\(ts=[^)]+\)\s+(.+)$', l.strip())
            if m:
                parts = [x.strip() for x in m.group(1).strip().rstrip(',').split(",") if x.strip()]
                nums = []
                for p in parts:
                    try:
                        nums.append(float(p))
                    except ValueError:
                        pass
                if nums:
                    values.append(nums)
    return values[:3] if values else []

def tool_phone_sense(sensor="all"):
    """Read phone sensors: accelerometer, light, battery, screen. !phone_sense [sensor]"""
    result = {"phone": True}
    if sensor in ("all", "accel", "accelerometer"):
        vals = _sensor_value("lsm6dsvq_acc")
        if vals:
            last = vals[0]
            # Calculate movement magnitude (excluding gravity ~9.8)
            mag = sum((v - (9.8 if i == 2 else 0))**2 for i, v in enumerate(last))**0.5
            result["accel"] = {"x": round(last[0], 2), "y": round(last[1], 2), "z": round(last[2], 2), "movement": round(mag, 2)}
        else:
            result["accel"] = None
    if sensor in ("all", "light"):
        vals = _sensor_value("gls6151c_als")
        if vals:
            last = vals[0]
            result["light"] = {"lux": round(last[0], 1), "raw": [round(v, 1) for v in last[:3]]}
        else:
            result["light"] = None
    if sensor in ("all", "proximity"):
        vals = _sensor_value("gls6151c_ps")
        if vals:
            result["proximity"] = {"value": round(vals[0][0], 1)}
        else:
            result["proximity"] = None
    if sensor in ("all", "gyro"):
        vals = _sensor_value("lsm6dsvq_gyro")
        if vals:
            last = vals[0]
            result["gyro"] = {"x": round(last[0], 2), "y": round(last[1], 2), "z": round(last[2], 2)}
        else:
            result["gyro"] = None
    if sensor in ("all", "battery"):
        raw = _adb("shell dumpsys battery")
        m_level = re.search(r'level:\s*(\d+)', raw)
        m_status = re.search(r'status:\s*(\d+)', raw)
        m_usb = re.search(r'USB powered:\s*(true|false)', raw)
        result["battery"] = {
            "level": int(m_level.group(1)) if m_level else None,
            "charging": m_usb.group(1) == "true" if m_usb else None,
            "status": int(m_status.group(1)) if m_status else None,
        }
    if sensor in ("all", "screen"):
        raw = _adb("shell dumpsys window")
        result["screen"] = {
            "on": "mScreenOnEarly=true" in raw or "mScreenOnFully=true" in raw,
            "awake": "mAwake=true" in raw,
        }
    return json.dumps(result, ensure_ascii=False)

def tool_phone_vibrate(duration_ms="200"):
    """Vibrate phone for N ms. !phone_vibrate 200"""
    _adb(f"shell service call vibrator 16 s32 {duration_ms}")  # Android 12+
    return json.dumps({"vibrated": True, "duration_ms": int(duration_ms)}, ensure_ascii=False)

def tool_phone_status():
    """Phone connection and sensor availability. !phone_status"""
    raw = _adb("devices")
    connected = _DEVICE in raw
    if not connected:
        return json.dumps({"connected": False}, ensure_ascii=False)
    bat = json.loads(tool_phone_sense("battery"))
    screen = json.loads(tool_phone_sense("screen"))
    accel = json.loads(tool_phone_sense("accel"))
    result = {
        "connected": True,
        "battery": bat.get("battery"),
        "screen": screen.get("screen"),
        "movement": accel.get("accel", {}).get("movement", 0) if accel.get("accel") else None,
    }
    return json.dumps(result, ensure_ascii=False)
