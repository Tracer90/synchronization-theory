"""
sde_pattern.py — Pattern Extraction for Scientific Discovery Engine
Extracts candidate regularities from observational data.
"""

import json
import re
import math
from datetime import datetime
from pathlib import Path
from collections import defaultdict, Counter
from typing import List, Dict, Any

MEMORY_FILE = Path("MEMORY.md")
SYNC_PATTERNS_FILE = Path("sync_patterns.json")
SYNC_SCORES_FILE = Path("state.json")


def _load_memory_entries(limit: int = None) -> List[Dict]:
    """Load memory entries with sync scores."""
    if not MEMORY_FILE.exists():
        return []
    content = MEMORY_FILE.read_text(encoding="utf-8")
    lines = content.strip().split("\n")
    if limit:
        lines = lines[-limit:]
    entries = []
    for line in lines:
        m = re.match(r'- \[(.*?)\]\s*(?:\[(.*?)\])?\s*(.*?)\s*\{sync:\s*([\d.]+).*?\}', line)
        if m:
            entries.append({
                "timestamp": m.group(1),
                "tag": m.group(2) or "",
                "content": m.group(3).strip(),
                "sync_score": float(m.group(4))
            })
    return entries


def _load_sync_history() -> List[Dict]:
    """Load sync scores from state file."""
    if not SYNC_SCORES_FILE.exists():
        return []
    try:
        data = json.loads(SYNC_SCORES_FILE.read_text(encoding="utf-8"))
        return data.get("sync_scores", [])
    except:
        return []


def _load_patterns() -> List[Dict]:
    if SYNC_PATTERNS_FILE.exists():
        try:
            return json.loads(SYNC_PATTERNS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []


# ===== 1. RECURRENCE QUANTIFICATION ANALYSIS =====

def _recurrence_analysis(entries: List[Dict]) -> Dict:
    """Quantify recurrence in sync scores and tags."""
    if len(entries) < 10:
        return {"error": "insufficient_data"}
    
    sync_scores = [e["sync_score"] for e in entries]
    tags = [e["tag"] for e in entries]
    
    # Recurrence matrix for sync scores (binned)
    bins = 10
    binned = [min(bins-1, int(s * bins)) for s in sync_scores]
    
    # Recurrence rate
    n = len(binned)
    rec_matrix = [[0]*n for _ in range(n)]
    threshold = 2  # bins
    for i in range(n):
        for j in range(n):
            if abs(binned[i] - binned[j]) <= threshold:
                rec_matrix[i][j] = 1
    
    recurrence_rate = sum(sum(row) for row in rec_matrix) / (n * n)
    
    # Determinism: diagonal lines
    diagonal_lines = []
    for i in range(n):
        for j in range(n):
            if i != j and rec_matrix[i][j] == 1:
                length = 1
                while i+length < n and j+length < n and rec_matrix[i+length][j+length] == 1:
                    length += 1
                if length >= 2:
                    diagonal_lines.append(length)
    
    determinism = sum(diagonal_lines) / (n * n) if diagonal_lines else 0
    max_line = max(diagonal_lines) if diagonal_lines else 0
    
    # Tag recurrence
    tag_rec = Counter(tags)
    tag_recurrence = {t: c/len(tags) for t, c in tag_rec.items()}
    
    return {
        "recurrence_rate": round(recurrence_rate, 3),
        "determinism": round(determinism, 3),
        "max_diagonal_line": max_line,
        "avg_diagonal_line": round(sum(diagonal_lines)/len(diagonal_lines), 2) if diagonal_lines else 0,
        "sync_score_entropy": round(-sum(p * math.log2(p) for p in Counter(binned).values() if p > 0), 3),
        "tag_recurrence": tag_recurrence,
        "interpretation": "high" if determinism > 0.3 else "moderate" if determinism > 0.1 else "low"
    }


# ===== 2. MUTUAL INFORMATION NETWORK =====

def _mutual_information_network(entries: List[Dict]) -> Dict:
    """Build MI network between tags and sync scores."""
    if len(entries) < 20:
        return {"error": "insufficient_data"}
    
    tags = [e["tag"] for e in entries]
    scores = [e["sync_score"] for e in entries]
    
    # Bin scores
    bins = 5
    binned = [min(bins-1, int(s * bins)) for s in scores]
    
    # Unique tags
    unique_tags = list(set(tags))
    tag_to_idx = {t: i for i, t in enumerate(unique_tags)}
    tag_seq = [tag_to_idx[t] for t in tags]
    
    # Joint distribution P(tag, score_bin)
    joint = defaultdict(int)
    for t, s in zip(tag_seq, binned):
        joint[(t, s)] += 1
    
    # Marginals
    p_tag = Counter(tag_seq)
    p_score = Counter(binned)
    n = len(tags)
    
    # MI per tag
    mi_per_tag = {}
    for t in unique_tags:
        mi = 0
        for s in range(bins):
            p_ts = joint.get((tag_to_idx[t], s), 0) / n
            if p_ts > 0:
                p_t = p_tag[tag_to_idx[t]] / n
                p_s = p_score[s] / n
                mi += p_ts * math.log2(p_ts / (p_t * p_s))
        mi_per_tag[t] = round(mi, 4)
    
    # Sort by MI
    sorted_mi = sorted(mi_per_tag.items(), key=lambda x: x[1], reverse=True)
    
    # Most predictive for low sync
    low_sync_tags = []
    for e in entries:
        if e["sync_score"] < 0.2:
            low_sync_tags.append(e["tag"])
    low_sync_dist = Counter(low_sync_tags)
    
    return {
        "mutual_info_per_tag": dict(sorted_mi),
        "most_predictive_tags": sorted_mi[:5],
        "most_predictive_low_sync": low_sync_dist.most_common(5),
        "total_tags": len(unique_tags),
        "entropy_tags": round(-sum((c/n)*math.log2(c/n) for c in p_tag.values()), 3),
        "entropy_scores": round(-sum((c/n)*math.log2(c/n) for c in p_score.values()), 3)
    }


# ===== 3. TOPOLOGICAL DATA ANALYSIS =====

def _topological_features(entries: List[Dict]) -> Dict:
    """Persistent homology on sync score time series (simplified)."""
    if len(entries) < 30:
        return {"error": "insufficient_data"}
    
    scores = [e["sync_score"] for e in entries]
    
    # Sliding window embedding
    window = 5
    embedded = []
    for i in range(len(scores) - window + 1):
        embedded.append(scores[i:i+window])
    
    # Distance matrix
    n = len(embedded)
    if n > 100:
        # Subsample
        indices = [i * n // 100 for i in range(100)]
        embedded = [embedded[i] for i in indices]
        n = 100
    
    # Compute Vietoris-Rips persistence (H0 and H1)
    # Simplified: count connected components and loops at different thresholds
    
    distances = []
    for i in range(n):
        for j in range(i+1, n):
            d = math.sqrt(sum((a-b)**2 for a, b in zip(embedded[i], embedded[j])))
            distances.append(d)
    
    if not distances:
        return {"error": "no_distances"}
    
    thresholds = sorted(set(round(d, 2) for d in distances))
    thresholds = thresholds[::max(1, len(thresholds)//20)]  # 20 thresholds
    
    h0_persist = []  # Components
    h1_persist = []  # Loops
    
    # Very simplified: track number of clusters vs threshold
    for eps in thresholds:
        # Union-find for connected components
        parent = list(range(n))
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py
        
        for i in range(n):
            for j in range(i+1, n):
                d = math.sqrt(sum((a-b)**2 for a, b in zip(embedded[i], embedded[j])))
                if d <= eps:
                    union(i, j)
        
        components = len(set(find(i) for i in range(n)))
        h0_persist.append(components)
    
    # H1: approximate by counting cycles in adjacency
    # Very rough approximation
    return {
        "h0_persistence": h0_persist[:10],
        "h1_persistence": [],  # Would need full PH library
        "detected_cycles": len([d for d in distances if d < 0.1]),
        "point_cloud_dimension": len(embedded[0]) if embedded else 0,
        "avg_distance": round(sum(distances)/len(distances), 3),
        "max_distance": round(max(distances), 3)
    }


# ===== 4. SYMMETRY DETECTION =====

def _symmetry_detection(entries: List[Dict]) -> List[Dict]:
    """Detect Lie group-like symmetries in the data."""
    if len(entries) < 30:
        return []
    
    scores = [e["sync_score"] for e in entries]
    symmetries = []
    
    # Time translation symmetry: autocorrelation
    for lag in range(1, min(20, len(scores)//2)):
        corr = sum(scores[i] * scores[i+lag] for i in range(len(scores)-lag))
        norm = sum(s*s for s in scores)
        if norm > 0:
            ac = corr / norm
            if ac > 0.7:
                symmetries.append({
                    "type": "time_translation",
                    "lag": lag,
                    "autocorrelation": round(ac, 3),
                    "generator": "d/dt"
                })
    
    # Scale symmetry: power law in score distribution
    if len(set(round(s, 2) for s in scores)) > 5:
        # Check if distribution follows power law
        hist = Counter(round(s, 2) for s in scores)
        items = sorted(hist.items())
        if len(items) > 5:
            x = [i+1 for i in range(len(items))]
            y = [v for _, v in items]
            # Simple power law fit
            logx = [math.log(v) for v in x if v > 0]
            logy = [math.log(v) for v in y if v > 0]
            if len(logx) > 3:
                # Linear fit
                n_pts = len(logx)
                sx = sum(logx)
                sy = sum(logy)
                sxx = sum(x*x for x in logx)
                sxy = sum(x*y for x, y in zip(logx, logy))
                denom = n_pts * sxx - sx * sx
                if denom != 0:
                    alpha = (n_pts * sxy - sx * sy) / denom
                    if abs(alpha + 1) < 0.5:  # Near -1 exponent
                        symmetries.append({
                            "type": "scale_invariance",
                            "exponent": round(alpha, 2),
                            "generator": "x d/dx"
                        })
    
    # Phase shift symmetry (for oscillatory)
    # Check if scores oscillate
    diffs = [scores[i+1] - scores[i] for i in range(len(scores)-1)]
    zero_crossings = sum(1 for i in range(len(diffs)-1) if diffs[i] * diffs[i+1] < 0)
    if zero_crossings > 3:
        period = len(scores) / (zero_crossings / 2)
        symmetries.append({
            "type": "phase_rotation",
            "estimated_period": round(period, 1),
            "generator": "d/dθ"
        })
    
    return symmetries


# ===== 5. CONSERVATION LAW DISCOVERY =====

def _conservation_laws(entries: List[Dict]) -> List[Dict]:
    """Noether-style: symmetry → conserved quantity."""
    laws = []
    if len(entries) < 20:
        return laws
    
    scores = [e["sync_score"] for e in entries]
    tags = [e["tag"] for e in entries]
    
    # Check if any linear combination is conserved
    # Look for: a*sync + b*tag_count = constant
    # Simplified: check if variance of certain combinations is low
    
    # Total "activity" = sum of sync scores over window
    window = 10
    activities = []
    for i in range(len(scores) - window):
        activities.append(sum(scores[i:i+window]))
    
    if activities:
        act_var = sum((x - sum(activities)/len(activities))**2 for x in activities) / len(activities)
        if act_var < 0.1:
            laws.append({
                "type": "activity_conservation",
                "quantity": "windowed_sync_sum",
                "variance": round(act_var, 4),
                "window": window,
                "symmetry_source": "time_translation"
            })
    
    # Tag-sync coupling
    for tag in set(tags):
        tag_scores = [s for s, t in zip(scores, tags) if t == tag]
        if len(tag_scores) > 5:
            var = sum((x - sum(tag_scores)/len(tag_scores))**2 for x in tag_scores) / len(tag_scores)
            if var < 0.02:
                laws.append({
                    "type": "tag_sync_coupling",
                    "tag": tag,
                    "sync_variance": round(var, 4),
                    "symmetry_source": "internal_symmetry"
                })
    
    # Information conservation (MI constant)
    # Check if MI between consecutive windows of MI(tag, score)
    return laws


# ===== MAIN TOOL =====

def tool_sde_extract_patterns(limit: int = 500) -> str:
    """
    Extract candidate patterns from memory and sync history.
    
    Returns JSON with:
    - recurrence_analysis
    - mutual_information_network
    - topological_features
    - symmetries
    - conservation_laws
    """
    entries = _load_memory_entries(limit)
    sync_history = _load_sync_history()
    
    # Combine entries with sync history
    combined = entries.copy()
    for s in sync_history[-100:]:
        if isinstance(s, list) and len(s) >= 2:
            combined.append({
                "timestamp": s[0],
                "tag": "sync_internal",
                "content": s[4] if len(s) > 4 else "",
                "sync_score": s[1]
            })
    
    if len(combined) < 10:
        return json.dumps({"error": "insufficient_data", "entries": len(combined)})
    
    patterns = {
        "recurrence_analysis": _recurrence_analysis(combined),
        "mutual_information_network": _mutual_information_network(combined),
        "topological_features": _topological_features(combined),
        "symmetries": _symmetry_detection(combined),
        "conservation_laws": _conservation_laws(combined),
        "extracted_at": datetime.now().isoformat(),
        "data_points": len(combined)
    }
    
    return json.dumps(patterns, ensure_ascii=False, indent=2)