"""
structure_classifier.py — StructureClassifier for IAC
Determines the structural type of incoming data BEFORE the main IAC cycle.
Implements Voynich invariants: instruction vs narrative, step delimiters,
reversibility, mechanical generation, topological reading.

Invariants: IAC-INV-019 through IAC-INV-023
Source: Voynich Manuscript analysis 2025-2026
"""

import json
import re
import math
from datetime import datetime
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Dict, Any, Optional, Tuple


# --- Step Markers (regular expressions) ---
DEFAULT_STEP_MARKERS = [
    r'\b(?:затем|потом|далее|после\s+этого|вслед|сначала|вначале|прежде\s+всего)\b',
    r'\b(?:then|next|after\s+that|afterward|first|firstly|secondly|thirdly|finally|lastly|subsequently)\b',
    r'\b(?:->|=>|→|⟹|step\s+\d+|шаг\s+\d+|этап\s+\d+)\b',
    r'\b(?:step|phase|stage|part)\s+\d+\b',
    r'\b(?:ytedy|yt|ty)\b',  # Voynich-like delimiters
    r'\b(?:1\.|2\.|3\.|4\.|5\.|6\.|7\.|8\.|9\.|10\.)\s',  # Numbered lists
    r'\b(?:I\.|II\.|III\.|IV\.|V\.)',
    r'\b(?:a\)|b\)|c\)|d\)|е\))',
]


# --- Zipf's law thresholds ---
ZIPF_FIRST_K = 10  # Check top 10 words
ZIPF_EXPECTED_RATIO = (2.0, 6.0)  # f(1)/f(2) ratio range for natural language


def _tokenize(text: str) -> List[str]:
    return re.findall(r'\b[a-zа-яё]{3,}\b', text.lower())


def _word_frequencies(tokens: List[str]) -> List[Tuple[str, int]]:
    return Counter(tokens).most_common()


def _zipf_check(tokens: List[str]) -> Dict:
    """Check if text follows Zipf's law (natural language indicator)."""
    if len(tokens) < 50:
        return {"zipfian": None, "confidence": 0.0, "reason": "insufficient_data"}

    freqs = _word_frequencies(tokens)
    if len(freqs) < 2:
        return {"zipfian": None, "confidence": 0.0, "reason": "too_few_unique"}

    # Zipf: f_n ≈ C / n^a. Check f(1)/f(2) ratio ~ 2 for natural language
    f1 = freqs[0][1]
    f2 = freqs[1][1] if len(freqs) > 1 else 1
    ratio = f1 / f2 if f2 > 0 else float('inf')

    # Perfect Zipf: f(rank) = C / rank
    # Check fit quality for top 10 ranks
    ranks = list(range(1, min(ZIPF_FIRST_K + 1, len(freqs) + 1)))
    actuals = [freqs[i - 1][1] for i in ranks]
    C = actuals[0]
    expected = [C / r for r in ranks]

    # R² for log-log fit
    log_r = [math.log(r) for r in ranks if r > 0]
    log_a = [math.log(a) for a in actuals if a > 0]

    if len(log_r) >= 3 and len(log_a) >= 3:
        n = len(log_r)
        sx = sum(log_r)
        sy = sum(log_a)
        sxx = sum(x * x for x in log_r)
        sxy = sum(x * y for x, y in zip(log_r, log_a))
        denom = n * sxx - sx * sx
        if denom != 0:
            slope = (n * sxy - sx * sy) / denom
            zipf_like = -1.3 < slope < -0.7  # Natural language: slope ≈ -1

            zipfian = zipf_like and (1.5 < ratio < 5.0)
            confidence = abs(slope + 1.0)  # Closer to -1 = less confidence it's NOT language

            return {
                "zipfian": zipfian,
                "confidence": round(min(1.0, 1.0 - abs(slope + 1.0) * 0.5), 3),
                "ratio_f1_f2": round(ratio, 2),
                "slope": round(slope, 3),
                "unique_words": len(freqs),
                "total_tokens": len(tokens),
            }

    return {"zipfian": None, "confidence": 0.0, "reason": "could_not_compute"}


def _phonetic_entropy(text: str) -> float:
    """Character-level entropy — natural language typically 3.5-4.5 bits."""
    if len(text) < 50:
        return 0.0
    chars = list(text.lower())
    freq = Counter(chars)
    total = len(chars)
    entropy = -sum((c / total) * math.log2(c / total) for c in freq.values() if c > 0)
    return round(entropy, 3)


def tool_structure_classify(text: str, custom_markers: str = "") -> str:
    """
    Classify the structural type of input data.
    
    Returns a ClassificationResult:
        type: 'narrative' | 'instruction' | 'diagram' | 'mixed'
        confidence: 0-1
        markers: found step delimiters
        isReversible: boolean
        isMechanical: boolean
    
    Args:
        text: Input text to classify
        custom_markers: JSON list of additional regex patterns to use as step markers
    """
    return json.dumps(_classify(text, custom_markers), ensure_ascii=False, indent=2)


def _classify(text: str, custom_markers: str = "") -> Dict:
    """Core classification logic."""
    if not text or len(text) < 10:
        return {
            "type": "narrative",
            "confidence": 0.3,
            "markers": [],
            "isReversible": False,
            "isMechanical": False,
            "graph": None,
            "error": "insufficient_data"
        }

    markers = tool_detect_markers(text, custom_markers)
    rtl = tool_detect_rtl(text)
    mechanical = tool_detect_mechanical(text)

    # Determine type
    marker_count = len(markers) if isinstance(markers, list) else 0
    is_rev = rtl.get("isReversible", False) if isinstance(rtl, dict) else False
    is_mech = mechanical.get("isMechanical", False) if isinstance(mechanical, dict) else False

    tokens = _tokenize(text)
    zipf = _zipf_check(tokens)
    entropy = _phonetic_entropy(text)

    scores = {"instruction": 0.0, "narrative": 0.5, "diagram": 0.0, "mixed": 0.0}

    # Instruction scoring
    if marker_count >= 3:
        scores["instruction"] += 0.6
    elif marker_count >= 1:
        scores["instruction"] += 0.3

    # Imperative verbs boost instruction score
    imperative_patterns = [
        r'\b(?:возьми|добавь|налей|нарежь|поставь|включи|выключи|открой|закрой|сделай|выполни|запусти|нажми)\b',
        r'\b(?:take|add|pour|cut|put|turn|open|close|make|do|run|press|click|enter|set|get)\b',
    ]
    imp_count = sum(len(re.findall(p, text, re.IGNORECASE)) for p in imperative_patterns)
    if imp_count >= 3:
        scores["instruction"] += 0.2

    # Narrative scoring
    narrative_markers = [
        r'\b(?:история|рассказ|глава|эпизод|однажды|когда-то|жил|был)\b',
        r'\b(?:story|chapter|once\s+upon|history|narrative|tale)\b',
        r'\b(?:я\s+(?:думаю|считаю|полагаю|вижу|слышу|чувствую))\b',
    ]
    narr_count = sum(len(re.findall(p, text, re.IGNORECASE)) for p in narrative_markers)
    if narr_count >= 2:
        scores["narrative"] += 0.3

    # Diagram scoring: low Zipf conformity + low phonetic entropy = likely diagram/table
    if zipf.get("zipfian") == False and entropy < 3.5:
        scores["diagram"] += 0.5
        scores["narrative"] -= 0.2
    elif zipf.get("zipfian") == True:
        scores["narrative"] += 0.3

    # Mixed scoring: if multiple types score high
    top_types = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    if top_types[0][1] - top_types[1][1] < 0.15:
        scores["mixed"] = max(scores.values())

    # Determine final type
    best_type = max(scores, key=scores.get)
    confidence = round(min(1.0, max(0.1, scores[best_type])), 3)

    result = {
        "type": best_type,
        "confidence": confidence,
        "markers": markers if isinstance(markers, list) else [],
        "isReversible": is_rev,
        "isMechanical": is_mech,
        "scores": {k: round(v, 3) for k, v in scores.items()},
        "zipf_analysis": zipf,
        "phonetic_entropy": entropy,
        "token_count": len(tokens),
        "classified_at": datetime.now().isoformat(),
    }

    # Recommend processing mode
    if best_type == "instruction" and is_rev:
        result["recommended_mode"] = "reversed"
    elif best_type == "diagram":
        result["recommended_mode"] = "topological"
    elif best_type == "instruction":
        result["recommended_mode"] = "linear"
    else:
        result["recommended_mode"] = "linear"

    return result


def tool_detect_markers(text: str, custom_markers: str = "") -> list:
    """
    Detect step delimiters (ytedy-like markers) in text.
    
    Args:
        text: Input text to scan
        custom_markers: JSON list of additional regex pattern strings
    
    Returns:
        List of detected marker objects [{marker, position, pattern}]
    """
    if not text:
        return []

    markers = list(DEFAULT_STEP_MARKERS)
    if custom_markers:
        try:
            extra = json.loads(custom_markers)
            if isinstance(extra, list):
                markers.extend(extra)
        except:
            pass

    found = []
    for pattern in markers:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            found.append({
                "marker": m.group(0),
                "position": m.start(),
                "pattern": pattern[:60],
                "context": text[max(0, m.start() - 20):m.end() + 30].strip()
            })

    # Deduplicate by position
    seen = set()
    unique = []
    for f in found:
        key = (f["position"], f["marker"])
        if key not in seen:
            seen.add(key)
            unique.append(f)

    unique.sort(key=lambda x: x["position"])
    return unique


def tool_detect_rtl(text: str) -> str:
    """
    Check if reverse reading (RTL) reveals hidden patterns.
    
    Args:
        text: Input text
    
    Returns:
        JSON: {isReversible: bool, forward_score, reverse_score, reason}
    """
    if not text or len(text) < 50:
        return json.dumps({"isReversible": False, "confidence": 0.0, "reason": "insufficient_data"})

    tokens = _tokenize(text)
    if len(tokens) < 20:
        return json.dumps({"isReversible": False, "confidence": 0.0, "reason": "too_few_tokens"})

    # Forward: check token frequency distribution
    fw_freq = _word_frequencies(tokens)
    fw_types = len(fw_freq)
    fw_entropy = -sum((c / len(tokens)) * math.log2(c / len(tokens))
                      for _, c in fw_freq if c > 0)

    # Reverse: tokens in reverse order
    rev_tokens = list(reversed(tokens))
    rv_freq = _word_frequencies(rev_tokens)
    rv_entropy = -sum((c / len(rev_tokens)) * math.log2(c / len(rev_tokens))
                      for _, c in rv_freq if c > 0)

    # Check if reverse reveals more structure
    # Fewer unique tokens in reverse = more structure when reversed
    rv_unique = len(rv_freq)

    # Heuristic: if reverse has notably different entropy or structure
    entropy_diff = abs(fw_entropy - rv_entropy)
    unique_ratio = rv_unique / max(1, fw_types)

    is_rev = (entropy_diff > 0.3 or unique_ratio < 0.85)
    confidence = round(min(1.0, entropy_diff * 2 + (1.0 - unique_ratio)), 3)

    reason = ""
    if is_rev:
        parts = []
        if entropy_diff > 0.3:
            parts.append(f"entropy_diff={entropy_diff:.2f}")
        if unique_ratio < 0.85:
            parts.append(f"unique_ratio={unique_ratio:.2f}")
        reason = " | ".join(parts)

    return json.dumps({
        "isReversible": is_rev,
        "confidence": confidence,
        "forward_entropy": round(fw_entropy, 3),
        "reverse_entropy": round(rv_entropy, 3),
        "entropy_difference": round(entropy_diff, 3),
        "forward_unique": fw_types,
        "reverse_unique": rv_unique,
        "unique_ratio": round(unique_ratio, 3),
        "reason": reason or None,
    })


def tool_detect_mechanical(text: str) -> str:
    """
    Check if data appears algorithmically/mechanically generated.
    
    Uses:
    - Repetition patterns
    - Entropy analysis
    - Autocorrelation of token sequences
    
    Args:
        text: Input text (or JSON array of values)
    
    Returns:
        JSON: {isMechanical: bool, confidence, patterns, entropy}
    """
    if not text or len(text) < 30:
        return json.dumps({"isMechanical": False, "confidence": 0.0, "reason": "insufficient_data"})

    scores = {"mechanical": 0.0, "natural": 0.0}

    # 1. Check numerical patterns
    numbers = re.findall(r'\b\d+(?:\.\d+)?\b', text)
    numeric = len(numbers) > len(text.split()) * 0.3 if text.split() else False
    if numeric:
        scores["mechanical"] += 0.2

    # 2. Exact repetition of long substrings
    tokens = _tokenize(text)
    if len(tokens) >= 10:
        # Check for repeated token triplets
        triplets = [" ".join(tokens[i:i + 3]) for i in range(len(tokens) - 2)]
        trip_freq = Counter(triplets)
        repeated = sum(1 for v in trip_freq.values() if v >= 3)
        if repeated >= 3:
            scores["mechanical"] += 0.3

        # Check for n-gram repetition patterns
        for n in [2, 4, 6]:
            ngrams = [" ".join(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]
            ng_freq = Counter(ngrams)
            if len(ngrams) > 10:
                repeat_ratio = sum(1 for v in ng_freq.values() if v >= 2) / len(ng_freq)
                if repeat_ratio > 0.3:
                    scores["mechanical"] += 0.1 * n / 2

    # 3. Entropy analysis
    chars = list(text.lower())
    if len(chars) > 10:
        char_freq = Counter(chars)
        char_entropy = -sum((c / len(chars)) * math.log2(c / len(chars))
                            for c in char_freq.values() if c > 0)
        # Natural text: ~4-4.5 bits. Mechanical: lower or higher extremes
        if char_entropy < 3.0:
            scores["mechanical"] += 0.3  # Very repetitive
        elif char_entropy > 5.5:
            scores["mechanical"] += 0.15  # Very random (e.g., encrypted/mechanical)
        else:
            scores["natural"] += 0.2

    # 4. Autocorrelation pattern
    if len(tokens) >= 20:
        token_ids = []
        token_map = {}
        for t in tokens:
            if t not in token_map:
                token_map[t] = len(token_map)
            token_ids.append(token_map[t])

        # Check for periodic repetition
        for period in [2, 3, 5, 7]:
            matches = 0
            total = len(token_ids) - period
            for i in range(total):
                if token_ids[i] == token_ids[i + period]:
                    matches += 1
            if total > 0 and matches / total > 0.4:
                scores["mechanical"] += 0.25
                break

    is_mech = scores["mechanical"] > scores["natural"] + 0.1
    confidence = round(min(1.0, max(0.1, abs(scores["mechanical"] - scores["natural"]))), 3)

    found_patterns = []
    if scores["mechanical"] > 0.3:
        found_patterns.append("repetition")
    if char_entropy < 3.0:
        found_patterns.append("low_entropy")
    elif char_entropy > 5.5:
        found_patterns.append("high_entropy")
    if numeric:
        found_patterns.append("numeric_dominant")

    return json.dumps({
        "isMechanical": is_mech,
        "confidence": confidence,
        "mechanical_score": round(scores["mechanical"], 3),
        "natural_score": round(scores["natural"], 3),
        "char_entropy": round(char_entropy, 3) if 'char_entropy' in dir() else 0,
        "patterns_detected": found_patterns,
        "token_count": len(tokens),
    })


def tool_build_graph(text: str, relation_type: str = "cooccurrence") -> str:
    """
    Build a graph from input text for topological analysis.
    
    Nodes = key tokens/entities
    Edges = relations (co-occurrence, temporal sequence, causality, similarity)
    
    Args:
        text: Input text
        relation_type: "cooccurrence" | "temporal" | "similarity" | "all"
    
    Returns:
        JSON: {nodes: [...], edges: [...], stats: {...}}
    """
    if not text or len(text) < 30:
        return json.dumps({"error": "insufficient_data", "nodes": [], "edges": []})

    tokens = _tokenize(text)
    stopwords = {
        'the', 'and', 'for', 'that', 'this', 'with', 'from', 'have', 'are',
        'это', 'что', 'как', 'для', 'или', 'так', 'уже', 'ещё', 'быть', 'есть',
        'was', 'were', 'been', 'being', 'has', 'had', 'not', 'but', 'all',
        'will', 'would', 'could', 'should', 'may', 'might', 'can', 'shall',
        'она', 'оно', 'они', 'себя', 'весь', 'кто', 'когда', 'где', 'почему',
    }
    filtered = [t for t in tokens if t not in stopwords]

    # Build nodes from top frequencies
    freq = Counter(filtered).most_common(30)
    nodes = []
    for word, count in freq:
        nodes.append({
            "id": word,
            "label": word,
            "frequency": count,
            "normalized_weight": round(count / max(1, len(filtered)), 4),
        })

    # Build edges based on relation type
    edges = []
    node_ids = {n["id"] for n in nodes}

    if relation_type in ("cooccurrence", "all"):
        window = 5
        token_ids = [t for t in filtered if t in node_ids]
        for i in range(len(token_ids)):
            for j in range(i + 1, min(i + window, len(token_ids))):
                if token_ids[i] != token_ids[j]:
                    edges.append({
                        "from": token_ids[i],
                        "to": token_ids[j],
                        "relation": "cooccurrence",
                        "weight": round(1.0 / (j - i), 3)  # Closer = stronger
                    })

    if relation_type in ("temporal", "all"):
        sentences = re.split(r'[.!?\n]+', text)
        for sent in sentences:
            sent_tokens = [t for t in _tokenize(sent) if t in node_ids]
            for i in range(len(sent_tokens) - 1):
                edges.append({
                    "from": sent_tokens[i],
                    "to": sent_tokens[i + 1],
                    "relation": "temporal",
                    "weight": 0.8,
                })

    if relation_type in ("similarity", "all"):
        for i, n1 in enumerate(nodes):
            for j, n2 in enumerate(nodes[i + 1:], i + 1):
                w1, w2 = n1["id"], n2["id"]
                char_overlap = len(set(w1) & set(w2)) / max(1, len(set(w1) | set(w2)))
                if char_overlap > 0.4:
                    edges.append({
                        "from": w1,
                        "to": w2,
                        "relation": "similarity",
                        "weight": round(char_overlap, 3),
                    })

    # Deduplicate edges
    seen = set()
    unique_edges = []
    for e in edges:
        key = (e["from"], e["to"], e["relation"])
        if key not in seen:
            seen.add(key)
            unique_edges.append(e)

    # Graph stats
    degrees = defaultdict(int)
    for e in unique_edges:
        degrees[e["from"]] += 1
        degrees[e["to"]] += 1

    max_deg = max(degrees.values()) if degrees else 0
    avg_deg = sum(degrees.values()) / max(1, len(nodes))
    density = (2 * len(unique_edges)) / max(1, len(nodes) * (len(nodes) - 1))

    return json.dumps({
        "nodes": nodes,
        "edges": unique_edges,
        "stats": {
            "node_count": len(nodes),
            "edge_count": len(unique_edges),
            "max_degree": max_deg,
            "avg_degree": round(avg_deg, 2),
            "density": round(density, 4),
            "relation_type": relation_type,
        },
        "built_at": datetime.now().isoformat(),
    }, ensure_ascii=False, indent=2)


def tool_classify_and_graph(text: str) -> str:
    """
    Full pipeline: classify text AND build graph.
    Returns combined result for diagrammatic mode.
    """
    classification = _classify(text)
    graph = json.loads(tool_build_graph(text, "all"))

    return json.dumps({
        "classification": classification,
        "graph": graph,
        "recommended_mode": classification.get("recommended_mode", "linear"),
    }, ensure_ascii=False, indent=2)
