"""
translate.py — Translation Architecture: мост между моделями

Реализует архитектуру перевода — систему правил, позволяющую преобразовывать
понятия одной модели в понятия другой без потери ключевых инвариантов.

Компоненты:
- Словарь соответствий (domain mapping)
- Грамматика переходов (сопоставление структур)
- Метрика согласованности (оценка качества перевода)
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Any

TRANSLATION_DB = Path("data/translation_db.json")


# ----------------------------------------------------------------
# База соответствий
# ----------------------------------------------------------------

def _load_translations() -> Dict:
    if TRANSLATION_DB.exists():
        try:
            return json.loads(TRANSLATION_DB.read_text(encoding="utf-8"))
        except:
            pass
    return {"mappings": {}, "domains": {}, "history": []}


def _save_translations(db: Dict):
    TRANSLATION_DB.parent.mkdir(exist_ok=True)
    TRANSLATION_DB.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding="utf-8")


_TRANSLATIONS = _load_translations()


# ----------------------------------------------------------------
# Ядро перевода
# ----------------------------------------------------------------

# Встроенный словарь соответствий между доменами
_BUILTIN_MAPPING = {
    "iac_to_intuition": {
        "sync_error": "ощущение расхождения с реальностью",
        "invariant": "устойчивый паттерн / закон",
        "meta_rule": "новый уровень понимания",
        "field": "информационное поле / поток идей",
        "trigger": "сигнал / озарение / толчок",
        "conflict": "внутреннее противоречие / когнитивный диссонанс",
        "representation": "модель мира / картина реальности",
        "transformation": "изменение / адаптация / рост",
        "self_consistency": "логическая цельность / непротиворечивость",
        "compression": "упрощение / выделение сути",
        "falsification": "проверка на прочность / попытка опровергнуть",
        "negative_intelligence": "внутренний критик / механизм сомнения",
        "field_interface": "восприимчивость / интуиция / чутьё",
    },
    "intuition_to_iac": {
        "интуиция": "field_interface + pattern detection без осознанного вывода",
        "озарение": "trigger с высоким резонансом",
        "внутренний голос": "negative_intelligence + field_interface",
        "поток": "field в активном состоянии синхронизации",
        "судьба": "trajectory в пространстве состояний при данных ограничениях",
        "душа": "representation на уровне meta-transformation",
        "любовь": "синхронизация с минимальным sync_error",
        "страх": "trigger с высоким sync_error без возможности разрешения",
        "вера": "invariant с posterior > 0.9, принятый без полной проверки",
        "чудо": "observation с sync_error > 0.9 относительно текущей модели",
    },
    "iac_to_business": {
        "sync_error": "gap analysis / отклонение от плана",
        "invariant": "устойчивое конкурентное преимущество",
        "meta_rule": "новая бизнес-модель",
        "conflict": "стратегическое противоречие",
        "representation": "карта рынка / бизнес-модель",
        "falsification": "A/B тестирование / стресс-тест гипотезы",
        "compression": "MVP / минимальный продукт",
        "self_consistency": "product-market fit",
    },
}


def _build_bidirectional():
    """Построить обратные отображения из встроенного словаря."""
    result = dict(_BUILTIN_MAPPING)
    for k, v in list(_BUILTIN_MAPPING.items()):
        if k.startswith("iac_to_") and not k.replace("iac_to_", "to_iac_") in result:
            target = k.split("_to_")[1]
            reverse_key = f"{target}_to_iac"
            result[reverse_key] = {val: key for key, val in v.items()}
    return result


_FULL_MAPPING = _build_bidirectional()


def _get_domain_pair(source: str, target: str) -> str:
    """Получить ключ пары доменов."""
    key = f"{source}_to_{target}"
    if key in _FULL_MAPPING:
        return key
    if key in _TRANSLATIONS.get("mappings", {}):
        return key
    return ""


def translate_concept(concept: str, source_domain: str, target_domain: str) -> str:
    """
    Перевести понятие из одного домена в другой.
    Сначала проверяет пользовательские соответствия, затем встроенные.
    """
    key = f"{source_domain}_to_{target_domain}"
    
    # Проверить пользовательские
    user_map = _TRANSLATIONS.get("mappings", {}).get(key, {})
    if concept.lower() in {k.lower(): v for k, v in user_map.items()}:
        return user_map.get(concept.lower(), concept)
    
    # Проверить встроенные
    builtin = _FULL_MAPPING.get(key, {})
    if concept.lower() in {k.lower(): v for k, v in builtin.items()}:
        return builtin.get(concept.lower(), concept)
    
    return concept


def translate_sentence(sentence: str, source_domain: str, target_domain: str) -> dict:
    """
    Перевести предложение посегментно.
    """
    words = re.findall(r'\b[\wа-яё-]+\b', sentence, re.IGNORECASE)
    translated = {}
    unchanged = []
    
    for w in words:
        tr = translate_concept(w, source_domain, target_domain)
        if tr != w:
            translated[w] = tr
        else:
            unchanged.append(w)
    
    return {
        "source_domain": source_domain,
        "target_domain": target_domain,
        "translated_terms": len(translated),
        "unchanged_terms": len(unchanged),
        "fidelity": round(
            len(translated) / len(words) if words else 0, 3
        ),
        "mapping": translated,
    }


def _evaluate_fidelity(source_text: str, translated_text: str, invariants: List[str]) -> float:
    """
    Метрика согласованности: сколько инвариантов сохранено при переводе.
    """
    if not invariants:
        return 0.5
    preserved = sum(
        1 for inv in invariants
        if inv.lower() in translated_text.lower()
    )
    return round(preserved / len(invariants), 3)


# ----------------------------------------------------------------
# Tool-функции
# ----------------------------------------------------------------

def tool_translate(text: str, source_domain: str = "iac", target_domain: str = "intuition") -> str:
    """
    Перевести текст из одного домена в другой.
    
    Доступные домены: iac, intuition, business, natural, mathematical
    
    Args:
        text: текст для перевода
        source_domain: исходный домен
        target_domain: целевой домен
    
    Returns:
        JSON: результат перевода
    """
    result = translate_sentence(text, source_domain, target_domain)
    
    # Применить перевод к тексту
    translated_text = text
    for src, dst in result["mapping"].items():
        translated_text = translated_text.replace(src, dst)
    
    result["source_text"] = text[:300]
    result["translated_text"] = translated_text[:500]
    
    return json.dumps(result, ensure_ascii=False, indent=2)


def tool_translate_batch(texts_json: str, source_domain: str = "iac", target_domain: str = "intuition") -> str:
    """
    Перевести пакет текстов.
    
    Args:
        texts_json: JSON-массив строк
        source_domain: исходный домен
        target_domain: целевой домен
    
    Returns:
        JSON: массив результатов
    """
    try:
        texts = json.loads(texts_json)
    except:
        return json.dumps({"error": "invalid JSON array"})
    
    results = [
        translate_sentence(t, source_domain, target_domain)
        for t in texts
    ]
    
    avg_fidelity = sum(r["fidelity"] for r in results) / len(results) if results else 0
    
    return json.dumps({
        "count": len(results),
        "average_fidelity": round(avg_fidelity, 3),
        "results": results,
    }, ensure_ascii=False, indent=2)


def tool_translate_mapping(action: str = "list", key: str = "", mapping_json: str = "") -> str:
    """
    Управление пользовательскими соответствиями.
    
    Args:
        action: "list" | "add" | "remove" | "builtin"
        key: ключ пары доменов (напр. "iac_to_intuition")
        mapping_json: JSON-объект {слово: перевод} при action="add"
    
    Returns:
        JSON
    """
    if action == "list":
        user_maps = _TRANSLATIONS.get("mappings", {})
        return json.dumps({
            "user_mappings": len(user_maps),
            "pairs": list(user_maps.keys()),
            "builtin_pairs": list(_FULL_MAPPING.keys()),
        }, ensure_ascii=False, indent=2)

    if action == "builtin":
        pair = _FULL_MAPPING.get(key, {})
        return json.dumps({
            "key": key,
            "entries": len(pair),
            "mapping": pair,
        }, ensure_ascii=False, indent=2)

    if action == "add" and key and mapping_json:
        try:
            mapping = json.loads(mapping_json)
            _TRANSLATIONS.setdefault("mappings", {})
            _TRANSLATIONS["mappings"].setdefault(key, {})
            _TRANSLATIONS["mappings"][key].update(mapping)
            _save_translations(_TRANSLATIONS)
            return json.dumps({"status": "added", "count": len(mapping), "key": key})
        except:
            return json.dumps({"error": "invalid mapping JSON"})

    if action == "remove" and key:
        _TRANSLATIONS.setdefault("mappings", {})
        _TRANSLATIONS["mappings"].pop(key, None)
        _save_translations(_TRANSLATIONS)
        return json.dumps({"status": "removed", "key": key})

    return json.dumps({"error": "invalid action or missing parameters"})


def tool_translate_domains(action: str = "list", domain_json: str = "") -> str:
    """
    Управление доменами перевода.
    
    Args:
        action: "list" | "add" | "remove"
        domain_json: JSON-описание домена
    
    Returns:
        JSON
    """
    if action == "list":
        domains = dict(_TRANSLATIONS.get("domains", {}))
        # Добавить встроенные домены
        builtin_domains = {
            "iac": "Invariant Adaptive Core — formal system concepts",
            "intuition": "Интуитивный человеческий язык, образы, метафоры",
            "business": "Бизнес-термины, стратегия, продукты",
            "natural": "Естественно-научная терминология",
            "mathematical": "Математические и формальные определения",
        }
        domains.update(builtin_domains)
        return json.dumps({"domains": domains}, ensure_ascii=False, indent=2)

    if action == "add" and domain_json:
        try:
            domain = json.loads(domain_json)
            name = domain.pop("name", "")
            if name:
                _TRANSLATIONS.setdefault("domains", {})
                _TRANSLATIONS["domains"][name] = domain.get("description", "")
                _save_translations(_TRANSLATIONS)
                return json.dumps({"status": "added", "name": name})
        except:
            pass
        return json.dumps({"error": "invalid domain JSON"})

    if action == "remove":
        name = domain_json.strip()
        _TRANSLATIONS["domains"].pop(name, None)
        _save_translations(_TRANSLATIONS)
        return json.dumps({"status": "removed", "name": name})

    return json.dumps({"error": "invalid action"})


def tool_translate_evaluate(source_text: str, translated_text: str, invariants_json: str = "[]") -> str:
    """
    Оценить качество перевода по сохранению инвариантов.
    
    Args:
        source_text: исходный текст
        translated_text: переведённый текст
        invariants_json: JSON-массив строк-инвариантов
    
    Returns:
        JSON: оценка fidelity
    """
    try:
        invariants = json.loads(invariants_json)
    except:
        invariants = []

    fidelity = _evaluate_fidelity(source_text, translated_text, invariants)
    
    return json.dumps({
        "fidelity": fidelity,
        "interpretation": (
            "perfect" if fidelity >= 0.95 else
            "high" if fidelity >= 0.8 else
            "moderate" if fidelity >= 0.6 else
            "low" if fidelity >= 0.4 else
            "lost_in_translation"
        ),
        "invariants_checked": len(invariants),
        "invariants_preserved": round(fidelity * len(invariants)),
    }, ensure_ascii=False, indent=2)


def tool_translate_status() -> str:
    """Статус Translation Architecture."""
    user_maps = _TRANSLATIONS.get("mappings", {})
    user_domains = _TRANSLATIONS.get("domains", {})
    history = _TRANSLATIONS.get("history", [])[-10:]
    
    total_entries = sum(len(m) for m in user_maps.values())
    
    return json.dumps({
        "builtin_pairs": len(_FULL_MAPPING),
        "user_pairs": len(user_maps),
        "user_entries": total_entries,
        "user_domains": len(user_domains),
        "available_domains": list(set(
            list({k.split("_to_")[0] for k in _FULL_MAPPING}) +
            list({k.split("_to_")[1] for k in _FULL_MAPPING}) +
            list(user_domains.keys())
        )),
        "recent_history": history,
    }, ensure_ascii=False, indent=2)
