import logging
import os
import sys
from pathlib import Path

# Добавляем корень проекта в PYTHONPATH
sys.path.append(str(Path(__file__).parent.parent))

import ffmpeg
from telegram import Update
from telegram.ext import Application, filters, MessageHandler
from tools import tool
import tempfile
import requests
import speech_recognition as sr

logger = logging.getLogger(__name__)

# Конфигурация из переменных окружения
TELEGRAM_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '8988705192:AAF3daTnloM_7HpD5hX35MvuCLMkO1LIG6M')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '398754794')
WHISPER_API_KEY = ""

application = None

@tool(name="telegram_start_listener")
def telegram_start_listener():
    """Запускает асинхронного слушателя Telegram"""
    global application
    if application:
        try:
            application.stop()
            application = None
            logger.info("Предыдущий слушатель остановлен")
        except Exception as e:
            logger.error(f"Ошибка остановки: {e}")
    
    try:
        application = Application.builder().token(TELEGRAM_TOKEN).build()
        application.add_handler(MessageHandler(filters.VOICE, handle_voice))
        application.run_polling()
        return "Слушатель Telegram запущен"
    except Exception as e:
        logger.error(f"Ошибка запуска: {e}")
        return f"Ошибка: {e}"

async def handle_voice(update: Update, context):
    """Обработка входящих голосовых сообщений"""
    user_id = update.message.from_user.id
    voice = update.message.voice
    
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as temp_voice:
        temp_path = temp_voice.name
        
    voice_file = await voice.get_file()
    await voice_file.download_to_drive(destination=temp_path)
    
    transcript = transcribe_audio(temp_path)
    
    if transcript:
        save_to_memory(user_id, transcript)
        await update.message.reply_text(f"🔮 Инсайд сохранён:\n{transcript[:200]}")
        logger.info(f"Сохранён инсайд от {user_id}")
    else:
        await update.message.reply_text("❌ Ошибка расшифровки")

def transcribe_audio(file_path: str) -> str:
    """Транскрибация аудио через Google Speech Recognition"""
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(file_path) as source:
            audio_data = recognizer.record(source)
            return recognizer.recognize_google(audio_data, language='ru-RU')
    except sr.UnknownValueError:
        return "Не удалось распознать речь"
    except sr.RequestError as e:
        return f"Ошибка сервиса: {e}"
    except Exception as e:
        return f"Ошибка: {e}"

def save_to_memory(user_id: int, text: str):
    """Сохранение в MEMORY.md"""
    # Форматирование и добавление тегов
    try:
        with open("MEMORY.md", "a", encoding="utf-8") as f:
            f.write(f"\n### 🔮 TG-инсайд от <user:{user_id}>\n")
            f.write(f"```\n{text}\n```\n\n")
    except Exception as e:
        logger.error(f"Ошибка записи: {e}")