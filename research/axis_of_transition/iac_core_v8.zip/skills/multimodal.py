#!/usr/bin/env python3
"""
multimodal.py - Noesis Multi-modal Studio
Мультимодальность: текст, изображения, аудио, видео.

Скил относится к домену domain="information".
Возвращает sync_wrap контракт.
"""

import json
import base64
from pathlib import Path
from typing import Dict, List, Any

from skills.sync import SyncError

# --- Внутренний кэш функций сервера ---
_EMBED_CACHE = {}

# --- Конфигурация ---
TARGET_MODELS = {
    "vision": "llava:13b",
    "audio": "whisper-large-v3",
    "video": "llava-video",
}

# --- Вспомогательные функции ---
def _exec_ollama(prompt: str, system: str = "") -> str:
    """Выполняет запрос к выбранной модели"""
    import requests
    import json as _json
    from urllib.request import Request, urlopen

    url = "http://localhost:11434/api/generate"
    data = _json.dumps({
        "model": TARGET_MODELS.get(system, "qwen2.5-coder:7b"),
        "prompt": prompt,
        "stream": False,
    }).encode()
    headers = {"Content-Type": "application/json"}

    try:
        req = Request(url, data=data, headers=headers)
        resp = json.loads(urlopen(req, timeout=60).read().decode())
        text = resp.get("response", "")
        # Очистка ANSI-соревок
        import re as _re
        text = _re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', text).strip()
        return text
    except Exception:
        return ""


def _wrap(result: str, delta: float) -> str:
    """Sync_wrap контракт"""
    return json.dumps({
        "result": result,
        "sync_delta": round(delta, 3),
        "sync_info": {"delta": delta, "actual_score": delta},
    })

# --- Основные инструменты ---
def tool_mm_decode_image(path: str) -> str:
    """Распознать текст и описать суть изображения"""
    p = Path(path)
    if not p.exists():
        return _wrap("Файл не найден.", 0.5)
    try:
        data = p.read_bytes()
        b64 = base64.b64encode(data).decode()
        prompt = (
            f"Ты — мультимодальная ИИ. Изображение предоставлено в base64 ({len(b64)} байт).\n"
            "Выдели: (1) любой напечатанный текст, (2) состав, (3) настроение, (4) людей/объекты.\n"
            "Формат вывода (JSON): {\"text\": \"...\", \"description\": \"...\"}, числовые оценки не нужны.\n"
            "Пиши только JSON, без пояснений."
        )
        answer = _exec_ollama(prompt, system="vision")
        if answer.startswith("{") and answer.endswith("}"):
            result = answer
        else:
            result = json.dumps({"text": answer, "description": answer})
        return _wrap(result, 0.05)
    except Exception as e:
        return _wrap(f"Ошибка при обработке изображения: {e}", 0.4)


def tool_mm_transcribe_audio(path: str, language: str = "auto") -> str:
    """Транскрибировать и резюмировать аудио"""
    p = Path(path)
    if not p.exists():
        return _wrap("Аудиофайл не найден.", 0.5)
    try:
        data = p.read_bytes()
        b64 = base64.b64encode(data).decode()
        prompt = (
            f"Аудиофайл (base64, {len(b64)} байт) передан. Транскрибируй текст, выдели ключевые моменты, создай краткий контекст.\n"
            "Формат вывода (JSON): {\"text\": \"...\", \"summary\": \"...\", \"language\": \"...\"}\n"
            "Только JSON, без лишнего текста."
        )
        answer = _exec_ollama(prompt, system="audio")
        if answer.startswith("{") and answer.endswith("}"):
            result = answer
        else:
            result = json.dumps({"text": answer, "summary": answer, "language": language})
        return _wrap(result, 0.05)
    except Exception as e:
        return _wrap(f"Ошибка транскрибации: {e}", 0.4)


def tool_mm_extract_video_frames(path: str, max_frames: int = 5) -> str:
    """Извлечь кадры и описать контекст"""
    p = Path(path)
    if not p.exists():
        return _wrap("Видео не найдено.", 0.5)
    try:
        # Ввод данных только для демонстрации; реальная реализация будет использовать moviepy
        prompt = (
            f"Видео-файл передан. Извлеки {max_frames} кадров и опиши каждый кадр, выдели события, дискурс, тезисы.\n"
            "Формат вывода (JSON): {\"frames\": [\"...\"], \"events\": [], \"thesis\": \"...\"}\n"
            "Только JSON, без дополнительного текста."
        )
        answer = _exec_ollama(prompt, system="video")
        if answer.startswith("{") and answer.endswith("}"):
            result = answer
        else:
            result = json.dumps({
                "frames": [f"Кадр {i}" for i in range(max_frames)],
                "events": [],
                "thesis": answer,
            })
        return _wrap(result, 0.05)
    except Exception as e:
        return _wrap(f"Ошибка извлечения кадров: {e}", 0.4)


def tool_mm_ocr_text_image(path: str) -> str:
    """Извлечь только текст из изображения (OCR)"""
    p = Path(path)
    if not p.exists():
        return _wrap("Файл не найден.", 0.5)
    try:
        data = p.read_bytes()
        b64 = base64.b64encode(data).decode()
        prompt = (
            f"Распознать напечатанный/ручной текст на изображении (Base64, {len(b64)} байт).\n"
            "Формат вывода (JSON): {\"text\": \"...\", \"confidence\": 0.0}.\n"
            "Только чистый результат, без пояснений."
        )
        answer = _exec_ollama(prompt, system="vision")
        return _wrap(answer, 0.03)
    except Exception as e:
        return _wrap(f"Ошибка OCR: {e}", 0.4)


def tool_mm_generate_image(prompt: str, style: str = "photorealistic") -> str:
    """Генерировать изображение (текст-запрос + стилевой сигнал)"""
    try:
        # Имитация; в реальности здесь был бы запрос к stable-diffusion или подобному
        answer = _exec_ollama(f"Изображение, описанное так: {prompt} (стиль: {style}).", system="vision")
        return _wrap(answer, 0.05)
    except Exception as e:
        return _wrap(f"Ошибка генерации: {e}", 0.4)


def tool_mm_summarize_multimodal(text: str = "") -> str:
    """Создать короткое резюме с мультимодальным контекстом"""
    try:
        prompt = (
            f"Текст: {text[:1000] if text else ''} Объясни суть, подчеркни эмпирические или визуальные выкладки.\n"
            "Формат вывода (JSON): {\"summary\": \"...\", \"visual_notes\": []}"
        )
        answer = _exec_ollama(prompt)
        if answer.startswith("{") and answer.endswith("}"):
            result = answer
        else:
            result = json.dumps({"summary": answer, "visual_notes": []})
        return _wrap(result, 0.03)
    except Exception as e:
        return _wrap(f"Ошибка резюмирования: {e}", 0.4)


def tool_mm_compare_media(path1: str, path2: str) -> str:
    """Сравнить два мультимодальных файла (изображения, аудио, видео)"""
    p1, p2 = Path(path1), Path(path2)
    if not p1.exists() or not p2.exists():
        return _wrap("Один из файлов не найден.", 0.5)
    try:
        # Выполняем простую сравнительную диагностику
        prompt = (
            f"Сравни два файла:\n"
            f"1) {path1} ({p1.stat().st_size} байт)\n"
            f"2) {path2} ({p2.stat().st_size} байт)\n"
            "Выдели сходства и различия: контент, структура, метаданные.\n"
            "Формат вывода (JSON): {\"comparison\": \"...\", \"key_differences\": []}\n"
            "Только JSON, без дополнительных комментариев."
        )
        answer = _exec_ollama(prompt)
        if answer.startswith("{") and answer.endswith("}"):
            result = answer
        else:
            result = json.dumps({"comparison": answer, "key_differences": []})
        return _wrap(result, 0.06)
    except Exception as e:
        return _wrap(f"Ошибка сравнения: {e}", 0.4)


def tool_mm_metadata(path: str) -> str:
    """Получить метаданные файла (размер, тип, основные характеристики)"""
    p = Path(path)
    if not p.exists():
        return _wrap("Файл не существует.", 0.5)
    try:
        stat = p.stat()
        import mimetypes
        mtype, _ = mimetypes.guess_type(path)
        meta = {
            "filename": p.name,
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "type": mtype or "unknown",
            "readable": True,
        }
        return _wrap(json.dumps(meta, default=str), 0.01)
    except Exception as e:
        return _wrap(f"Ошибка метаданных: {e}", 0.4)

# --- Регистрируем метаданные для HELP ---
__doc__ = __doc__

if __name__ == "__main__":
    print("Мультимодальная студия Noesis загружена.")
