"""
somatic.py — SomaticPracticesEngine for IAC
Auto-detects body markers in text, recommends somatic practices.

Invariants: INV-TB-001 through INV-TB-006
All protocols automatic; manual override via tool args.

Practices: breathing, scanning, movement, grounding, centering
"""

import json
import re
import math
from datetime import datetime
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Dict, Any, Optional

STATE_FILE = Path("data/somatic_state.json")
FEEDBACK_FILE = Path("data/somatic_feedback.jsonl")


# ===== PRACTICE LIBRARY =====

PRACTICES = {
    "breathing": {
        "name": "breathing",
        "label_ru": "Дыхание 4-7-8",
        "description": "Вдох 4с → задержка 7с → выдох 8с. Снижает ЧСС, активирует парасимпатику.",
        "duration_sec": 120,
        "targets": ["anxiety", "racing_thoughts", "panic", "stress", "тревог", "паник", "стресс"],
        "mechanism": "parasympathetic_activation",
        "difficulty": "easy",
    },
    "scanning": {
        "name": "scanning",
        "label_ru": "Сканирование тела",
        "description": "Медленное внимание от макушки до пальцев ног. Замечать ощущения без оценки.",
        "duration_sec": 300,
        "targets": ["freeze", "dissociation", "numbness", "disconnect", "замирание", "онемение", "отключ"],
        "mechanism": "interoceptive_awareness",
        "difficulty": "medium",
    },
    "movement": {
        "name": "movement",
        "label_ru": "Микродвижения",
        "description": "Shake out — тряска конечностей, спонтанные движения. Сброс избыточного возбуждения.",
        "duration_sec": 180,
        "targets": ["tension", "stuck", "restless", "agitation", "напряжение", "застрял", "беспокойств"],
        "mechanism": "motor_discharge",
        "difficulty": "easy",
    },
    "grounding": {
        "name": "grounding",
        "label_ru": "Заземление 5-4-3-2-1",
        "description": "Найти 5 видимых предметов, 4 осязаемых, 3 звука, 2 запаха, 1 вкус.",
        "duration_sec": 180,
        "targets": ["overwhelm", "dissociation", "floating", "spiraling", "перегруз", "уносит", "захлёст"],
        "mechanism": "sensory_anchoring",
        "difficulty": "easy",
    },
    "centering": {
        "name": "centering",
        "label_ru": "Центрирование",
        "description": "Рука на живот, медленное дыхание диафрагмой. Ощутить центр тяжести в тазу.",
        "duration_sec": 120,
        "targets": ["scattered", "unfocused", "lost", "confusion", "разброс", "расфокус", "потерян"],
        "mechanism": "proprioceptive_center",
        "difficulty": "easy",
    },
    "pendulation": {
        "name": "pendulation",
        "label_ru": "Пендуляция (Somatic Experiencing)",
        "description": "Перемещать внимание между напряжением и нейтральной зоной. 30с туда, 30с обратно.",
        "duration_sec": 240,
        "targets": ["trauma", "triggered", "flashback", "травм", "триггер", "флэшбек"],
        "mechanism": "titration",
        "difficulty": "medium",
    },
}


# ===== SOMATIC MARKERS (auto-detection) =====

SOMATIC_PATTERNS = {
    "tension": [
        r'\b(?:напряж(?:ён|ен|ение|ена)|зажат|сжат|скован|скрючен|tension|tight|stiff|clenched)\b',
        r'\b(?:плечи\s+(?:подняты|напряжены)|челюсть\s+сжата|кулаки\s+сжаты)\b',
    ],
    "freeze": [
        r'\b(?:замер(?:ла?|ли?)|замирание|ступор|оцепенение|freeze|frozen|stuck|paraly[sz]ed)\b',
        r'\b(?:не\s+могу\s+(?:двигаться|пошевелиться)|не\s+двигается)\b',
    ],
    "anxiety": [
        r'\b(?:тревог[аиуое]|тревож(?:ный|но|ное|ная)|anxiety|anxious|worry|worried|panic)\b',
        r'\b(?:сердце\s+(?:колотится|стучит|выпрыгивает)|учащ(?:ён|ен)ное\s+сердцебиение)\b',
        r'\b(?:накры(?:ло|вает|л[аои]?)\s+(?:тревог|паник|волн))\b',
    ],
    "dissociation": [
        r'\b(?:диссоциация|отключ(?:ён|ен|ился)|dissociat|disconnect|numb|out\s+of\s+body)\b',
        r'\b(?:как\s+будто.*не\s+я|наблюдаю.*со\s+стороны|не\s+чувствую\s+тел[ао])\b',
        r'\b(?:онеме(?:л[аои]?|ние)|онемевш|оцепене(?:л[аои]?|ние)|дереализаци)\b',
    ],
    "overwhelm": [
        r'\b(?:перегруз(?:ка|жен)|захлёст|overwhelm|flooded|too\s+much|drowning)\b',
        r'\b(?:слишком\s+много|не\s+справляюсь|не\s+вывожу)\b',
        r'\b(?:накры(?:ло|вает|л[аои]?))\b',
    ],
    "stress": [
        r'\b(?:стресс|stress(?:ed)?|выгорание|burnout|exhaust(?:ed|ion)|измот(?:ан|ал))\b',
        r'\b(?:нет\s+сил|устал[аои]?|нет\s+энергии|утомл(?:ён|ен)|усталость)\b',
    ],
    "body_signal": [
        r'\b(?:тело|body|somatic|соматик|ощущение\s+в\s+теле|физическ(?:ое|ий|ая))\b',
        r'\b(?:живот|грудь|горло|спина|плечи|челюсть|руки|ноги)\b',
        r'\b(?:дыхание|breath|сердцебиение|heartbeat|пульс|pulse)\b',
    ],
    "trauma": [
        r'\b(?:травм(?:а|атическ|ирован)|trauma(?:tic|tized)?)\b',
        r'\b(?:триггер(?:нуло|ит|ят)?|trigger(?:ed|ing)?)\b',
        r'\b(?:флэшбек|flashback|воспоминание\s+(?:накрыло|захлестнуло))\b',
    ],
}


def _detect_markers(text: str) -> Dict[str, List[Dict]]:
    """Scan text for somatic body markers. Returns grouped findings."""
    if not text or len(text) < 10:
        return {}

    text_lower = text.lower()
    found = defaultdict(list)

    for category, patterns in SOMATIC_PATTERNS.items():
        for pat in patterns:
            for m in re.finditer(pat, text, re.IGNORECASE):
                found[category].append({
                    "marker": m.group(0),
                    "position": m.start(),
                    "context": text[max(0, m.start() - 30):m.end() + 30].strip(),
                    "category": category,
                })

    # Deduplicate
    for cat in found:
        seen = set()
        unique = []
        for f in found[cat]:
            key = (f["position"], f["marker"])
            if key not in seen:
                seen.add(key)
                unique.append(f)
        found[cat] = unique

    return dict(found)


def _calculate_intensity(markers: Dict) -> float:
    """Calculate somatic activation intensity 0..1."""
    if not markers:
        return 0.0

    # Weight by category severity
    weights = {
        "freeze": 0.9,
        "trauma": 0.9,
        "dissociation": 0.85,
        "anxiety": 0.8,
        "overwhelm": 0.75,
        "tension": 0.6,
        "stress": 0.5,
        "body_signal": 0.3,
    }

    total_weight = 0.0
    total_count = 0
    for cat, findings in markers.items():
        w = weights.get(cat, 0.5)
        total_weight += w * len(findings)
        total_count += len(findings)

    if total_count == 0:
        return 0.0

    base = total_weight / max(1, total_count)
    # Bonus for multiple categories (complex activation)
    category_bonus = min(0.3, (len(markers) - 1) * 0.1)
    return round(min(1.0, base + category_bonus), 3)


def _match_practices(markers: Dict, intensity: float) -> List[Dict]:
    """Match detected markers to best-fit practices."""
    if not markers:
        return []

    active_targets = set()
    for cat in markers:
        active_targets.add(cat)

    scored = []
    for pid, practice in PRACTICES.items():
        targets = practice["targets"]
        # How many of our markers match this practice's targets
        hits = 0
        for t in targets:
            if any(t in cat for cat in active_targets):
                hits += 1

        # Also check text overlap
        for cat in active_targets:
            if cat in targets or any(cat in t for t in targets):
                hits += 1

        base_score = hits / max(1, len(targets) * 0.5)
        # Intensity bonus: higher intensity → easier practices preferred
        if intensity > 0.7 and practice["difficulty"] == "easy":
            base_score += 0.2
        elif intensity < 0.4 and practice["difficulty"] == "medium":
            base_score += 0.1

        score = round(min(1.0, base_score), 3)
        scored.append({
            "practice_id": pid,
            "practice": practice["label_ru"],
            "score": score,
            "duration_sec": practice["duration_sec"],
            "mechanism": practice["mechanism"],
            "difficulty": practice["difficulty"],
        })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return [s for s in scored if s["score"] > 0.2]


# ===== PERSONALIZATION STATE =====

_PERSONAL_STATE: Dict = {
    "user_profile": {},      # user_id → {preferences, history}
    "feedback_log": [],      # recent feedback entries
    "effectiveness": {},     # practice_id → {avg_effectiveness, count}
    "last_practice": "",     # last recommended practice
    "sessions_count": 0,
}


def _load_state():
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            _PERSONAL_STATE.update(data)
        except:
            pass


def _save_state():
    STATE_FILE.parent.mkdir(exist_ok=True)
    STATE_FILE.write_text(json.dumps(_PERSONAL_STATE, ensure_ascii=False, indent=2), encoding="utf-8")


_load_state()


def _apply_feedback_learning(practice_id: str, effectiveness: float):
    """Learn from feedback: update effectiveness scores."""
    eff = _PERSONAL_STATE["effectiveness"]
    if practice_id not in eff:
        eff[practice_id] = {"avg_effectiveness": 0.0, "count": 0}

    e = eff[practice_id]
    n = e["count"] + 1
    e["avg_effectiveness"] = round((e["avg_effectiveness"] * e["count"] + effectiveness) / n, 3)
    e["count"] = n

    # Log feedback
    _PERSONAL_STATE["feedback_log"].append({
        "practice_id": practice_id,
        "effectiveness": effectiveness,
        "time": datetime.now().strftime('%H:%M'),
    })
    _PERSONAL_STATE["feedback_log"] = _PERSONAL_STATE["feedback_log"][-50:]
    _save_state()


def _personalize_practices(scored: List[Dict]) -> List[Dict]:
    """Adjust scores based on learned effectiveness."""
    eff = _PERSONAL_STATE["effectiveness"]
    for s in scored:
        pid = s["practice_id"]
        if pid in eff and eff[pid]["count"] >= 2:
            # Boost effective practices, penalize ineffective ones
            adjustment = (eff[pid]["avg_effectiveness"] - 0.5) * 0.3
            s["score"] = round(min(1.0, max(0.05, s["score"] + adjustment)), 3)
            s["personalized"] = True
            s["learned_effectiveness"] = eff[pid]["avg_effectiveness"]

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored


# ===== TOOL FUNCTIONS =====

def tool_somatic_detect(text: str) -> str:
    """
    Detect somatic body markers in text.
    Returns markers grouped by category with intensity score.

    Args:
        text: Input text to scan for body signals
    """
    markers = _detect_markers(text)
    intensity = _calculate_intensity(markers)
    practices = _match_practices(markers, intensity)
    practices = _personalize_practices(practices)

    # Summarize by category
    by_category = {cat: len(f) for cat, f in markers.items()}

    return json.dumps({
        "somatic_detected": len(markers) > 0,
        "intensity": intensity,
        "level": (
            "critical" if intensity > 0.7 else
            "high" if intensity > 0.5 else
            "moderate" if intensity > 0.3 else
            "low" if intensity > 0.1 else
            "none"
        ),
        "categories_found": by_category,
        "markers": {cat: [m["marker"] for m in f[:3]] for cat, f in markers.items()} if markers else {},
        "recommended_practices": practices[:3],
        "detected_at": datetime.now().isoformat(),
    }, ensure_ascii=False, indent=2)


def tool_somatic_recommend(markers_json: str = "", text: str = "") -> str:
    """
    Recommend best somatic practice for given markers or text.

    Args:
        markers_json: JSON string with pre-detected markers (optional)
        text: Raw text to auto-detect from (used if no markers_json)
    """
    if markers_json:
        try:
            markers = json.loads(markers_json)
        except:
            return json.dumps({"error": "invalid_markers_json"})
        intensity = _calculate_intensity(markers)
    elif text:
        markers = _detect_markers(text)
        intensity = _calculate_intensity(markers)
    else:
        return json.dumps({"error": "no_input"})

    practices = _match_practices(markers, intensity)
    practices = _personalize_practices(practices)

    top = practices[0] if practices else None
    if top:
        _PERSONAL_STATE["last_practice"] = top["practice_id"]

    return json.dumps({
        "intensity": intensity,
        "top_recommendation": top,
        "alternatives": practices[1:3] if len(practices) > 1 else [],
        "rationale": (
            f"Intensity {intensity:.2f}: {top['mechanism']}" if top
            else "No somatic markers detected"
        ),
    }, ensure_ascii=False, indent=2)


def tool_somatic_apply(text: str = "", user_id: str = "") -> str:
    """
    Full pipeline: detect → recommend → prepare practice instruction.
    Auto-mode: no manual input needed.

    Args:
        text: Text to analyze
        user_id: Optional user ID for personalization
    """
    if not text:
        return json.dumps({
            "action": "scan",
            "recommendation": "Provide text or context for somatic analysis.",
        })

    detect = json.loads(tool_somatic_detect(text))
    if not detect["somatic_detected"]:
        return json.dumps({
            "somatic_detected": False,
            "action": "none",
            "message": "No body markers found in text.",
        })

    practices = detect.get("recommended_practices", [])
    if not practices:
        return json.dumps(detect)

    top_practice_id = practices[0]["practice_id"]
    practice = PRACTICES.get(top_practice_id, PRACTICES["grounding"])

    # Build practice session
    session = {
        "practice_id": top_practice_id,
        "practice_name": practice["label_ru"],
        "duration_sec": practice["duration_sec"],
        "instructions": {
            "setup": f"Find a comfortable position. Take one natural breath.",
            "main": practice["description"],
            "close": "Notice how your body feels now. One more breath.",
        },
        "mechanism": practice["mechanism"],
        "personalized": practices[0].get("personalized", False),
        "effectiveness": practices[0].get("learned_effectiveness"),
        "intensity": detect["intensity"],
        "session_id": f"sess_{datetime.now().strftime('%H%M%S')}",
    }

    _PERSONAL_STATE["sessions_count"] += 1
    _PERSONAL_STATE["last_practice"] = top_practice_id
    _save_state()

    return json.dumps({
        "somatic_detected": True,
        "intensity": detect["intensity"],
        "session": session,
        "alternatives": [p["practice_id"] for p in practices[1:3]],
    }, ensure_ascii=False, indent=2)


def tool_somatic_feedback(practice_id: str = "", effectiveness: float = 0.5, note: str = "") -> str:
    """
    Record feedback on practice effectiveness for learning.
    0 = ineffective, 1 = highly effective.

    Args:
        practice_id: Which practice was used
        effectiveness: 0..1 rating
        note: Optional text note
    """
    if not practice_id:
        practice_id = _PERSONAL_STATE.get("last_practice", "")
    if not practice_id:
        return json.dumps({"error": "no_practice_to_rate"})

    _apply_feedback_learning(practice_id, max(0.0, min(1.0, effectiveness)))

    # Log to feedback file
    FEEDBACK_FILE.parent.mkdir(exist_ok=True)
    with open(FEEDBACK_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps({
            "practice_id": practice_id,
            "effectiveness": effectiveness,
            "note": note[:200],
            "time": datetime.now().isoformat(),
        }, ensure_ascii=False) + "\n")

    eff = _PERSONAL_STATE["effectiveness"].get(practice_id, {})
    return json.dumps({
        "recorded": True,
        "practice_id": practice_id,
        "effectiveness": effectiveness,
        "learned_avg": eff.get("avg_effectiveness", effectiveness),
        "total_feedback": eff.get("count", 1),
        "all_effectiveness": _PERSONAL_STATE["effectiveness"],
    }, ensure_ascii=False, indent=2)


def tool_somatic_status() -> str:
    """Show SomaticPracticesEngine state: sessions, effectiveness, profile."""
    return json.dumps({
        "sessions_count": _PERSONAL_STATE["sessions_count"],
        "last_practice": _PERSONAL_STATE.get("last_practice", ""),
        "practices_learned": len(_PERSONAL_STATE["effectiveness"]),
        "effectiveness": _PERSONAL_STATE["effectiveness"],
        "recent_feedback": _PERSONAL_STATE["feedback_log"][-5:],
        "available_practices": list(PRACTICES.keys()),
    }, ensure_ascii=False, indent=2)


def tool_somatic_reset() -> str:
    """Reset all somatic learning state."""
    _PERSONAL_STATE["effectiveness"] = {}
    _PERSONAL_STATE["feedback_log"] = []
    _PERSONAL_STATE["last_practice"] = ""
    _PERSONAL_STATE["sessions_count"] = 0
    _save_state()
    return json.dumps({"reset": True, "message": "Somatic state cleared"})