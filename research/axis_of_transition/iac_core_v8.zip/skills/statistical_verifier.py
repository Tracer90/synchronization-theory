"""
statistical_verifier.py — StatisticalVerifier for IAC
Auto-verifies patterns for statistical significance (INV-024-030).

Protocol: pattern → bootstrap → p-value → significance decision.
Runs automatically; no manual UI needed.
"""

import json
import math
import random
import re
from datetime import datetime
from collections import Counter
from pathlib import Path
from typing import List, Dict, Any, Tuple

PATTERNS_FILE = Path("sync_patterns.json")
MEMORY_FILE = Path("MEMORY.md")


def _bootstrap_p_value(observed_stat: float, null_distribution: List[float]) -> float:
    """Calculate two-sided p-value from bootstrap null distribution."""
    if len(null_distribution) < 10:
        return 1.0

    # Count how many null stats are at least as extreme as observed
    more_extreme = sum(1 for x in null_distribution if abs(x) >= abs(observed_stat))
    return round(more_extreme / len(null_distribution), 4)


def _generate_null_distribution(data: List[float], statistic_fn, n_bootstrap: int = 1000) -> List[float]:
    """Generate null distribution by shuffling/permuting data."""
    if len(data) < 5:
        return []

    null_stats = []
    for _ in range(min(n_bootstrap, len(data) * 10)):
        shuffled = random.sample(data, len(data))
        null_stats.append(statistic_fn(shuffled))

    return null_stats


def _autocorrelation_statistic(data: List[float], lag: int = 1) -> float:
    """Autocorrelation at given lag."""
    if len(data) < lag + 2:
        return 0.0
    mean = sum(data) / len(data)
    num = sum((data[i] - mean) * (data[i + lag] - mean) for i in range(len(data) - lag))
    den = sum((x - mean) ** 2 for x in data)
    return num / den if den > 0 else 0.0


def _is_fibonacci(x: float, tolerance: float = 0.05) -> Tuple[bool, float, int]:
    """Check if number is near a Fibonacci number."""
    fib = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765]
    best_dist = float('inf')
    best_idx = 0
    for i, f in enumerate(fib):
        if f == 0:
            continue
        dist = abs((x / f) - 1.0)
        if dist < best_dist:
            best_dist = dist
            best_idx = i
    return best_dist < tolerance, round(best_dist, 4), best_idx


def _is_power_of_two(x: float, tolerance: float = 0.1) -> Tuple[bool, float]:
    """Check if number is near a power of 2."""
    if x <= 0:
        return False, 1.0
    log2 = math.log2(x)
    nearest_int = round(log2)
    dist = abs(log2 - nearest_int)
    return dist < tolerance, round(dist, 4)


def _parse_number_from_label(label: str) -> float:
    """Extract the numeric value from a label like '7 (days of week)' or 'closest: 56'."""
    if not label:
        return 1.0
    m = re.match(r'(?:best:|closest:)?\s*([\d.]+)', label)
    return float(m.group(1)) if m else 1.0


def _is_sacred_number(x: float, tolerance: float = 0.05) -> Tuple[bool, str]:
    """Check against known sacred/cultural numbers."""
    sacred = {
        3: "trinity, synthesis",
        7: "days of week, perfection",
        10: "decimal system, commandments",
        12: "zodiac, hours, tribes",
        40: "testing period (flood, desert)",
        56: "Saros eclipse cycle (years)",
        60: "Babylonian base, minutes",
        72: "precession degree span",
        108: "sacred in Hinduism/Buddhism",
        360: "circle degrees",
        432: "cosmic cycle (Kali Yuga)",
    }
    best_dist = float('inf')
    best_label = ""
    best_n = 0
    for n, label in sacred.items():
        if n == 0:
            continue
        dist = abs((x / n) - 1.0)
        if dist < best_dist:
            best_dist = dist
            best_label = label
            best_n = n
    return best_dist < tolerance, f"{best_n} ({best_label})"


def _is_astronomical_cycle(x: float, tolerance: float = 0.03) -> Tuple[bool, str]:
    """Check against known astronomical cycles."""
    cycles = {
        1.0: "year",
        18.6: "lunar nodal precession (years)",
        29.5: "synodic month (days)",
        56: "Saros visibility cycle (years)",
        223: "Saros (synodic months)",
        19: "Metonic cycle (years)",
        11.0: "solar activity cycle (years)",
        25.8: "axial precession (K years)",
        230: "Cheops base (meters)",
        146: "Cheops height (meters)",
    }
    best_dist = float('inf')
    best_label = ""
    best_n = 0
    for n, label in cycles.items():
        if n == 0:
            continue
        dist = abs((x / n) - 1.0)
        if dist < best_dist:
            best_dist = dist
            best_label = label
            best_n = n
    return best_dist < tolerance, f"{best_n} ({best_label})"


def _log_perception(x: float) -> Dict:
    """Weber-Fechner law: perceived magnitude ∝ log(actual)."""
    if x <= 0:
        return {"perceived": 0, "scale": "linear"}
    perceived = math.log10(x)
    return {
        "actual": x,
        "perceived_log": round(perceived, 3),
        "scale": "linear" if x < 10 else "logarithmic" if x < 1000 else "cosmic",
    }


def tool_statistical_verify(pattern_json: str, context_json: str = "") -> str:
    """
    Verify pattern significance via bootstrap test.
    
    Args:
        pattern_json: JSON with pattern data {value, context, domain}
        context_json: Optional JSON with null distribution data
    
    Returns:
        JSON: {p_value, is_significant, robustness, verdict}
    """
    try:
        pattern = json.loads(pattern_json) if pattern_json else {}
    except:
        pattern = {"value": 0, "context": pattern_json}

    data_points = pattern.get("data", [])
    value = pattern.get("value", 0)
    context = pattern.get("context", "")

    result = {
        "p_value": 1.0,
        "is_significant": False,
        "robustness": 0.0,
        "verdict": "untested",
        "tested_at": datetime.now().isoformat(),
    }

    # 1. If we have data points, bootstrap
    if isinstance(data_points, list) and len(data_points) >= 5:
        data = [float(x) for x in data_points if isinstance(x, (int, float)) or (
            isinstance(x, str) and x.replace('.', '', 1).replace('-', '', 1).isdigit())]
        data = [float(x) if isinstance(x, str) else x for x in data_points if isinstance(x, (int, float, str)) and (
            not isinstance(x, str) or x.replace('.', '', 1).replace('-', '', 1).isdigit())]
        data = [float(x) if isinstance(x, str) else x for x in data_points
                if (isinstance(x, (int, float))) or
                (isinstance(x, str) and x.replace('.', '', 1).replace('-', '', 1).isdigit())]

        if len(data) >= 5:
            obs_stat = _autocorrelation_statistic(data, lag=1)
            null_dist = _generate_null_distribution(data, _autocorrelation_statistic, n_bootstrap=500)
            p_value = _bootstrap_p_value(obs_stat, null_dist)
            result["p_value"] = p_value
            result["is_significant"] = p_value < 0.05
            result["observed_statistic"] = round(obs_stat, 4)
            result["bootstrap_samples"] = len(null_dist)

    # 2. Number pattern analysis
    if isinstance(value, (int, float)) and value > 0:
        num_analysis = tool_number_analyze(str(value), "")
        num_result = json.loads(num_analysis)
        result["number_analysis"] = num_result
        if num_result.get("patterns"):
            result["robustness"] = round(num_result.get("confidence", 0.5), 3)

    # 3. Cross-reference with memory (automatic)
    if MEMORY_FILE.exists():
        memory = MEMORY_FILE.read_text(encoding="utf-8").lower()
        pattern_text = str(context or value).lower()
        pattern_words = set(pattern_text.split())
        memory_words = set(memory.split())
        overlap = len(pattern_words & memory_words) / max(1, len(pattern_words))
        result["memory_overlap"] = round(overlap, 3)
        result["robustness"] = round(max(result["robustness"], overlap * 0.5), 3)

    # 4. Verdict
    if result["is_significant"]:
        result["verdict"] = "confirmed_statistically"
    elif result["robustness"] > 0.5:
        result["verdict"] = "plausible_hypothesis"
    elif result["p_value"] < 0.1:
        result["verdict"] = "borderline_significant"
    else:
        result["verdict"] = "insufficient_evidence"

    return json.dumps(result, ensure_ascii=False, indent=2)


def tool_number_analyze(numbers: str, mode: str = "auto") -> str:
    """
    Analyze numbers for known patterns (Fibonacci, binary, sacred, astronomical).

    Args:
        numbers: Comma/space-separated numbers or single value
        mode: "auto" | "fibonacci" | "binary" | "sacred" | "astronomical" | "perception"

    Returns:
        JSON: list of detected NumberPatterns
    """
    try:
        values = [float(x.strip()) for x in re.split(r'[,;\s]+', numbers) if x.strip()]
    except:
        pass

    if not values:
        try:
            values = [float(numbers)]
        except:
            numeric = [float(x) for x in re.findall(r'\d+(?:\.\d+)?', str(numbers))]
            values = numeric

    if not values:
        return json.dumps({"error": "no_numbers_found", "input": str(numbers)[:50]})

    patterns = []
    confidence = 0.0

    for v in values:
        if v <= 0:
            continue

        checks = []

        if mode in ("auto", "fibonacci"):
            is_fib, fib_dist, fib_idx = _is_fibonacci(v)
            if is_fib:
                checks.append({
                    "type": "fibonacci",
                    "value": v,
                    "confidence": round(1.0 - fib_dist, 3),
                    "fib_index": fib_idx,
                    "relation_to_phi": round(v / max(1, (1.618 ** fib_idx)), 3),
                })

        if mode in ("auto", "binary"):
            is_pow2, pow2_dist = _is_power_of_two(v)
            if is_pow2:
                checks.append({
                    "type": "binary",
                    "value": v,
                    "confidence": round(1.0 - pow2_dist, 3),
                    "power_of_2": f"2^{round(math.log2(v))}",
                })

        if mode in ("auto", "sacred"):
            is_sacred, sacred_label = _is_sacred_number(v)
            sacred_n = _parse_number_from_label(sacred_label)
            confidence_adj = round(1.0 - abs((v / max(1, sacred_n)) - 1.0), 3)
            checks.append({
                "type": "cultural",
                "value": v,
                "confidence": max(0.3, confidence_adj),
                "match": sacred_label,
                "is_match": is_sacred,
            })

        if mode in ("auto", "astronomical"):
            is_astro, astro_label = _is_astronomical_cycle(v)
            astro_n = _parse_number_from_label(astro_label)
            checks.append({
                "type": "cyclical",
                "value": v,
                "confidence": round(max(0.3, 1.0 - abs((v / max(1, astro_n)) - 1.0)), 3),
                "match": astro_label,
                "is_match": is_astro,
            })

        if mode in ("auto", "perception"):
            perception = _log_perception(v)
            checks.append({
                "type": "perception",
                "value": v,
                "confidence": 0.8,
                "perception_scale": perception["scale"],
                "log_value": perception["perceived_log"],
            })

        patterns.extend(checks)

    # Sort by confidence descending
    patterns.sort(key=lambda x: x["confidence"], reverse=True)

    # Overall confidence = average of top matches
    if patterns:
        confidence = round(sum(p["confidence"] for p in patterns[:3]) / min(3, len(patterns)), 3)

    # Summary by type
    by_type = {}
    for p in patterns:
        t = p["type"]
        by_type[t] = by_type.get(t, 0) + 1

    return json.dumps({
        "values_analyzed": len(values),
        "patterns_found": len(patterns),
        "confidence": confidence,
        "by_type": by_type,
        "top_patterns": patterns[:10],
    }, ensure_ascii=False, indent=2)


def tool_reversible_process(text: str, mode: str = "compare") -> str:
    """
    ReversibleProcessor: analyze text in both directions, return best result.
    
    Args:
        text: Input text
        mode: "compare" | "forward" | "reverse"
    
    Returns:
        JSON: comparison result with recommended direction
    """
    if not text or len(text) < 30:
        return json.dumps({"error": "insufficient_text"})

    tokens = [w for w in text.lower().split() if len(w) > 2]

    if len(tokens) < 15:
        return json.dumps({
            "recommended": "forward",
            "reason": "too_few_tokens",
            "confidence": 0.3,
        })

    # Forward token entropy
    fw_freq = Counter(tokens)
    fw_total = len(tokens)
    fw_entropy = -sum((c / fw_total) * math.log2(c / fw_total) for c in fw_freq.values() if c > 0)

    # Reverse
    rev_tokens = list(reversed(tokens))
    rv_freq = Counter(rev_tokens)
    rv_total = len(rev_tokens)
    rv_entropy = -sum((c / rv_total) * math.log2(c / rv_total) for c in rv_freq.values() if c > 0)

    # Token uniqueness
    fw_unique = len(fw_freq)
    rv_unique = len(rv_freq)
    unique_ratio = rv_unique / max(1, fw_unique)

    # Pattern count: how many recurring n-grams in each direction
    def count_ngrams(tokens_list, n=3):
        if len(tokens_list) < n:
            return 0
        ngrams = [tuple(tokens_list[i:i + n]) for i in range(len(tokens_list) - n + 1)]
        freq = Counter(ngrams)
        return sum(1 for v in freq.values() if v >= 2)

    fw_patterns = count_ngrams(tokens, 3)
    rv_patterns = count_ngrams(rev_tokens, 3)

    # Decision
    entropy_advantage = fw_entropy - rv_entropy
    pattern_advantage = rv_patterns - fw_patterns
    unique_advantage = 1.0 - unique_ratio

    score_forward = 0.0
    score_reverse = 0.0

    if entropy_advantage > 0.1:
        score_reverse += 0.3
    else:
        score_forward += 0.1

    if pattern_advantage > 0:
        score_reverse += 0.3
    else:
        score_forward += 0.1

    if unique_ratio < 0.9:
        score_reverse += 0.2
    else:
        score_forward += 0.1

    # Default bias toward forward
    score_forward += 0.3

    recommended = "reverse" if score_reverse > score_forward else "forward"
    confidence = round(abs(score_reverse - score_forward) + 0.3, 3)

    reason = []
    if entropy_advantage > 0.1:
        reason.append("reverse_has_lower_entropy")
    if pattern_advantage > 0:
        reason.append(f"reverse_shows_{pattern_advantage}_more_patterns")
    if unique_ratio < 0.9:
        reason.append("reverse_consolidates_tokens")

    return json.dumps({
        "recommended": recommended,
        "confidence": min(1.0, confidence),
        "reason": " | ".join(reason) or "default_forward",
        "forward": {
            "entropy": round(fw_entropy, 3),
            "unique_tokens": fw_unique,
            "ngram_patterns": fw_patterns,
        },
        "reverse": {
            "entropy": round(rv_entropy, 3),
            "unique_tokens": rv_unique,
            "ngram_patterns": rv_patterns,
        },
        "relative_metrics": {
            "entropy_diff": round(entropy_advantage, 3),
            "pattern_diff": pattern_advantage,
            "unique_ratio": round(unique_ratio, 3),
        },
    }, ensure_ascii=False, indent=2)


def tool_auto_verify_and_promote(pattern_json: str = "") -> str:
    """
    Full automatic pipeline: analyze → verify → promote.
    Runs StatisticalVerifier + NumberAnalyzer, promotes significant results.
    No manual UI needed.
    """
    verify_result = json.loads(tool_statistical_verify(pattern_json))
    patterns = json.loads(pattern_json) if pattern_json else {}

    # If significant, auto-promote to invariants
    if verify_result.get("is_significant") or verify_result.get("verdict") == "confirmed_statistically":
        pattern_text = patterns.get("context", patterns.get("value", str(patterns)))
        domain = patterns.get("domain", "auto_verified")

        import skills
        skills.REGISTRY["sync_learn"](str(pattern_text)[:100], -0.25, domain)

        # Also add to architectural invariants
        try:
            inv_file = Path("architectural_invariants.json")
            existing = json.loads(inv_file.read_text(encoding="utf-8"))
            existing_patterns = {inv.get("pattern", "") for inv in existing}
            if str(pattern_text)[:60] not in existing_patterns:
                existing.append({
                    "pattern": str(pattern_text)[:60],
                    "domains": [domain],
                    "domain_count": 1,
                    "avg_weight": -0.25,
                    "total_count": 1,
                    "invariant_strength": round(verify_result.get("robustness", 0.7), 3),
                    "type": "AUTO_VERIFIED",
                    "source": "statistical_verifier",
                    "p_value": verify_result.get("p_value"),
                    "promoted_at": datetime.now().strftime('%Y-%m-%d %H:%M'),
                    "status": "active",
                })
                inv_file.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
        except:
            pass

        verify_result["auto_promoted"] = True

    return json.dumps(verify_result, ensure_ascii=False, indent=2)