"""Bybit Analysis Script — DEMO MODE. No trading."""
import importlib, json, os, hashlib, hmac, time, sys
from datetime import datetime
from pathlib import Path

# Use importlib to bypass local skills/email.py shadowing stdlib email
urllib_req = importlib.import_module("urllib.request")

API_KEY = os.getenv("BYBIT_API_KEY", "YTeVNez9VjhQBuMs2G")
SECRET_KEY = os.getenv("BYBIT_SECRET_KEY", "08vLWMo8OkdiRQ4qDs44LCV9nTwPJYp58phr")
BASE = "https://api.bybit.com"
DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

def _sign(params):
    query = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
    sig = hmac.new(SECRET_KEY.encode(), query.encode(), hashlib.sha256).hexdigest()
    return query + "&sign=" + sig

def _get(endpoint, params=None):
    if params is None:
        params = {}
    params["api_key"] = API_KEY
    params["timestamp"] = str(int(time.time() * 1000))
    query = _sign(params)
    req = urllib_req.Request(f"{BASE}{endpoint}?{query}")
    try:
        resp = urllib_req.urlopen(req, timeout=15)
        return json.loads(resp.read().decode())
    except Exception as e:
        return {"ret_code": -1, "ret_msg": str(e)}

def get_ticker(symbol="BTCUSDT"):
    return _get("/v5/market/tickers", {"category": "spot", "symbol": symbol})

def get_kline(symbol="BTCUSDT", interval="D", limit=30):
    return _get("/v5/market/kline", {
        "category": "spot", "symbol": symbol,
        "interval": interval, "limit": limit
    })

def get_wallet():
    return _get("/v5/account/wallet-balance", {"accountType": "UNIFIED"})

def analyze():
    print("=" * 50)
    print("BYBIT ANALYSIS (DEMO)")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 50)

    ticker = get_ticker()
    if ticker.get("retCode") == 0:
        t = ticker["result"]["list"][0]
        print(f"\nBTC: ${float(t['lastPrice']):.2f}")
        print(f"  24h: {t.get('change24h', '?')}%")

    kline = get_kline()
    diff_pct = 0
    avg = 0
    if kline.get("retCode") == 0:
        prices = [float(c[4]) for c in kline["result"]["list"]]
        if len(prices) > 1:
            avg = sum(prices) / len(prices)
            low = min(prices)
            high = max(prices)
            current = prices[-1]
            diff_pct = ((current - avg) / avg) * 100
            print(f"\n  30d avg: ${avg:.2f}")
            print(f"  vs avg: {diff_pct:+.2f}%")
            print(f"  30d: ${low:.2f} - ${high:.2f}")

            if diff_pct < -10:
                print("  AVG BUY SIGNAL")
            elif diff_pct > 10:
                print("  AVG SELL SIGNAL")
            else:
                print("  Neutral")

    wallet = get_wallet()
    if wallet.get("retCode") == 0:
        coins = wallet.get("result", {}).get("list", [{}])[0].get("coin", [])
        usdt = next((c for c in coins if c.get("coin") == "USDT"), None)
        if usdt:
            wb = float(usdt.get("walletBalance", 0))
            print(f"\n  Balance: {wb:.2f} USDT")

    report = {
        "timestamp": datetime.now().isoformat(),
        "btc_price": float(ticker["result"]["list"][0]["lastPrice"]) if ticker.get("retCode") == 0 else 0,
        "signal": "buy" if diff_pct < -10 else "sell" if diff_pct > 10 else "neutral",
    }
    rpath = DATA_DIR / "bybit_analysis.json"
    history = []
    if rpath.exists():
        try:
            history = json.loads(rpath.read_text(encoding="utf-8"))
        except:
            history = []
    history.append(report)
    history = history[-100:]
    rpath.write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(f"\n  {len(history)} reports saved")
    print("=" * 50)

if __name__ == "__main__":
    analyze()
