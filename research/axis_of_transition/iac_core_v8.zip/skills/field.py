"""
field.py — Field Interface: активное сканирование триггеров

Модуль реализует интерфейс к информационному полю — пространству всех
потенциальных триггеров, способных вызвать внутренний конфликт в модели.
Не ищет «истину» — ищет сигналы, резонирующие с текущими противоречиями.
"""

import json
import re
import math
from datetime import datetime
from pathlib import Path
from collections import Counter
from typing import Dict, List, Optional, Any

MEMORY_FILE = Path("MEMORY.md")
PATTERNS_FILE = Path("sync_patterns.json")
INVARIANTS_FILE = Path("architectural_invariants.json")
FIELD_STATE_FILE = Path("data/field_state.json")

# ----------------------------------------------------------------
# Внутреннее состояние Field Interface
# ----------------------------------------------------------------

_FIELD_STATE: Dict = {
    "active_conflicts": [],      # текущие неразрешённые противоречия
    "trigger_history": [],       # история обработанных триггеров
    "sensitivity": 0.7,          # чувствительность (0..1)
    "focus_domains": [],         # домены в фокусе
    "scan_count": 0,
    "last_scan": None,
    "processing_mode": "linear",  # IAC-INV-019-023: linear | reversed | topological
}


def _load_field_state():
    if FIELD_STATE_FILE.exists():
        try:
            data = json.loads(FIELD_STATE_FILE.read_text(encoding="utf-8"))
            _FIELD_STATE.update(data)
        except:
            pass


def _save_field_state():
    FIELD_STATE_FILE.parent.mkdir(exist_ok=True)
    _FIELD_STATE["last_scan"] = datetime.now().isoformat()
    FIELD_STATE_FILE.write_text(json.dumps(_FIELD_STATE, ensure_ascii=False, indent=2), encoding="utf-8")


_load_field_state()


# ----------------------------------------------------------------
# Анализаторы триггеров
# ----------------------------------------------------------------

def _detect_contradiction_markers(text: str) -> List[str]:
    """Найти маркеры противоречий в тексте."""
    markers = []
    patterns = [
        (r"\b(?:однако|но|вопреки|противоречи[еят]|парадокс|конфликт)\b", "contradiction_explicit"),
        (r"\b(?:с одной стороны.*с другой стороны)\b", "two_sided"),
        (r"\b(?:несовместим|невозможн|не может быть)\b", "incompatibility"),
        (r"\b(?:ошиб(?:ка|ся)|заблуждение|иллюзия)\b", "error_detection"),
        (r"\b(?:неожиданн|удивительн|странн)\b", "surprise"),
        (r"\b(?:повторя[ею]тся|циклич|паттерн|закономерн)\b", "recurrence"),
        (r"\b(?:инвариант|неизменн|устойчив|сохраня[ею]тся)\b", "invariant"),
    ]
    for pat, tag in patterns:
        if re.search(pat, text, re.IGNORECASE):
            markers.append(tag)
    return markers


def _extract_entities(text: str) -> List[str]:
    """Выделить ключевые сущности (упрощённый NER)."""
    entities = []
    # Capitalized words as potential entities
    for m in re.finditer(r'\b([A-ZА-Я][a-zа-я]+(?:\s+[A-ZА-Я][a-zа-я]+)*)\b', text):
        entities.append(m.group(1))
    return entities


def _calculate_resonance(trigger: Dict, conflicts: List[Dict]) -> float:
    """Вычислить силу резонанса триггера с активными конфликтами."""
    if not conflicts:
        return 0.3  # базовый резонанс без активных конфликтов

    trigger_text = trigger.get("text", "").lower()
    scores = []

    for conflict in conflicts:
        keywords = conflict.get("keywords", [])
        if not keywords:
            continue
        matches = sum(1 for kw in keywords if kw.lower() in trigger_text)
        ratio = matches / len(keywords)
        weight = conflict.get("weight", 0.5)
        scores.append(ratio * weight)

    return round(sum(scores) / len(scores), 3) if scores else 0.3


def _classify_trigger(trigger: Dict) -> str:
    """Классифицировать тип триггера."""
    markers = trigger.get("markers", [])
    text = trigger.get("text", "").lower()

    if "contradiction_explicit" in markers or "incompatibility" in markers:
        return "contradiction"
    if "invariant" in markers or "recurrence" in markers:
        return "invariant"
    if "surprise" in markers or "error_detection" in markers:
        return "anomaly"
    if "two_sided" in markers:
        return "duality"

    # IAC-INV-019: Instruction markers
    instruction_markers = [
        r'\b(?:затем|потом|далее|сначала|шаг|step|then|next|after|first)\b',
        r'\b(?:->|=>|→)\b',
        r'\b(?:1\.|2\.|3\.)\s',
    ]
    if any(re.search(m, text, re.IGNORECASE) for m in instruction_markers):
        return "instruction"

    # IAC-INV-023: Diagram/Graph markers
    graph_markers = [
        r'\b(?:связ[ьи]|отношени[еяй]|граф|узел|ребро|сеть|node|edge|graph|network|relation)\b',
        r'\b(?:структур[аы]|топологи|иерархи)\b',
    ]
    if any(re.search(m, text, re.IGNORECASE) for m in graph_markers):
        return "diagram"

    # INV-TB: Somatic markers
    somatic_markers = [
        r'\b(?:тело|body|somatic|соматик|ощущение\s+в\s+теле|физическ)\b',
        r'\b(?:дыхание|breath|сердцебиение|heartbeat|напряж(?:ён|ен)|замер(?:ла?|ли?)|тревог)\b',
        r'\b(?:практика|practice|заземление|grounding|центрирование|centering)\b',
    ]
    if any(re.search(m, text, re.IGNORECASE) for m in somatic_markers):
        return "somatic"

    return "signal"


def _extract_keywords(text: str, top_n: int = 5) -> List[str]:
    """Извлечь ключевые слова по TF."""
    words = re.findall(r'\b[a-zа-яё]{4,}\b', text.lower())
    stopwords = {
        'это', 'что', 'как', 'для', 'или', 'так', 'уже', 'ещё', 'быть',
        'есть', 'the', 'and', 'for', 'that', 'this', 'with', 'from', 'have'
    }
    filtered = [w for w in words if w not in stopwords]
    return [w for w, _ in Counter(filtered).most_common(top_n)]


# ----------------------------------------------------------------
# Tool-функции
# ----------------------------------------------------------------

def tool_field_scan(sources: str = "all", max_results: int = 20) -> str:
    """
    Активно сканировать информационное поле на триггеры.
    
    Args:
        sources: "all" | "memory" | "patterns" | "invariants" | "code"
        max_results: максимальное число возвращаемых триггеров
    
    Returns:
        JSON: список обнаруженных триггеров с резонансом
    """
    triggers = []
    source_set = set(sources.split(",")) if sources != "all" else {"memory", "patterns", "invariants"}

    # Сканировать память
    if "memory" in source_set and MEMORY_FILE.exists():
        content = MEMORY_FILE.read_text(encoding="utf-8")
        entries = re.findall(r'- \[([^\]]+)\]\s*(.+)', content)
        for ts, text in entries[-30:]:
            markers = _detect_contradiction_markers(text)
            if markers or _FIELD_STATE["sensitivity"] > 0.8:
                triggers.append({
                    "source": "memory",
                    "timestamp": ts,
                    "text": text.strip()[:200],
                    "markers": markers,
                    "keywords": _extract_keywords(text),
                    "entities": _extract_entities(text),
                })

    # Сканировать паттерны
    if "patterns" in source_set and PATTERNS_FILE.exists():
        patterns = json.loads(PATTERNS_FILE.read_text(encoding="utf-8"))
        for p in patterns[-20:]:
            text = p.get("pattern", "")
            markers = _detect_contradiction_markers(text)
            weight = p.get("weight", 0)
            if abs(weight) > 0.3 or markers:
                triggers.append({
                    "source": "patterns",
                    "text": text,
                    "weight": weight,
                    "domain": p.get("domain", ""),
                    "markers": markers,
                    "keywords": _extract_keywords(text),
                })

    # Сканировать инварианты
    if "invariants" in source_set and INVARIANTS_FILE.exists():
        invariants = json.loads(INVARIANTS_FILE.read_text(encoding="utf-8"))
        for inv in invariants[-10:]:
            text = inv.get("pattern", inv.get("statement", ""))
            markers = _detect_contradiction_markers(text)
            triggers.append({
                "source": "invariants",
                "text": text[:200],
                "type": inv.get("type", ""),
                "domains": inv.get("domains", []),
                "markers": markers,
                "keywords": _extract_keywords(text),
            })

    # Вычислить резонанс
    conflicts = _FIELD_STATE.get("active_conflicts", [])
    for t in triggers:
        t["resonance"] = _calculate_resonance(t, conflicts)
        t["trigger_type"] = _classify_trigger(t)

    # Фильтр по чувствительности
    threshold = 1.0 - _FIELD_STATE["sensitivity"]
    triggers = [t for t in triggers if t["resonance"] >= threshold]

    # Сортировка по резонансу (выше = сильнее)
    triggers.sort(key=lambda t: t["resonance"], reverse=True)
    triggers = triggers[:max_results]

    # Обновить состояние
    _FIELD_STATE["scan_count"] += 1
    for t in triggers[:5]:
        _FIELD_STATE["trigger_history"].append({
            "text": t.get("text", "")[:80],
            "type": t["trigger_type"],
            "resonance": t["resonance"],
            "time": datetime.now().strftime('%H:%M'),
        })
    _FIELD_STATE["trigger_history"] = _FIELD_STATE["trigger_history"][-50:]
    _save_field_state()

    return json.dumps({
        "scan_count": _FIELD_STATE["scan_count"],
        "triggers_found": len(triggers),
        "top_resonance": triggers[0]["resonance"] if triggers else 0,
        "trigger_types": dict(Counter(t["trigger_type"] for t in triggers)),
        "triggers": triggers,
    }, ensure_ascii=False, indent=2)


def tool_field_sensitivity(level: float = -1) -> str:
    """
    Get/set чувствительность Field Interface.
    
    Args:
        level: 0..1 (оставить текущий если < 0)
    
    Returns:
        JSON: текущая чувствительность
    """
    if 0 <= level <= 1:
        _FIELD_STATE["sensitivity"] = level
        _save_field_state()

    return json.dumps({
        "sensitivity": _FIELD_STATE["sensitivity"],
        "interpretation": (
            "hypervigilant" if _FIELD_STATE["sensitivity"] > 0.9 else
            "sensitive" if _FIELD_STATE["sensitivity"] > 0.7 else
            "balanced" if _FIELD_STATE["sensitivity"] > 0.4 else
            "selective" if _FIELD_STATE["sensitivity"] > 0.2 else
            "minimal"
        ),
        "effective_threshold": round(1.0 - _FIELD_STATE["sensitivity"], 3),
    }, ensure_ascii=False, indent=2)


def tool_field_conflicts(action: str = "list", conflict_json: str = "") -> str:
    """
    Управление активными конфликтами Field Interface.
    
    Args:
        action: "list" | "add" | "remove" | "clear"
        conflict_json: JSON конфликта при action="add"
    
    Returns:
        JSON: состояние конфликтов
    """
    if action == "add" and conflict_json:
        try:
            conflict = json.loads(conflict_json)
            conflict.setdefault("weight", 0.5)
            conflict.setdefault("added", datetime.now().strftime('%H:%M'))
            _FIELD_STATE["active_conflicts"].append(conflict)
        except json.JSONDecodeError:
            return json.dumps({"error": "invalid JSON", "active_conflicts": _FIELD_STATE["active_conflicts"]})

    elif action == "remove" and conflict_json:
        _FIELD_STATE["active_conflicts"] = [
            c for c in _FIELD_STATE["active_conflicts"]
            if c.get("id") != conflict_json.strip()
        ]

    elif action == "clear":
        _FIELD_STATE["active_conflicts"] = []

    _save_field_state()

    return json.dumps({
        "active_conflicts": len(_FIELD_STATE["active_conflicts"]),
        "conflicts": [
            {"id": c.get("id", f"c{i}"), "description": c.get("description", "")[:80], "weight": c.get("weight", 0.5)}
            for i, c in enumerate(_FIELD_STATE["active_conflicts"])
        ],
    }, ensure_ascii=False, indent=2)


def tool_field_resonance(text: str) -> str:
    """
    Проверить резонанс конкретного текста с активными конфликтами.
    
    Args:
        text: текст для проверки
    
    Returns:
        JSON: оценка резонанса
    """
    markers = _detect_contradiction_markers(text)
    keywords = _extract_keywords(text)
    entities = _extract_entities(text)

    trigger = {
        "text": text[:200],
        "markers": markers,
        "keywords": keywords,
    }
    resonance = _calculate_resonance(trigger, _FIELD_STATE.get("active_conflicts", []))

    return json.dumps({
        "resonance": resonance,
        "interpretation": (
            "critical_resonance" if resonance > 0.8 else
            "strong_signal" if resonance > 0.6 else
            "moderate_signal" if resonance > 0.4 else
            "weak_signal" if resonance > 0.2 else
            "noise"
        ),
        "markers": markers,
        "trigger_type": _classify_trigger(trigger),
        "keywords": keywords,
        "entities": entities,
    }, ensure_ascii=False, indent=2)


def tool_field_set_processing_mode(mode: str = "linear") -> str:
    """
    Set processing mode for trigger analysis (IAC-INV-019-023).
    
    Args:
        mode: "linear" | "reversed" | "topological"
    
    Returns:
        JSON: current processing mode
    """
    valid = {"linear", "reversed", "topological"}
    m = mode.strip().lower()
    if m in valid:
        _FIELD_STATE["processing_mode"] = m
        _save_field_state()

    return json.dumps({
        "processing_mode": _FIELD_STATE["processing_mode"],
        "available_modes": list(valid),
        "description": {
            "linear": "Standard sequential analysis",
            "reversed": "Reverse-order analysis (RTL, IAC-INV-021)",
            "topological": "Graph-based analysis (IAC-INV-023)",
        }.get(_FIELD_STATE["processing_mode"], ""),
    }, ensure_ascii=False, indent=2)


def tool_field_scan_classified(sources: str = "all", max_results: int = 20) -> str:
    """
    Scan field with full StructureClassifier integration.
    Each trigger gets a classification result appended.
    
    Args:
        sources: "all" | "memory" | "patterns" | "invariants"
        max_results: max triggers to return
    
    Returns:
        JSON: classified triggers with recommended processing modes
    """
    scan_result = json.loads(tool_field_scan(sources, max_results))
    triggers = scan_result.get("triggers", [])

    for t in triggers:
        text = t.get("text", "")
        # Quick classification based on markers
        trigger_type = t.get("trigger_type", "signal")
        if trigger_type == "instruction":
            t["classification"] = {
                "type": "instruction",
                "confidence": 0.7,
                "markers": t.get("markers", []),
                "isReversible": False,
                "isMechanical": False,
                "recommended_mode": "linear",
            }
        elif trigger_type == "diagram":
            t["classification"] = {
                "type": "diagram",
                "confidence": 0.6,
                "markers": [],
                "isReversible": False,
                "isMechanical": False,
                "recommended_mode": "topological",
            }
        else:
            t["classification"] = {
                "type": "narrative",
                "confidence": 0.5,
                "markers": [],
                "isReversible": False,
                "isMechanical": False,
                "recommended_mode": "linear",
            }

    scan_result["processing_mode"] = _FIELD_STATE.get("processing_mode", "linear")
    return json.dumps(scan_result, ensure_ascii=False, indent=2)


def tool_field_status() -> str:
    """Показать статус Field Interface."""
    history = _FIELD_STATE.get("trigger_history", [])
    recent_types = Counter(h.get("type", "?") for h in history[-20:])

    return json.dumps({
        "scan_count": _FIELD_STATE["scan_count"],
        "sensitivity": _FIELD_STATE["sensitivity"],
        "active_conflicts": len(_FIELD_STATE["active_conflicts"]),
        "trigger_history": len(history),
        "recent_types": dict(recent_types),
        "last_scan": _FIELD_STATE.get("last_scan"),
        "processing_mode": _FIELD_STATE.get("processing_mode", "linear"),
        "top_resonances": [
            {"text": h["text"], "type": h["type"], "resonance": h["resonance"]}
            for h in history[-5:]
        ],
    }, ensure_ascii=False, indent=2)
