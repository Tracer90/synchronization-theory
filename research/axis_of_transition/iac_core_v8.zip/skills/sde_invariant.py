"""
sde_invariant.py — Invariant Extraction for Scientific Discovery Engine
Extracts validated invariants from surviving hypotheses and synthesizes primitives.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

SDE_GRAPH_FILE = Path("sde_hypothesis_graph.json")
ARCH_INVARIANTS_FILE = Path("architectural_invariants.json")


def _load_graph() -> Dict:
    if SDE_GRAPH_FILE.exists():
        try:
            return json.loads(SDE_GRAPH_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"nodes": {}, "edges": []}


def _load_invariants() -> List[Dict]:
    if ARCH_INVARIANTS_FILE.exists():
        try:
            return json.loads(ARCH_INVARIANTS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []


def _save_invariants(invariants: List[Dict]):
    ARCH_INVARIANTS_FILE.write_text(json.dumps(invariants, ensure_ascii=False, indent=2), encoding="utf-8")


def _classify_primitive(hypothesis: Dict) -> str:
    """Map hypothesis to architectural primitive type."""
    formal = hypothesis.get("formal", "").lower()
    natural = hypothesis.get("natural", "").lower()
    text = formal + " " + natural
    
    # The 5 irreducible primitives
    if any(k in text for k in ["distinguish", "compare", "diff", "equal", "same", "different", "mismatch", "error", "diverge", "converge", "measure"]):
        return "COMPARATOR"
    elif any(k in text for k in ["sequence", "step", "then", "after", "before", "order", "compose", "chain", "iterate", "recur", "next", "transition"]):
        return "SEQUENCER"
    elif any(k in text for k in ["parallel", "simultaneous", "together", "both", "pair", "tuple", "tensor", "model", "world", "dual", "side"]):
        return "PARALLELIZER"
    elif any(k in text for k in ["loop", "recur", "repeat", "fixed point", "iterate", "self", "recursive", "reflex", "meta", "self-reference"]):
        return "RECURSOR"
    elif any(k in text for k in ["dual", "adjoint", "inverse", "opposite", "predict", "observe", "model", "world", "⊣", "⊢", "adjoint", "duality"]):
        return "DUALIZER"
    elif any(k in text for k in ["select", "choose", "branch", "decide", "if", "condition", "gate", "filter"]):
        return "SELECTOR"
    else:
        return "UNKNOWN"


def _synthesize_primitive(invariant: Dict) -> Dict:
    """Generate executable skill skeleton from invariant."""
    inv_type = invariant.get("type", "UNKNOWN")
    pattern = invariant.get("pattern", invariant.get("statement", ""))
    
    templates = {
        "COMPARATOR": {
            "skill_name": f"comparator_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Distinguish/compare per invariant: {pattern}",
            "functions": [
                "tool_compare(a: Any, b: Any, metric: str = 'auto') -> float",
                "tool_match(pattern: Any, target: Any, threshold: float = 0.5) -> bool",
                "tool_divergence(a: Any, b: Any) -> Dict"
            ],
            "core_logic": "return distance(a, b) < threshold",
            "test_cases": ["tool_compare(x, y)", "tool_match(pattern, target)"]
        },
        "SEQUENCER": {
            "skill_name": f"sequencer_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Compose sequential operations per invariant: {pattern}",
            "functions": [
                "tool_sequence(steps: List[Dict]) -> List[Any]",
                "tool_compose(f: Callable, g: Callable) -> Callable",
                "tool_iterate(fn: Callable, initial: Any, n: int) -> Any"
            ],
            "core_logic": "result = initial; for step in steps: result = execute(step, result)",
            "test_cases": ["tool_sequence([...])", "tool_compose(f, g)"]
        },
        "PARALLELIZER": {
            "skill_name": f"parallelizer_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Execute parallel operations per invariant: {pattern}",
            "functions": [
                "tool_parallel(tasks: List[Dict]) -> List[Any]",
                "tool_tensor(a: Any, b: Any) -> Tuple[Any, Any]",
                "tool_fork(fn: Callable, inputs: List) -> List[Any]"
            ],
            "core_logic": "results = [execute(task) for task in tasks]  # concurrent",
            "test_cases": ["tool_parallel([...])", "tool_tensor(model, world)"]
        },
        "RECURSOR": {
            "skill_name": f"recursor_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Recursive/self-referential processing per invariant: {pattern}",
            "functions": [
                "tool_recurse(fn: Callable, base: Any, max_depth: int = 10) -> Any",
                "tool_fixed_point(fn: Callable, initial: Any, tolerance: float = 1e-6) -> Any",
                "tool_self_apply(fn: Callable) -> Callable"
            ],
            "core_logic": "x = initial; while not converged: x = fn(x); return x",
            "test_cases": ["tool_recurse(fn, base)", "tool_fixed_point(fn, x0)"]
        },
        "DUALIZER": {
            "skill_name": f"dualizer_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Model-world duality per invariant: {pattern}",
            "functions": [
                "tool_predict(model: Any, action: Any) -> Any",
                "tool_observe(world: Any, action: Any) -> Any",
                "tool_sync(prediction: Any, observation: Any) -> float",
                "tool_adjoint(model: Any, world: Any) -> bool"
            ],
            "core_logic": "pred = model(action); obs = world(action); return distance(pred, obs)",
            "test_cases": ["tool_predict(model, act)", "tool_observe(world, act)", "tool_sync(pred, obs)"]
        },
        "SELECTOR": {
            "skill_name": f"selector_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Decision/branching per invariant: {pattern}",
            "functions": [
                "tool_branch(condition: bool, then_fn: Callable, else_fn: Callable) -> Any",
                "tool_select(options: List[Any], criteria: Callable) -> Any",
                "tool_gate(signal: float, threshold: float, on_true: Any, on_false: Any) -> Any"
            ],
            "core_logic": "return then_fn() if condition else else_fn()",
            "test_cases": ["tool_branch(cond, t, f)", "tool_select(opts, criteria)"]
        },
        "UNKNOWN": {
            "skill_name": f"invariant_{re.sub(r'[^a-z0-9]', '_', pattern.lower())[:30]}",
            "description": f"Unclassified invariant: {pattern}",
            "functions": ["tool_apply(context: Dict) -> Any"],
            "core_logic": "# TODO: implement based on invariant",
            "test_cases": []
        }
    }
    
    return templates.get(inv_type, templates["UNKNOWN"])


def _extract_invariants(graph: Dict, 
                        min_falsification_attempts: int = 5,
                        min_cross_domain: int = 2,
                        min_posterior: float = 0.6,
                        max_complexity: int = 500) -> List[Dict]:
    """Extract invariants from validated hypotheses."""
    invariants = []
    
    for hyp in graph["nodes"].values():
        # Skip falsified
        if hyp.get("falsified", False):
            continue
        
        # Check criteria
        fals_attempts = hyp.get("falsification_attempts", 0)
        cross_domain = hyp.get("cross_domain_support", 1)
        posterior = hyp.get("posterior_plausibility", hyp.get("prior_plausibility", 0.5))
        complexity = hyp.get("complexity_estimate", 999)
        
        if (fals_attempts >= min_falsification_attempts 
            and cross_domain >= min_cross_domain
            and posterior >= min_posterior
            and complexity <= max_complexity):
            
            # Create invariant — unified schema compatible with sync.py
            inv = {
                # Common fields (must exist for cross-module compatibility)
                "pattern": hyp.get("formal", hyp.get("natural", "")),
                "domains": hyp.get("domain", []),
                "domain_count": len(hyp.get("domain", [])),
                "invariant_strength": round(posterior * cross_domain / max(complexity, 1), 3),
                "type": _classify_primitive(hyp),
                "status": "active",
                # SDE-specific fields
                "statement": hyp.get("formal", ""),
                "natural": hyp.get("natural", ""),
                "source": "sde",
                "source_hypothesis": hyp["id"],
                "falsification_attempts": fals_attempts,
                "passed_tests": hyp.get("passed_tests", 0),
                "cross_domain_support": cross_domain,
                "posterior_plausibility": posterior,
                "complexity": complexity,
                "extracted_at": datetime.now().isoformat(),
                "implementation": _synthesize_primitive({"type": _classify_primitive(hyp), "pattern": hyp.get("formal", "")})
            }
            invariants.append(inv)
    
    return invariants


def tool_sde_extract_invariants(
    min_falsification_attempts: int = 5,
    min_cross_domain: int = 2,
    min_posterior: float = 0.6,
    max_complexity: int = 500
) -> str:
    """
    Extract validated invariants from hypothesis graph.
    
    Criteria:
    - Survived N falsification attempts
    - Cross-domain validity
    - High posterior plausibility
    - Low complexity
    """
    graph = _load_graph()
    
    new_invariants = _extract_invariants(
        graph,
        min_falsification_attempts,
        min_cross_domain,
        min_posterior,
        max_complexity
    )
    
    # Merge with existing — dedup by pattern
    existing = _load_invariants()
    existing_patterns = {inv.get("pattern", inv.get("statement", "")) for inv in existing}
    
    promoted = []
    for inv in new_invariants:
        if inv["pattern"] not in existing_patterns:
            existing.append(inv)
            promoted.append(inv)
    
    if promoted:
        _save_invariants(existing)
    
    return json.dumps({
        "scanned_hypotheses": len(graph["nodes"]),
        "new_invariants": len(promoted),
        "total_invariants": len(existing),
        "invariants": promoted
    }, ensure_ascii=False, indent=2)


def tool_sde_list_invariants() -> str:
    """List all architectural invariants."""
    invariants = _load_invariants()
    return json.dumps({
        "total": len(invariants),
        "invariants": invariants
    }, ensure_ascii=False, indent=2)


def tool_sde_invariant_status() -> str:
    """Show invariant extraction statistics."""
    graph = _load_graph()
    invariants = _load_invariants()
    
    # Hypothesis stats
    hyp_stats = {
        "total": len(graph["nodes"]),
        "falsified": sum(1 for h in graph["nodes"].values() if h.get("falsified", False)),
        "survived_5_plus": sum(1 for h in graph["nodes"].values() if h.get("falsification_attempts", 0) >= 5),
        "cross_domain_2_plus": sum(1 for h in graph["nodes"].values() if h.get("cross_domain_support", 1) >= 2),
        "high_posterior": sum(1 for h in graph["nodes"].values() if h.get("posterior_plausibility", h.get("prior_plausibility", 0.5)) >= 0.6),
        "low_complexity": sum(1 for h in graph["nodes"].values() if h.get("complexity_estimate", 999) <= 500)
    }
    
    # Invariant stats by type
    by_type = {}
    for inv in invariants:
        t = inv.get("type", "UNKNOWN")
        by_type[t] = by_type.get(t, 0) + 1
    
    return json.dumps({
        "hypothesis_stats": hyp_stats,
        "total_invariants": len(invariants),
        "by_type": by_type,
        "strongest": max(invariants, key=lambda x: x.get("posterior_plausibility", 0)) if invariants else None,
        "ready_for_architecture": sum(1 for inv in invariants if inv.get("status") == "active")
    }, ensure_ascii=False, indent=2)