"""
sde_contradiction.py — Contradiction Engine for Scientific Discovery Engine
Detects logical, empirical, and self-referential contradictions.
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Any, Set
from collections import defaultdict

SDE_GRAPH_FILE = Path("sde_hypothesis_graph.json")
MEMORY_FILE = Path("MEMORY.md")


def _load_graph() -> Dict:
    if SDE_GRAPH_FILE.exists():
        try:
            return json.loads(SDE_GRAPH_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"nodes": {}, "edges": []}


def _load_memory_entries(limit: int = 500) -> List[Dict]:
    if not MEMORY_FILE.exists():
        return []
    content = MEMORY_FILE.read_text(encoding="utf-8")
    lines = content.strip().split("\n")
    entries = []
    for line in lines[-limit:]:
        m = re.match(r'- \[(.*?)\]\s*(?:\[(.*?)\])?\s*(.*?)\s*\{sync:\s*([\d.]+).*?\}', line)
        if m:
            entries.append({
                "timestamp": m.group(1),
                "tag": m.group(2) or "",
                "content": m.group(3).strip(),
                "sync_score": float(m.group(4))
            })
    return entries


def _smt_check_consistency(hypotheses: List[Dict]) -> Dict:
    """
    Simplified SMT-style consistency check using formal strings.
    In production, would call Z3 or similar SMT solver.
    """
    # Extract logical constraints from formal statements
    constraints = []
    for h in hypotheses:
        formal = h.get("formal", "")
        # Parse simple patterns
        if "∀" in formal or "forall" in formal.lower():
            constraints.append(("universal", formal))
        if "∃" in formal or "exists" in formal.lower():
            constraints.append(("existential", formal))
        if "→" in formal or "implies" in formal.lower():
            constraints.append(("implication", formal))
        if "∧" in formal or "and" in formal.lower():
            constraints.append(("conjunction", formal))
        if "¬" in formal or "not" in formal.lower():
            constraints.append(("negation", formal))
    
    # Simple heuristic: check for direct contradictions
    contradictions = []
    formal_strings = [h.get("formal", "").lower() for h in hypotheses]
    
    for i, f1 in enumerate(formal_strings):
        for j, f2 in enumerate(formal_strings[i+1:], i+1):
            # Check for P and not P
            if "¬" in f1 and f1.replace("¬", "") == f2:
                contradictions.append({"type": "direct_negation", "h1": hypotheses[i]["id"], "h2": hypotheses[j]["id"]})
            if "not" in f1 and f1.replace("not ", "") == f2:
                contradictions.append({"type": "direct_negation", "h1": hypotheses[i]["id"], "h2": hypotheses[j]["id"]})
    
    return {
        "constraints_found": len(constraints),
        "contradictions": contradictions,
        "status": "consistent" if not contradictions else "inconsistent"
    }


def _empirical_consistency_check(hypothesis: Dict, memory_entries: List[Dict]) -> List[Dict]:
    """Check if hypothesis predictions match empirical data."""
    contradictions = []
    
    predictions = hypothesis.get("falsifiable_predictions", [])
    for pred in predictions:
        pred_text = str(pred.get("prediction", "")).lower()
        test_method = pred.get("test_method", "")
        
        # Simple keyword matching in memory
        if "low sync" in pred_text or "low error" in pred_text:
            # Check if high sync actually occurred
            high_sync = [e for e in memory_entries if e["sync_score"] > 0.7]
            if high_sync:
                contradictions.append({
                    "type": "empirical",
                    "hypothesis": hypothesis["id"],
                    "prediction": pred_text,
                    "evidence": f"Found {len(high_sync)} high-sync entries contradicting 'low sync' prediction",
                    "confidence": min(1.0, len(high_sync) / 10)
                })
        
        if "high sync" in pred_text or "high error" in pred_text:
            low_sync = [e for e in memory_entries if e["sync_score"] < 0.1]
            if low_sync:
                contradictions.append({
                    "type": "empirical",
                    "hypothesis": hypothesis["id"],
                    "prediction": pred_text,
                    "evidence": f"Found {len(low_sync)} low-sync entries contradicting 'high sync' prediction",
                    "confidence": min(1.0, len(low_sync) / 10)
                })
        
        # Check tag-specific predictions
        if "search" in pred_text:
            search_synced = [e for e in memory_entries if e["tag"] == "search" and e["sync_score"] < 0.2]
            search_desynced = [e for e in memory_entries if e["tag"] == "search" and e["sync_score"] > 0.5]
            if search_desynced and "low" in pred_text:
                contradictions.append({
                    "type": "empirical",
                    "hypothesis": hypothesis["id"],
                    "prediction": pred_text,
                    "evidence": f"Search actions show desync: {len(search_desynced)} high-sync entries",
                    "confidence": 0.7
                })
    
    return contradictions


def _self_reference_check(hypothesis: Dict) -> List[Dict]:
    """Check if hypothesis predicts its own falsity (Liar paradox style)."""
    contradictions = []
    
    formal = hypothesis.get("formal", "").lower()
    natural = hypothesis.get("natural", "").lower()
    text = formal + " " + natural
    
    # Check for self-referential paradoxes
    if any(kw in text for kw in ["this hypothesis", "self", "own", "this statement"]):
        if "false" in text or "wrong" in text or "incorrect" in text:
            contradictions.append({
                "type": "self_reference",
                "hypothesis": hypothesis["id"],
                "issue": "Hypothesis references itself and claims falsity",
                "severity": "paradox"
            })
    
    # Check if hypothesis claims "all hypotheses of type X are false" including itself
    if "all hypotheses" in text or "every hypothesis" in text:
        if "false" in text or "wrong" in text:
            contradictions.append({
                "type": "self_reference",
                "hypothesis": hypothesis["id"],
                "issue": "Universal claim includes self, potential paradox",
                "severity": "potential_paradox"
            })
    
    return contradictions


def _cross_domain_consistency(hypothesis: Dict, graph: Dict) -> List[Dict]:
    """Check if analogical mappings violate domain axioms."""
    contradictions = []
    
    # Domain-specific axioms (simplified)
    domain_axioms = {
        "thermodynamics": ["entropy_increases", "energy_conserved", "no_perpetual_motion"],
        "computation": ["halting_undecidable", "turing_complete", "finite_memory"],
        "biology": ["evolution_no_goal", "finite_resources", "mutation_random"],
        "control_theory": ["bode_integral", "waterbed_effect", "causality"],
        "information": ["data_processing_inequality", "channel_capacity", "no_free_lunch"]
    }
    
    source_domain = hypothesis.get("domain", ["system_dynamics"])[0]
    edges = graph.get("edges", [])
    
    # Find analogies from this hypothesis
    for e in edges:
        if e["from"] == hypothesis["id"] and e["relation"] == "ANALOGOUS":
            target_id = e["to"]
            target = graph["nodes"].get(target_id, {})
            target_domain = target.get("domain", ["unknown"])[0]
            
            # Check if source domain axiom contradicts target
            if source_domain in domain_axioms and target_domain in domain_axioms:
                for axiom in domain_axioms[source_domain]:
                    if axiom in ["no_perpetual_motion", "energy_conserved"]:
                        if target_domain == "computation" and "infinite" in hypothesis.get("natural", "").lower():
                            contradictions.append({
                                "type": "cross_domain_axiom",
                                "hypothesis": hypothesis["id"],
                                "source_domain": source_domain,
                                "target_domain": target_domain,
                                "violated_axiom": axiom,
                                "issue": f"Analogy to {target_domain} violates {axiom} from {source_domain}"
                            })
    
    return contradictions


def _topological_consistency_check(graph: Dict) -> List[Dict]:
    """Check graph topology for structural contradictions (IAC-INV-023)."""
    contradictions = []
    nodes = graph.get("nodes", {})
    edges = graph.get("edges", [])

    if not nodes or len(nodes) < 3:
        return contradictions

    # 1. Build adjacency
    adj = defaultdict(set)
    all_ids = set(nodes.keys())
    for e in edges:
        adj[e["from"]].add(e["to"])
        adj[e["to"]].add(e["from"])

    # 2. Orphan nodes: exist but no edges
    connected = set()
    for e in edges:
        connected.add(e["from"])
        connected.add(e["to"])
    orphans = all_ids - connected
    for oid in orphans:
        contradictions.append({
            "type": "topological",
            "subtype": "orphan_node",
            "severity": "warning",
            "hypothesis": oid,
            "issue": f"Hypothesis '{oid}' has no connections — structurally isolated",
        })

    # 3. Dangling edges
    for e in edges:
        for end in ("from", "to"):
            if e[end] not in all_ids:
                contradictions.append({
                    "type": "topological",
                    "subtype": "dangling_edge",
                    "severity": "critical",
                    "edge": f"{e['from']} -> {e['to']}",
                    "issue": f"Edge references non-existent node '{e[end]}'",
                })

    # 4. Contradiction cliques: mutually contradictory groups
    contradictions_edges = [e for e in edges if e.get("relation") == "CONTRADICTS"]
    if contradictions_edges:
        contradictions.append({
            "type": "topological",
            "subtype": "contradiction_cluster",
            "severity": "critical" if len(contradictions_edges) > 3 else "warning",
            "contradiction_count": len(contradictions_edges),
            "issue": f"{len(contradictions_edges)} mutual contradictions detected in graph",
        })

    # 5. Missing analogy bridges: same pattern type, different domains, no ANALOGOUS edge
    by_pattern = defaultdict(list)
    for nid, n in nodes.items():
        pt = n.get("pattern_type", "")
        if pt:
            by_pattern[pt].append(nid)

    for pt, nids in by_pattern.items():
        domains = {nodes[nid].get("domain", [None])[0] for nid in nids}
        if len(domains) > 1:
            # Check if ANALOGOUS edges exist between these nodes
            analogous = [
                e for e in edges
                if e.get("relation") == "ANALOGOUS"
                and e["from"] in nids and e["to"] in nids
            ]
            if len(analogous) < len(nids) - 1:
                contradictions.append({
                    "type": "topological",
                    "subtype": "missing_analogy_bridge",
                    "severity": "warning",
                    "pattern_type": pt,
                    "nodes": nids,
                    "domains": list(domains),
                    "issue": f"Pattern '{pt}' spans {len(domains)} domains but has {len(analogous)} bridges",
                })

    return contradictions


def tool_sde_find_contradictions() -> str:
    """
    Find all types of contradictions in the hypothesis graph.
    
    Returns JSON with:
    - logical contradictions (SMT)
    - empirical contradictions
    - self-referential paradoxes
    - cross-domain axiom violations
    """
    graph = _load_graph()
    memory = _load_memory_entries(1000)
    
    all_contradictions = []
    
    # 1. Logical contradictions
    hypotheses = list(graph["nodes"].values())
    if len(hypotheses) >= 2:
        smt_result = _smt_check_consistency(hypotheses)
        for c in smt_result.get("contradictions", []):
            all_contradictions.append({
                "type": "logical",
                "subtype": c["type"],
                "hypotheses": [c["h1"], c["h2"]],
                "severity": "critical"
            })
    
    # 2. Empirical contradictions
    for hyp in hypotheses:
        emp = _empirical_consistency_check(hyp, memory)
        for c in emp:
            c["hypothesis"] = hyp["id"]
            all_contradictions.append(c)
    
    # 3. Self-reference
    for hyp in hypotheses:
        self_ref = _self_reference_check(hyp)
        for c in self_ref:
            c["hypothesis"] = hyp["id"]
            all_contradictions.append(c)
    
    # 4. Cross-domain
    for hyp in hypotheses:
        xd = _cross_domain_consistency(hyp, graph)
        for c in xd:
            c["hypothesis"] = hyp["id"]
            all_contradictions.append(c)

    # 5. Topological (IAC-INV-023)
    topo = _topological_consistency_check(graph)
    for c in topo:
        all_contradictions.append(c)
    
    # Group by type
    by_type = defaultdict(list)
    for c in all_contradictions:
        by_type[c["type"]].append(c)
    
    return json.dumps({
        "total_contradictions": len(all_contradictions),
        "by_type": {k: len(v) for k, v in by_type.items()},
        "details": dict(by_type),
        "critical_count": sum(1 for c in all_contradictions if c.get("severity") == "critical")
    }, ensure_ascii=False, indent=2)


def tool_sde_resolve_contradiction(contradiction_id: str, resolution: str) -> str:
    """
    Record contradiction resolution.
    resolution: "reject_h1" | "reject_h2" | "refine_both" | "domain_restrict"
    """
    graph = _load_graph()
    
    # Find contradiction (simplified - in practice would track IDs)
    # For now, just record resolution metadata
    for hyp in graph["nodes"].values():
        if contradiction_id in hyp.get("id", ""):
            hyp.setdefault("contradiction_resolutions", []).append({
                "contradiction_id": contradiction_id,
                "resolution": resolution,
                "resolved_at": datetime.now().isoformat()
            })
    
    _save_graph(graph)
    return json.dumps({"resolved": True, "resolution": resolution})