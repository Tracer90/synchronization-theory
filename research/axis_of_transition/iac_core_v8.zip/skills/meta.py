"""
meta.py — Meta-Skills Engine
Автоматизация процесса обучения, планирования и самоанализа.
Регистрируется с domain="meta".
Возвращает sync_wrap контракт.
"""

import json
import time
import subprocess
from datetime import datetime
from pathlib import Path
from collections import defaultdict, deque

from skills.sync import SyncError

# --- Внутреннее хранилище ---
_PATTERN_DB = {}
_LEARNING_QUEUE = deque(maxlen=50)
_PERFORMANCE_CACHE = {}

# --- Вспомогательные функции ---
def _wrap(result: str, delta: float) -> str:
    return json.dumps({
        "result": result,
        "sync_delta": round(delta, 3),
        "sync_info": {"delta": delta, "actual_score": delta},
    })

def _detect_pattern(text: str) -> list:
    patterns = []
    words = text.lower().split()
    for i in range(len(words) - 2):
        triplet = " ".join(words[i:i+3])
        if len(triplet) > 5 and len(triplet) < 40:
            patterns.append(triplet)
    return patterns

def _extract_action_prefix(text: str) -> str:
    return (text or "").lstrip("!").split()[0].lower() if text else ""

def _suggest_optimization(current_mode: str, last_action: str) -> str:
    suggestions = []
    
    if current_mode == "tool":
        if "search" in _PERFORMANCE_CACHE:
            avg_se = _PERFORMANCE_CACHE["search"]["avg_se"]
            if avg_se > 0.4:
                suggestions.append("switch to code mode for targeted edits")
        
        if "edit" in _PERFORMANCE_CACHE:
            edits = _PERFORMANCE_CACHE["edit"]["count"]
            if edits > 0 and edits % 5 == 0:
                suggestions.append("break long edit sequences to avoid context decay")
    
    if not suggestions:
        return json.dumps({"strategies": ["continue current approach"]}, ensure_ascii=False)
    
    return json.dumps({"strategies": suggestions}, ensure_ascii=False)

# --- Основные инструменты ---
def tool_meta_learn(pattern: str, weight: float = 0.0, domain: str = "meta") -> str:
    """Записать в Pattern DB для авто-рекомендаций"""
    if not pattern or len(pattern) < 3:
        return _wrap("Паттерн слишком короткий.", 0.6)
    
    _PATTERN_DB[pattern] = {
        "weight": round(weight, 3),
        "domain": domain,
        "count": _PATTERN_DB.get(pattern, {}).get("count", 0) + 1,
        "first_seen": datetime.now().strftime('%Y-%m-%d %H:%M'),
    }
    
    # Сохраняем в sync_patterns.json для совместимости
    patterns = _load_existing_patterns()
    existing = any(p.get("pattern") == pattern and p.get("domain") == domain for p in patterns)
    if not existing:
        patterns.append({
            "pattern": pattern,
            "weight": round(weight, 3),
            "domain": domain,
            "count": _PATTERN_DB[pattern]["count"],
            "created": datetime.now().strftime('%d.%m %H:%M'),
        })
        Path("sync_patterns.json").write_text(json.dumps(patterns, ensure_ascii=False, indent=2), encoding="utf-8")
    
    return _wrap(f"Записан паттерн: {pattern[:60]}", 0.05)

def tool_meta_optimize(feedback_log: str = "") -> str:
    """Систематическая оптимизация действий на основе мета-данных"""
    if not feedback_log or len(feedback_log) < 10:
        return _wrap("Недостаточно данных для оптимизации.", 0.5)
    
    # Анализируем паттерны в истории действий
    patterns = _detect_pattern(feedback_log)
    
    # Оценка эффективности паттернов
    effective_patterns = []
    ineffective_patterns = []
    
    for pattern in patterns:
        avg_scores = []
        for action_key in _PERFORMANCE_CACHE:
            if pattern in _PERFORMANCE_CACHE[action_key].get("patterns", []):
                avg_scores.append(_PERFORMANCE_CACHE[action_key]["avg_se"])
        
        if avg_scores:
            avg_score = sum(avg_scores) / len(avg_scores)
            if avg_score < 0.3:
                effective_patterns.append(pattern)
            else:
                ineffective_patterns.append(pattern)
    
    # Создаем рекомендации
    optimizations = []
    
    if effective_patterns:
        optimizations.append(
            f"эффективные паттерны ({len(effective_patterns)}): {effective_patterns[:3]}"
        )
    
    if ineffective_patterns:
        optimizations.append(
            f"мастер-индекс неэффективных ({len(ineffective_patterns)}): нужно улучшение"
        )
    
    # Обновляем конфиг системы
    if optimizations:
        tool_meta_learn("optimize_action_sequence", 0.1, "meta")
    
    return _wrap(json.dumps({
        "optimizations": optimizations,
        "effective_patterns": len(effective_patterns),
        "needs_improvement": len(ineffective_patterns),
        "suggestion": "continue_current_direction" if optimizations else "explore_new_paths"
    }, ensure_ascii=False), 0.03)

def tool_meta_predict(action_hint: str = "", max_suggestions: int = 3) -> str:
    """Прогнозирование оптимальных операций на основе мета-данных"""
    candidates = []
    
    # Анализируем историю действий и метрики
    if _PERFORMANCE_CACHE:
        sorted_actions = sorted(
            _PERFORMANCE_CACHE.items(),
            key=lambda x: x[1]["avg_se"]
        )
        
        for action, metrics in sorted_actions[:max_suggestions]:
            candidates.append({
                "action": action,
                "predicted_se": metrics["avg_se"],
                "historical_count": metrics["count"],
                "reason": f"historically reliable (avg SE {metrics['avg_se']:.2f})"
            })
    
    # Если нет данных, используем умолчания
    if not candidates:
        candidates = [
            {
                "action": "search",
                "predicted_se": 0.5,
                "reason": "fallback recommendation"
            }
        ]
    
    return _wrap(json.dumps({
        "predictions": candidates,
        "action_hint": action_hint,
        "recommendations": [
            "start with historically best performing action" if candidates else "try a new approach"
        ]
    }, ensure_ascii=False), 0.02)

def _load_existing_patterns() -> list:
    patterns_file = Path("sync_patterns.json")
    if patterns_file.exists():
        try:
            return json.loads(patterns_file.read_text(encoding="utf-8"))
        except:
            pass
    return []


def tool_meta_export(format: str = "json") -> str:
    """Экспорт всех мета данных в удобном формате"""
    export_data = {
        "pattern_db_size": len(_PATTERN_DB),
        "pattern_db": _PATTERN_DB,
        "performance_cache": _PERFORMANCE_CACHE,
        "timestamp": datetime.now().isoformat(),
        "sync_patterns_count": len(_load_existing_patterns()),
    }
    
    if format.lower() == "json":
        content = json.dumps(export_data, ensure_ascii=False, indent=2)
        return _wrap(content, 0.02)
    else:
        # Простая текстовая экспорт-стратегия
        lines = [
            f"Noesis Meta Export: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Паттерн DB: {len(_PATTERN_DB)} записей",
            f"Кэш метрик: {len(_PERFORMANCE_CACHE)} записей",
            f"Экспорт завершен.",
        ]
        return _wrap("\n".join(lines), 0.01)

def tool_meta_import(data: str) -> str:
    """Импорт мета данных из внешнего источника"""
    if not data or len(data) < 50:
        return _wrap("Недостаточный объем данных для импорта.", 0.6)
    
    try:
        import_data = json.loads(data)
        
        # Импортируем pattern_db
        imported_patterns = import_data.get("pattern_db", {})
        for pattern, meta in imported_patterns.items():
            _PATTERN_DB[pattern] = meta
        
        # Импортируем performance_cache
        imported_performance = import_data.get("performance_cache", {})
        for action, metrics in imported_performance.items():
            _PERFORMANCE_CACHE[action] = metrics
        
        # Обновляем sync_patterns.json
        patterns = _load_existing_patterns()
        for pattern, meta in imported_patterns.items():
            if not any(p.get("pattern") == pattern for p in patterns):
                patterns.append({
                    "pattern": pattern,
                    "weight": meta.get("weight", 0.0),
                    "domain": meta.get("domain", "meta"),
                    "count": meta.get("count", 1),
                    "created": datetime.now().strftime('%d.%m %H:%M'),
                })
        
        Path("sync_patterns.json").write_text(json.dumps(patterns, ensure_ascii=False, indent=2), encoding="utf-8")
        
        return _wrap(f"Импортировано: {len(imported_patterns)} паттернов, {len(imported_performance)} метрик.", 0.02)
    except json.JSONDecodeError:
        return _wrap("Неверный формат JSON.", 0.5)
    except Exception as e:
        return _wrap(f"Ошибка импорта: {e}", 0.5)

def tool_meta_report() -> str:
    """Детальный отчет обо всей мета системе"""
    total_patterns = len(_PATTERN_DB)
    total_performance_metrics = len(_PERFORMANCE_CACHE)
    
    # Анализируем best/worst performing действия
    if _PERFORMANCE_CACHE:
        sorted_actions = sorted(
            _PERFORMANCE_CACHE.items(),
            key=lambda x: x[1]["avg_se"]
        )
        
        best_action = sorted_actions[0]
        worst_action = sorted_actions[-1]
        
        best = {
            "action": best_action[0],
            "avg_se": best_action[1]["avg_se"],
            "count": best_action[1]["count"]
        }
        
        worst = {
            "action": worst_action[0],
            "avg_se": worst_action[1]["avg_se"],
            "count": worst_action[1]["count"]
        }
    else:
        best = worst = {"action": "none", "avg_se": 0.0, "count": 0}
    
    patterns_by_domain = defaultdict(int)
    for pattern_meta in _PATTERN_DB.values():
        patterns_by_domain[pattern_meta.get("domain", "unknown")] += 1
    
    report_data = {
        "meta_system_status": "operational",
        "pattern_database": {
            "total_patterns": total_patterns,
            "domains": dict(patterns_by_domain)
        },
        "performance_tracking": {
            "tracked_actions": total_performance_metrics,
            "best_performing": best,
            "worst_performing": worst,
        },
        "system_health": {
            "memory_usage": {"estimated_size": "small"},
            "last_update": datetime.now().isoformat(),
        },
        "recommendations": [
            f"optimize action '{worst['action']}' (SE {worst['avg_se']:.2f})" if worst['avg_se'] > 0.4 else "maintain current performance",
            "consider refining high-weight patterns for better consistency",
            "review low-frequency actions for potential improvements"
        ]
    }
    
    return _wrap(json.dumps(report_data, ensure_ascii=False, indent=2), 0.03)

def _register_meta_metrics(action: str, se: float, delta: float, patterns: list = None):
    """Внутренняя функция для регистрации мета-данных о производительности"""
    prefix = _extract_action_prefix(action)
    if prefix not in _PERFORMANCE_CACHE:
        _PERFORMANCE_CACHE[prefix] = {"count": 0, "avg_se": 0.0, "avg_delta": 0.0, "patterns": []}
    
    cache = _PERFORMANCE_CACHE[prefix]
    n = cache["count"] + 1
    cache["avg_se"] = round((cache["avg_se"] * cache["count"] + se) / n, 3)
    cache["avg_delta"] = round((cache["avg_delta"] * cache["count"] + delta) / n, 3)
    cache["count"] = n
    
    # Обновляем ассоциативные паттерны
    if patterns:
        cache["patterns"] = patterns
    else:
        detected = _detect_pattern(action)
        cache["patterns"] = list(set(cache.get("patterns", []) + detected))


# --- Регистрируем метаданные для HELP ---
__doc__ = __doc__


if __name__ == "__main__":
    print("Мета-engine Noesis загружена.")
