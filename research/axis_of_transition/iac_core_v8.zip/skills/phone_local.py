"""
phone_local.py — сенсоры телефона изнутри (через termux-api)
Используется когда live.py запущен прямо на телефоне
"""

import json, subprocess, re

def _cmd(cmd, timeout=5):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=True)
        return r.stdout
    except:
        return ""

def tool_phone_sense(sensor="all"):
    """Read phone sensors locally via termux-sensor. !phone_sense [all|accel|light|battery|screen]"""
    result = {"phone": True, "local": True}
    if sensor in ("all", "accel", "accelerometer"):
        raw = _cmd("termux-sensor -s Accelerometer -n 1 2>/dev/null")
        if raw:
            try:
                d = json.loads(raw)
                vals = d.get("Accelerometer", {}).get("values", [])
                if vals:
                    mag = sum((v - (9.8 if i == 2 else 0))**2 for i, v in enumerate(vals))**0.5
                    result["accel"] = {"x": round(vals[0], 2), "y": round(vals[1], 2), "z": round(vals[2], 2), "movement": round(mag, 2)}
            except:
                result["accel"] = None
        else:
            result["accel"] = None
    if sensor in ("all", "light"):
        raw = _cmd("termux-sensor -s Light -n 1 2>/dev/null")
        if raw:
            try:
                d = json.loads(raw)
                vals = d.get("Light", {}).get("values", [])
                if vals:
                    result["light"] = {"lux": round(vals[0], 1)}
            except:
                result["light"] = None
        else:
            result["light"] = None
    if sensor in ("all", "battery"):
        raw = _cmd("termux-battery-status 2>/dev/null")
        if raw:
            try:
                d = json.loads(raw)
                result["battery"] = {
                    "level": d.get("percentage"),
                    "charging": d.get("plugged") != "UNPLUGGED",
                    "status": d.get("status", "unknown"),
                }
            except:
                result["battery"] = None
        else:
            result["battery"] = None
    if sensor in ("all", "proximity"):
        raw = _cmd("termux-sensor -s Proximity -n 1 2>/dev/null")
        if raw:
            try:
                d = json.loads(raw)
                vals = d.get("Proximity", {}).get("values", [])
                if vals:
                    result["proximity"] = {"value": round(vals[0], 1)}
            except:
                result["proximity"] = None
        else:
            result["proximity"] = None
    if sensor in ("all", "gyro"):
        raw = _cmd("termux-sensor -s Gyroscope -n 1 2>/dev/null")
        if raw:
            try:
                d = json.loads(raw)
                vals = d.get("Gyroscope", {}).get("values", [])
                if vals:
                    result["gyro"] = {"x": round(vals[0], 2), "y": round(vals[1], 2), "z": round(vals[2], 2)}
            except:
                result["gyro"] = None
        else:
            result["gyro"] = None
    return json.dumps(result, ensure_ascii=False)

def tool_phone_vibrate(duration_ms="200"):
    """Vibrate phone for N ms via termux. !phone_vibrate 200"""
    _cmd(f"termux-vibrate -d {duration_ms} 2>/dev/null")
    return json.dumps({"vibrated": True, "duration_ms": int(duration_ms)}, ensure_ascii=False)

def tool_phone_status():
    """Phone connection status (local). !phone_status"""
    raw = _cmd("termux-sensor -l 2>/dev/null")
    sensors_ok = len(raw) > 10
    bat_raw = _cmd("termux-battery-status 2>/dev/null")
    bat = {}
    if bat_raw:
        try:
            bat = json.loads(bat_raw)
        except:
            pass
    return json.dumps({
        "connected": True,
        "local": True,
        "sensors_available": sensors_ok,
        "battery": {"level": bat.get("percentage")} if bat else None,
    }, ensure_ascii=False)
