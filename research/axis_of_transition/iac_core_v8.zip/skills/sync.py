"""
sync.py — Synchronization Engine
Измеряет и управляет рассогласованием между моделью и реальностью.
SynchronizationError: 0.0 = идеальная синхр., 1.0 = полный разрыв.
"""

import json
import re
import math
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.request import Request, urlopen
from urllib.error import URLError

MEMORY_FILE = Path("MEMORY.md")
PATTERNS_FILE = Path("sync_patterns.json")


def _load_patterns() -> list:
    if PATTERNS_FILE.exists():
        try:
            return json.loads(PATTERNS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []


def _save_patterns(patterns: list):
    PATTERNS_FILE.write_text(json.dumps(patterns, ensure_ascii=False, indent=2), encoding="utf-8")


class SyncError:
    @staticmethod
    def from_bool(passed: bool) -> float:
        return 0.0 if passed else 1.0

    @staticmethod
    def from_confidence(confidence: float) -> float:
        return 1.0 - max(0.0, min(1.0, confidence))

    @staticmethod
    def from_diff(expected: float, actual: float) -> float:
        return min(1.0, abs(expected - actual))

    @staticmethod
    def combine(scores: list) -> float:
        return sum(scores) / len(scores) if scores else 0.0

    @staticmethod
    def interpret(score: float) -> str:
        if score < 0.1:
            return "synced"
        if score < 0.3:
            return "slight_drift"
        if score < 0.5:
            return "notable_desync"
        if score < 0.7:
            return "significant_desync"
        return "critical_desync"


FACT_RE = re.compile(r'^\s*-\s*\[(.*?)\]\s*(?:\[(.*?)\])?\s*(.*?)(?:\s*\{sync:\s*([\d.]+).*?\})?\s*$')


def _parse_fact(line: str) -> Optional[dict]:
    m = FACT_RE.match(line)
    if m:
        return {
            "timestamp": m.group(1),
            "content": m.group(3).strip(),
            "tag": m.group(2) or "",
            "sync_score": float(m.group(4)) if m.group(4) else None,
        }
    return None


def _heuristic_score(value: str, domain: str = "") -> float:
    if not value or len(value) < 3:
        return 0.5
    score = 0.0
    if len(value) < 15:
        score += 0.2
    elif len(value) < 50:
        score += 0.1
    val_lower = value.lower()
    error_indicators = ["error", "not found", "nothing found", "fail", "timeout"]
    if any(ind in val_lower for ind in error_indicators):
        score += 0.2
    uncertainty = ["i think", "maybe", "probably", "could be", "might"]
    if any(ind in val_lower for ind in uncertainty):
        score += 0.1
    # apply learned patterns
    patterns = _load_patterns()
    matched_texts = set()
    for p in patterns:
        if p.get("pattern", "").lower() in val_lower:
            if p.get("domain") and domain and p["domain"] != domain:
                continue
            score += p.get("weight", 0)
            if p.get("pattern"):
                matched_texts.add(p["pattern"])
    # cross-domain bonus: pattern in 2+ domains = stronger invariant
    for mt in matched_texts:
        doms = set(p.get("domain", "") for p in patterns if p.get("pattern") == mt and p.get("domain"))
        if len(doms) > 1:
            score += min(0.1, len(doms) * 0.03)
            break
    return min(1.0, max(0.0, score))


def tool_sync_score(value: str = "") -> str:
    """Рассчитать SynchronizationError для значения. Возвращает JSON"""
    score = round(_heuristic_score(value), 3)
    return json.dumps({
        "score": score,
        "score_source": "text_heuristic",
        "interpretation": SyncError.interpret(score),
    })


def tool_sync_filter(value: str, threshold: float = 0.5) -> str:
    """Фильтр с непрерывной оценкой. Возвращает JSON: {passed, score, reason}"""
    result = json.loads(tool_sync_score(value))
    score = result["score"]
    passed = score <= threshold
    return json.dumps({
        "passed": passed,
        "score": score,
        "reason": f"sync_error {score:.3f} {'≤' if passed else '>'} threshold {threshold}",
    })


def tool_sync_fact(content: str, confidence: float = 0.5, tag: str = "") -> str:
    """Сохранить факт в MEMORY.md с метаданными синхронизации. tag: search|code|pattern|reflection|error"""
    result = json.loads(tool_sync_score(content))
    score = result["score"]
    ts = datetime.now().strftime('%d.%m %H:%M')
    sync_tag = f"{{sync: {score:.2f}, conf: {confidence:.2f}}}"
    tag_part = f"[{tag.strip()}] " if tag else ""
    entry = f"- [{ts}] {tag_part}{content[:200].strip()} {sync_tag}\n"
    with open(MEMORY_FILE, "a", encoding="utf-8") as f:
        f.write(entry)
    return json.dumps({
        "saved": True,
        "sync_score": score,
        "confidence": confidence,
        "tag": tag or None,
        "entry": entry.strip(),
    })


def tool_sync_status(detail: str = "summary") -> str:
    """Показать состояние синхронизации. detail: summary | full"""
    if not MEMORY_FILE.exists():
        return json.dumps({"error": "MEMORY.md not found"})
    content = MEMORY_FILE.read_text(encoding="utf-8")
    entries = [_parse_fact(line) for line in content.split("\n")]
    entries = [e for e in entries if e]
    if not entries:
        return json.dumps({"entries": 0, "avg_sync": None, "status": "no_data"})
    scores = [e["sync_score"] for e in entries if e["sync_score"] is not None]
    avg_sync = sum(scores) / len(scores) if scores else None
    tags = {}
    for e in entries:
        t = e.get("tag") or "none"
        tags[t] = tags.get(t, 0) + 1
    base = {
        "entries": len(entries),
        "avg_sync": round(avg_sync, 3) if avg_sync is not None else None,
        "interpretation": SyncError.interpret(avg_sync) if avg_sync is not None else "unknown",
        "tags": tags,
    }
    if detail == "full":
        base["recent"] = [e for e in entries[-5:]]
        base["all"] = entries
    return json.dumps(base, ensure_ascii=False, indent=2)


def tool_sync_delta(expected: str, actual: str) -> str:
    """Synchronization Delta: расхождение между ожиданием и фактом"""
    exp = json.loads(tool_sync_score(expected))
    act = json.loads(tool_sync_score(actual))
    exp_s, act_s = exp["score"], act["score"]
    delta = round(min(1.0, abs(exp_s - act_s) + max(0.0, act_s - exp_s)), 3)
    direction = "worse" if act_s > exp_s + 0.1 else "better" if act_s < exp_s - 0.1 else "neutral"
    return json.dumps({
        "expected_score": exp_s,
        "actual_score": act_s,
        "delta": delta,
        "score_source": "text_heuristic",
        "direction": direction,
        "interpretation": SyncError.interpret(delta),
    })


def tool_sync_wrap(result: str, expected: str = "") -> str:
    """Wrap результат в единый контракт {result, sync_delta, sync_info}"""
    if expected:
        delta_info = json.loads(tool_sync_delta(expected, result))
    else:
        info = json.loads(tool_sync_score(result))
        delta_info = {"delta": info["score"], "expected_score": None,
                       "actual_score": info["score"]}
    return json.dumps({
        "result": result,
        "sync_delta": delta_info["delta"],
        "sync_info": delta_info,
        "score_source": "text_heuristic",
    })


def _load_entries() -> list:
    """Load all parsed entries from MEMORY.md"""
    if not MEMORY_FILE.exists():
        return []
    content = MEMORY_FILE.read_text(encoding="utf-8")
    return [e for e in (_parse_fact(line) for line in content.split("\n")) if e]


_EMBED_CACHE = {}
def _embed(text: str) -> Optional[list]:
    """Embed text via Ollama nomic-embed-text. Returns vector or None."""
    if not text or not text.strip():
        return None
    key = text[:200]
    if key in _EMBED_CACHE:
        return _EMBED_CACHE[key]
    try:
        data = json.dumps({"model": "nomic-embed-text", "prompt": text}).encode()
        req = Request("http://localhost:11434/api/embeddings", data=data,
                       headers={"Content-Type": "application/json"})
        resp = json.loads(urlopen(req, timeout=10).read().decode())
        vec = resp.get("embedding")
        if vec:
            _EMBED_CACHE[key] = vec
        return vec
    except (URLError, OSError, json.JSONDecodeError, KeyError):
        return None

def _cosine_sim(a: list, b: list) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0

def tool_memory_query(query: str = "", limit: int = 5, min_sync: float = 0.0, max_sync: float = 1.0, tag: str = "", semantic: bool = False) -> str:
    """Search MEMORY.md by keyword or tag, filter by sync range. Returns JSON.
    Set semantic=True for embedding-based relevance re-ranking (requires Ollama)."""
    entries = _load_entries()
    q = query.lower().strip() if query else ""
    t = tag.strip().lower() if tag else ""
    matched = []
    for e in entries:
        s = e.get("sync_score")
        if s is not None and (s < min_sync or s > max_sync):
            continue
        if t and e.get("tag", "").lower() != t:
            continue
        if semantic and query:
            pass  # skip keyword filter for semantic ranking
        elif q and q not in e.get("content", "").lower():
            continue
        matched.append(e)
    if semantic and query and len(matched) <= 50:
        q_vec = _embed(query)
        if q_vec:
            for e in matched:
                ev = _embed(e.get("content", ""))
                e["relevance"] = round(_cosine_sim(q_vec, ev), 4) if ev else 0.0
            matched.sort(key=lambda x: x.get("relevance", 0.0), reverse=True)
        else:
            matched.sort(key=lambda x: x.get("sync_score", 0.5) if x.get("sync_score") is not None else 0.5)
    else:
        matched.sort(key=lambda x: x.get("sync_score", 0.5) if x.get("sync_score") is not None else 0.5)
    top = matched[:limit]
    return json.dumps({
        "total_matches": len(matched),
        "query": query or "",
        "tag": tag or None,
        "results": top,
    }, ensure_ascii=False, indent=2)


def tool_memory_stats() -> str:
    """Show memory health: sync distribution, counts, best/worst entries"""
    entries = _load_entries()
    if not entries:
        return json.dumps({"entries": 0, "status": "empty"})
    scores = [e["sync_score"] for e in entries if e["sync_score"] is not None]
    bands = {"synced": 0, "slight_drift": 0, "notable_desync": 0, "significant_desync": 0, "critical_desync": 0}
    for s in scores:
        band = SyncError.interpret(s)
        bands[band] = bands.get(band, 0) + 1
    avg_sync = sum(scores) / len(scores) if scores else None
    best = min(entries, key=lambda e: e["sync_score"] or 1) if scores else None
    worst = max(entries, key=lambda e: e["sync_score"] or 0) if scores else None
    ts_all = [e["timestamp"] for e in entries if e.get("timestamp")]
    tags = {}
    for e in entries:
        t = e.get("tag") or "none"
        tags[t] = tags.get(t, 0) + 1
    return json.dumps({
        "total_entries": len(entries),
        "entries_with_sync": len(scores),
        "avg_sync": round(avg_sync, 3) if avg_sync else None,
        "interpretation": SyncError.interpret(avg_sync) if avg_sync else "unknown",
        "tags": tags,
        "bands": bands,
        "best_entry": best,
        "worst_entry": worst,
        "oldest": ts_all[-1] if ts_all else None,
        "newest": ts_all[0] if ts_all else None,
    }, ensure_ascii=False, indent=2)


def tool_memory_compress(max_entries: int = 200) -> str:
    """Compress MEMORY.md: archive old low-sync entries when file exceeds max_entries"""
    entries = _load_entries()
    if len(entries) <= max_entries:
        # also compress the raw file size if it's huge (over 500KB)
        size = MEMORY_FILE.stat().st_size if MEMORY_FILE.exists() else 0
        if size < 500_000:
            return json.dumps({"action": "none", "entries": len(entries), "size": size})
    # keep top max_entries by sync quality (lowest error = best)
    keep_count = max_entries // 2
    scored = [e for e in entries if e["sync_score"] is not None]
    unscored = [e for e in entries if e["sync_score"] is None]
    scored.sort(key=lambda e: e["sync_score"])
    keep = scored[:keep_count] + unscored
    # rebuild MEMORY.md with only kept entries
    lines = []
    for e in keep:
        sync_tag = ""
        if e.get("sync_score") is not None:
            sync_tag = f" {{sync: {e['sync_score']:.2f}}}"
        tag_part = f"[{e['tag']}] " if e.get("tag") else ""
        lines.append(f"- [{e['timestamp']}] {tag_part}{e['content']}{sync_tag}")
    header = "# MEMORY.md — Единый файл долговременной памяти\n\n"
    body = "\n".join(lines) + "\n"
    MEMORY_FILE.write_text(header + body, encoding="utf-8")
    removed = len(entries) - len(keep)
    return json.dumps({
        "action": "compressed",
        "before": len(entries),
        "after": len(keep),
        "removed": removed,
    })


def tool_sync_learn(pattern: str, weight: float, domain: str = "") -> str:
    """Обучить эвристику: pattern → sync weight (+ = хуже, - = лучше)"""
    patterns = _load_patterns()
    for p in patterns:
        if p.get("pattern") == pattern and p.get("domain", "") == domain:
            p["weight"] = round(weight, 3)
            p["count"] = p.get("count", 0) + 1
            _save_patterns(patterns)
            return json.dumps({"learned": True, "updated": True, "pattern": pattern, "weight": weight})
    patterns.append({
        "pattern": pattern,
        "weight": round(weight, 3),
        "domain": domain,
        "count": 1,
        "created": datetime.now().strftime('%d.%m %H:%M'),
    })
    _save_patterns(patterns)
    return json.dumps({"learned": True, "updated": False, "pattern": pattern, "weight": weight})


def tool_sync_forget(pattern: str, domain: str = "") -> str:
    """Забыть выученный паттерн"""
    patterns = _load_patterns()
    before = len(patterns)
    patterns = [p for p in patterns if not (p.get("pattern") == pattern and p.get("domain", "") == domain)]
    _save_patterns(patterns)
    return json.dumps({"forgotten": before - len(patterns), "remaining": len(patterns)})


def tool_sync_list_patterns() -> str:
    """Показать все выученные паттерны (JSON)"""
    patterns = _load_patterns()
    return json.dumps({
        "total": len(patterns),
        "patterns": patterns,
    }, ensure_ascii=False, indent=2)


def tool_patterns(filter_mode: str = "") -> str:
    """Показать паттерны. --invariants: только cross-domain с силой инвариантности. --by-domain: с группировкой"""
    patterns = _load_patterns()
    if not patterns:
        return json.dumps({"total": 0, "message": "нет выученных паттернов"})

    # cross-domain: pattern text in 2+ domains
    text_domains = {}
    for p in patterns:
        pt = p.get("pattern", "")
        d = p.get("domain", "")
        if pt not in text_domains:
            text_domains[pt] = set()
        if d:
            text_domains[pt].add(d)

    xd_set = {pt for pt, ds in text_domains.items() if len(ds) > 1}

    if filter_mode == "--invariants":
        # Рассчитываем силу инвариантности: strength = (count_domains / total_domains) * (1 - avg_weight)
        # В нашем случае упрощенно: strength = len(domains) * (1 - abs(weight))
        invariants = []
        for p in patterns:
            pt = p.get("pattern", "")
            if pt in xd_set:
                domains = text_domains[pt]
                weight = abs(p.get("weight", 0))
                strength = round(len(domains) * (1 - weight), 3)
                invariants.append({
                    **p,
                    "invariant_strength": strength,
                    "cross_domain_count": len(domains),
                    "domains": list(domains)
                })
        
        # Сортировка по убыванию силы
        invariants.sort(key=lambda x: x["invariant_strength"], reverse=True)
        
        return json.dumps({
            "total": len(invariants),
            "mode": "invariants",
            "patterns": invariants,
        }, ensure_ascii=False, indent=2)

    if filter_mode == "--by-domain":
        by_domain = {}
        for p in patterns:
            d = p.get("domain", "(no domain)")
            by_domain.setdefault(d, []).append(p)
        result = {"total": len(patterns), "domains": {}}
        for d, ps in sorted(by_domain.items()):
            result["domains"][d] = {
                "count": len(ps),
                "patterns": [{"pattern": p["pattern"][:60], "weight": p.get("weight", 0),
                               "count": p.get("count", 1),
                               "cross_domain": p["pattern"] in xd_set}
                             for p in ps],
            }
        return json.dumps(result, ensure_ascii=False, indent=2)

    return tool_sync_list_patterns()


# ===== VARIABLE SYNC OBJECTIVES =====
from enum import Enum

class SyncObjective(Enum):
    """Synchronization objective: what the system tries to achieve with sync_error"""
    MINIMIZE = "minimize"      # Standard: reduce divergence (homeostasis, control)
    MAXIMIZE = "maximize"      # Exploration: seek surprise/novelty (curiosity, creativity)
    TARGET = "target"          # Match specific target value (setpoint tracking)
    EXPLORE = "explore"        # Active inference: maximize expected information gain
    MAINTAIN = "maintain"      # Keep within bounds (band control)

_OBJECTIVE_STATE = {"current": SyncObjective.MINIMIZE}

def tool_sync_objective(objective: str = "") -> str:
    """Get/set synchronization objective. Options: minimize|maximize|target|explore|maintain"""
    global _OBJECTIVE_STATE
    if objective:
        obj = objective.strip().lower()
        try:
            _OBJECTIVE_STATE["current"] = SyncObjective(obj)
            return json.dumps({"set": True, "objective": obj})
        except ValueError:
            return json.dumps({"error": f"Unknown objective: {obj}. Valid: {[o.value for o in SyncObjective]}"})
    return json.dumps({"current": _OBJECTIVE_STATE["current"].value, "options": [o.value for o in SyncObjective]})


def tool_sync_score_objective(value: str = "", target: float = 0.0, objective: str = "") -> str:
    """
    Calculate sync score with configurable objective.
    
    Args:
        value: Text to evaluate
        target: Target sync score (for TARGET objective)
        objective: Override current objective (minimize|maximize|target|explore|maintain)
    
    Returns JSON with score adjusted for objective.
    """
    base_score = _heuristic_score(value)
    obj = SyncObjective(objective) if objective else _OBJECTIVE_STATE["current"]
    
    if obj == SyncObjective.MINIMIZE:
        # Standard: lower is better
        adjusted = base_score
    elif obj == SyncObjective.MAXIMIZE:
        # Invert: higher base_score (more error) = better
        adjusted = 1.0 - base_score
    elif obj == SyncObjective.TARGET:
        # Distance from target
        adjusted = min(1.0, abs(base_score - target))
    elif obj == SyncObjective.EXPLORE:
        # Reward moderate surprise (not too high, not too low)
        # Optimal around 0.3-0.5 sync_error (information gain zone)
        if 0.2 <= base_score <= 0.6:
            adjusted = 1.0 - abs(base_score - 0.4) * 2  # Peak at 0.4
        else:
            adjusted = base_score  # Penalize extremes
    elif obj == SyncObjective.MAINTAIN:
        # Keep within band [target-0.1, target+0.1]
        if abs(base_score - target) <= 0.1:
            adjusted = 0.0  # Perfect
        else:
            adjusted = min(1.0, abs(base_score - target) * 5)  # Steep penalty outside band
    else:
        adjusted = base_score
    
    return json.dumps({
        "base_score": round(base_score, 3),
        "adjusted_score": round(adjusted, 3),
        "objective": obj.value,
        "target": target,
        "interpretation": SyncError.interpret(adjusted)
    })


def tool_sync_trajectory(objective: str = "", steps: int = 10) -> str:
    """
    Simulate sync trajectory under objective.
    Returns projected sync scores over time.
    """
    obj = SyncObjective(objective) if objective else _OBJECTIVE_STATE["current"]
    
    # Simple dynamical model: sync_error evolves based on objective
    trajectory = []
    se = 0.5  # Start at moderate desync
    
    for i in range(steps):
        if obj == SyncObjective.MINIMIZE:
            se = max(0.0, se - 0.05 + (0.02 * (i % 3)))  # Gradual improvement with noise
        elif obj == SyncObjective.MAXIMIZE:
            se = min(1.0, se + 0.08 - (0.03 * (i % 4)))  # Increasing surprise
        elif obj == SyncObjective.TARGET:
            target = 0.1
            se = target + (se - target) * 0.7  # Exponential convergence
        elif obj == SyncObjective.EXPLORE:
            # Oscillate in information gain zone
            se = 0.4 + 0.15 * math.sin(i * 0.8)
        elif obj == SyncObjective.MAINTAIN:
            se = 0.2 + 0.05 * math.sin(i)  # Stable band
        
        trajectory.append({
            "step": i,
            "sync_error": round(se, 3),
            "interpretation": SyncError.interpret(se)
        })
    
    return json.dumps({
        "objective": obj.value,
        "trajectory": trajectory,
        "steady_state": trajectory[-1]["sync_error"] if trajectory else None
    }, ensure_ascii=False, indent=2)


# ===== META-SYNC (SYNCHRONIZATION OF SYNCHRONIZATION) =====

_META_SYNC_LOG = Path("meta_sync.jsonl")

def tool_meta_sync(action: str = "record", predicted_se: float = 0.0, actual_se: float = 0.0, context: str = "") -> str:
    """
    Track synchronization OF the synchronization engine itself.
    Meta-sync = how well predicted sync matches actual sync.
    
    action: record|status|reset
    """
    if action == "reset":
        if _META_SYNC_LOG.exists():
            _META_SYNC_LOG.unlink()
        return json.dumps({"reset": True})
    
    if action == "record":
        meta_sync = 1.0 - min(1.0, abs(predicted_se - actual_se) * 2)
        record = {
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "predicted_se": predicted_se,
            "actual_se": actual_se,
            "meta_sync": round(meta_sync, 3),
            "context": context[:200]
        }
        with open(_META_SYNC_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        return json.dumps(record)
    
    if action == "status":
        if not _META_SYNC_LOG.exists():
            return json.dumps({"entries": 0, "avg_meta_sync": None})
        lines = _META_SYNC_LOG.read_text(encoding="utf-8").strip().split("\n")
        scores = []
        for line in lines[-50:]:
            try:
                scores.append(json.loads(line)["meta_sync"])
            except:
                continue
        avg = sum(scores) / len(scores) if scores else 0
        return json.dumps({
            "entries": len(lines),
            "avg_meta_sync": round(avg, 3),
            "interpretation": "well_calibrated" if avg > 0.7 else "miscalibrated" if avg < 0.4 else "moderate",
            "recent": scores[-10:]
        })
    
    return json.dumps({"error": f"Unknown action: {action}"})


# ===== CROSS-DOMAIN INVARIANT PROMOTION =====

INVARIANTS_FILE = Path("architectural_invariants.json")

def _load_invariants() -> list:
    if INVARIANTS_FILE.exists():
        try:
            return json.loads(INVARIANTS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []

def _save_invariants(invariants: list):
    INVARIANTS_FILE.write_text(json.dumps(invariants, ensure_ascii=False, indent=2), encoding="utf-8")


def tool_promote_invariants(min_strength: float = 0.5, min_domains: int = 2, auto_create_skill: bool = False) -> str:
    """
    Scan learned patterns for cross-domain invariants and promote to architectural primitives.
    
    Args:
        min_strength: Minimum invariant strength to promote (default 0.5)
        min_domains: Minimum number of domains pattern must appear in (default 2)
        auto_create_skill: If True, generate skill skeleton for promoted invariants
    
    Returns:
        JSON with promoted invariants and optional skill templates
    """
    patterns = _load_patterns()
    if not patterns:
        return json.dumps({"promoted": 0, "message": "no patterns to analyze"})
    
    # Group patterns by text across domains
    text_domains = {}
    text_weights = {}
    text_counts = {}
    for p in patterns:
        pt = p.get("pattern", "")
        d = p.get("domain", "")
        w = p.get("weight", 0)
        c = p.get("count", 1)
        if pt not in text_domains:
            text_domains[pt] = set()
            text_weights[pt] = []
            text_counts[pt] = 0
        if d:
            text_domains[pt].add(d)
        text_weights[pt].append(w)
        text_counts[pt] += c
    
    # Calculate invariant strength for cross-domain patterns
    candidates = []
    for pt, domains in text_domains.items():
        if len(domains) >= min_domains:
            avg_weight = sum(text_weights[pt]) / len(text_weights[pt]) if text_weights[pt] else 0
            # Strength = domain_coverage * (1 - abs(avg_weight)) * log(total_count)
            import math
            strength = round(len(domains) * (1 - abs(avg_weight)) * math.log(text_counts[pt] + 1), 3)
            if strength >= min_strength:
                candidates.append({
                    "pattern": pt,
                    "domains": list(domains),
                    "domain_count": len(domains),
                    "avg_weight": round(avg_weight, 3),
                    "total_count": text_counts[pt],
                    "invariant_strength": strength,
                    "candidate_type": _classify_invariant(pt, domains)
                })
    
    # Sort by strength
    candidates.sort(key=lambda x: x["invariant_strength"], reverse=True)
    
    # Load existing invariants
    existing = _load_invariants()
    existing_patterns = {inv["pattern"] for inv in existing}
    
    # Promote new ones
    promoted = []
    for c in candidates:
        if c["pattern"] not in existing_patterns:
            invariant = {
                "pattern": c["pattern"],
                "domains": c["domains"],
                "domain_count": c["domain_count"],
                "avg_weight": c["avg_weight"],
                "total_count": c["total_count"],
                "invariant_strength": c["invariant_strength"],
                "type": c["candidate_type"],
                "source": "sync",
                "promoted_at": datetime.now().strftime('%Y-%m-%d %H:%M'),
                "status": "active"
            }
            existing.append(invariant)
            promoted.append(invariant)
    
    if promoted:
        _save_invariants(existing)
    
    result = {
        "scanned_patterns": len(patterns),
        "cross_domain_candidates": len(candidates),
        "newly_promoted": len(promoted),
        "total_invariants": len(existing),
        "invariants": promoted
    }
    
    if auto_create_skill and promoted:
        result["skill_templates"] = [_generate_skill_template(inv) for inv in promoted]
    
    return json.dumps(result, ensure_ascii=False, indent=2)


def _classify_invariant(pattern: str, domains: set) -> str:
    """Classify what kind of architectural primitive this invariant represents."""
    p = pattern.lower()
    if any(k in p for k in ["distinguish", "compare", "diff", "equal", "same", "different", "mismatch"]):
        return "COMPARATOR"
    elif any(k in p for k in ["sequence", "step", "then", "after", "before", "order", "compose", "chain"]):
        return "SEQUENCER"
    elif any(k in p for k in ["parallel", "simultaneous", "together", "both", "pair", "tuple", "tensor"]):
        return "PARALLELIZER"
    elif any(k in p for k in ["loop", "recur", "repeat", "fixed point", "iterate", "self", "recursive"]):
        return "RECURSOR"
    elif any(k in p for k in ["dual", "adjoint", "inverse", "opposite", "predict", "observe", "model", "world"]):
        return "DUALIZER"
    elif any(k in p for k in ["select", "choose", "branch", "decide", "if", "condition"]):
        return "SELECTOR"
    else:
        return "UNKNOWN"


def _generate_skill_template(invariant: dict) -> dict:
    """Generate a skill skeleton for an invariant."""
    inv_type = invariant["type"]
    pattern = invariant["pattern"]
    
    templates = {
        "COMPARATOR": {
            "name": f"comparator_{pattern[:20].replace(' ', '_')}",
            "description": f"Distinguish/compare based on invariant: {pattern}",
            "functions": ["tool_compare(a, b)", "tool_match(pattern, target)"]
        },
        "SEQUENCER": {
            "name": f"sequencer_{pattern[:20].replace(' ', '_')}",
            "description": f"Compose sequential operations per invariant: {pattern}",
            "functions": ["tool_sequence(steps)", "tool_compose(f, g)"]
        },
        "PARALLELIZER": {
            "name": f"parallelizer_{pattern[:20].replace(' ', '_')}",
            "description": f"Execute parallel operations per invariant: {pattern}",
            "functions": ["tool_parallel(tasks)", "tool_tensor(a, b)"]
        },
        "RECURSOR": {
            "name": f"recursor_{pattern[:20].replace(' ', '_')}",
            "description": f"Recursive/self-referential processing per invariant: {pattern}",
            "functions": ["tool_recurse(fn, base)", "tool_fixed_point(fn)"]
        },
        "DUALIZER": {
            "name": f"dualizer_{pattern[:20].replace(' ', '_')}",
            "description": f"Model-world duality per invariant: {pattern}",
            "functions": ["tool_predict(model, action)", "tool_observe(world, action)", "tool_sync(pred, obs)"]
        },
        "SELECTOR": {
            "name": f"selector_{pattern[:20].replace(' ', '_')}",
            "description": f"Decision/branching per invariant: {pattern}",
            "functions": ["tool_branch(condition, then_fn, else_fn)", "tool_select(options, criteria)"]
        },
        "UNKNOWN": {
            "name": f"invariant_{pattern[:20].replace(' ', '_')}",
            "description": f"Unclassified invariant: {pattern}",
            "functions": ["tool_apply(context)"]
        }
    }
    
    return templates.get(inv_type, templates["UNKNOWN"])


def tool_list_invariants() -> str:
    """List all promoted architectural invariants."""
    invariants = _load_invariants()
    return json.dumps({
        "total": len(invariants),
        "invariants": invariants
    }, ensure_ascii=False, indent=2)


def tool_invariant_status() -> str:
    """Show invariant promotion statistics."""
    patterns = _load_patterns()
    invariants = _load_invariants()
    
    # Pattern stats
    text_domains = {}
    for p in patterns:
        pt = p.get("pattern", "")
        d = p.get("domain", "")
        if pt not in text_domains:
            text_domains[pt] = set()
        if d:
            text_domains[pt].add(d)
    
    cross_domain = sum(1 for d in text_domains.values() if len(d) >= 2)
    single_domain = sum(1 for d in text_domains.values() if len(d) == 1)
    
    # Invariant stats by type
    by_type = {}
    for inv in invariants:
        t = inv.get("type", "UNKNOWN")
        by_type[t] = by_type.get(t, 0) + 1
    
    return json.dumps({
        "patterns_total": len(patterns),
        "unique_pattern_texts": len(text_domains),
        "cross_domain_patterns": cross_domain,
        "single_domain_patterns": single_domain,
        "promoted_invariants": len(invariants),
        "by_type": by_type,
        "strongest": max(invariants, key=lambda x: x.get("invariant_strength", 0)) if invariants else None
    }, ensure_ascii=False, indent=2)
