"""
service_bot.py — Telegram bot for selling automation services.
Lead generation, order collection, portfolio showcase.
"""

import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    ConversationHandler, CallbackQueryHandler, filters,
)

logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
ADMIN_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
DATA_DIR = Path(__file__).parent.parent / "data"
ORDERS_FILE = DATA_DIR / "orders.json"
DATA_DIR.mkdir(exist_ok=True)

STATE_NAME, STATE_DESCR, STATE_BUDGET, STATE_CONTACT = range(4)

SERVICES = {
    "telegram_bot": "Telegram-боты (любой сложности: заказ, уведомления, опросы, админ-панели)",
    "parser": "Парсеры и скраперы (данные с сайтов, мониторинг цен, агрегация)",
    "integration": "Интеграции API (подключение сервисов, вебхуки, синхронизация данных)",
    "automation": "Автоматизация бизнес-процессов (скрипты, воркфлоу, отчёты)",
    "ai": "AI-решения (ChatGPT/OpenRouter интеграции, генерация контента, анализ)",
    "custom": "Другое (опишу сам)",
}

PRICING = (
    "Мини-задача (бот/парсер): $20-50\n"
    "Средний проект: $50-150\n"
    "Комплексная автоматизация: $150-500+\n"
    "Поддержка: $50/мес\n\n"
    "Оплата: USDT (TRC-20) / USDC / Crypto"
)

async def start(update: Update, context):
    user = update.effective_user
    welcome = (
        f"Привет, {user.first_name}! \n\n"
        "Я — сервис автоматизации. Делаю под ключ:\n"
        "- Telegram-боты\n"
        "- Парсеры и скраперы\n"
        "- API интеграции\n"
        "- AI-решения\n"
        "- Бизнес-автоматизация\n\n"
        "Команды:\n"
        "/services — список услуг\n"
        "/pricing — цены\n"
        "/portfolio — примеры работ\n"
        "/order — заказать\n"
        "/contact — контакты\n"
        "/help — помощь"
    )
    await update.message.reply_text(welcome)

async def services(update: Update, context):
    text = "*Наши услуги:*\n\n"
    for key, desc in SERVICES.items():
        text += f"• *{desc.split('(')[0].strip()}*\n  {desc}\n\n"
    await update.message.reply_text(text, parse_mode="Markdown")

async def pricing(update: Update, context):
    await update.message.reply_text(
        f"*Цены:*\n\n{PRICING}\n\n"
        "Точная цена после описания задачи.",
        parse_mode="Markdown",
    )

async def portfolio(update: Update, context):
    text = (
        "*Примеры работ:*\n\n"
        "1. Telegram-бот приёма заказов (для кофейни)\n"
        "2. Парсер конкурентов (агрегация цен с 5 сайтов)\n"
        "3. AI-ассистент для техподдержки (GPT-4)\n"
        "4. Автоматизация отчётности (Google Sheets + Telegram)\n"
        "5. Мониторинг криптовалют (Bybit API + алерты)\n"
        "6. Монитор цен — следит за ценой товара, шлёт алерт при снижении\n"
        "7. CSV→JSON конвертер с отчётом в Telegram\n\n"
        "/order — заказать аналогичное"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def demos(update: Update, context):
    text = (
        "*Демо-автоматизации (код в portfolio/):*\n\n"
        "*price_monitor.py* — мониторинг цен\n"
        "  ```python price_monitor.py <URL> <target_price>```\n\n"
        "*csv_to_json.py* — конвертер данных\n"
        "  ```python csv_to_json.py input.csv```\n\n"
        "*telegram_notifier.py* — уведомления\n"
        "  ```python telegram_notifier.py \"сообщение\"```\n\n"
        "Могу сделать такое же под твою задачу. /order"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def help_cmd(update: Update, context):
    text = (
        "Как это работает:\n"
        "1. Ты описываешь задачу (/order)\n"
        "2. Я называю цену и сроки\n"
        "3. После оплаты — приступаю\n"
        "4. Готовый код + инструкция\n\n"
        "Гарантия: правки бесплатно 7 дней."
    )
    await update.message.reply_text(text)

async def contact(update: Update, context):
    await update.message.reply_text(
        "Связь:\n"
        "Telegram: @connected_users\n\n"
        "Или просто оставь заявку через /order — я отвечу в течение часа."
    )

async def order_start(update: Update, context):
    await update.message.reply_text(
        "Расскажи, что нужно сделать. Опиши задачу в 2-3 предложениях:"
    )
    return STATE_NAME

async def order_name(update: Update, context):
    context.user_data["order_name"] = update.message.text
    await update.message.reply_text(
        "Опиши подробнее:\n- Что должно работать?\n- Какие технологии?\n- Есть ли ТЗ?"
    )
    return STATE_DESCR

async def order_descr(update: Update, context):
    context.user_data["order_descr"] = update.message.text
    keyboard = [
        [InlineKeyboardButton("$20-50", callback_data="20-50")],
        [InlineKeyboardButton("$50-150", callback_data="50-150")],
        [InlineKeyboardButton("$150-500", callback_data="150-500")],
        [InlineKeyboardButton("$500+", callback_data="500+")],
        [InlineKeyboardButton("Не знаю", callback_data="unknown")],
    ]
    await update.message.reply_text(
        "Примерный бюджет:", reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return STATE_BUDGET

async def order_budget(update: Update, context):
    query = update.callback_query
    await query.answer()
    context.user_data["order_budget"] = query.data
    await query.edit_message_text("Как с тобой связаться? (Telegram @username или email)")
    return STATE_CONTACT

async def order_contact(update: Update, context):
    context.user_data["order_contact"] = update.message.text
    await _save_order(context.user_data)
    await _notify_admin(context.user_data)
    await update.message.reply_text(
        "Спасибо! Заявка принята. Я отвечу в ближайшее время.",
    )
    return ConversationHandler.END

async def cancel(update: Update, context):
    await update.message.reply_text("Заказ отменён. /start — главное меню.")
    return ConversationHandler.END

async def _save_order(data: dict):
    orders = []
    if ORDERS_FILE.exists():
        try:
            orders = json.loads(ORDERS_FILE.read_text(encoding="utf-8"))
        except:
            orders = []
    order = {
        "id": len(orders) + 1,
        "timestamp": datetime.now().isoformat(),
        "name": data.get("order_name", ""),
        "description": data.get("order_descr", ""),
        "budget": data.get("order_budget", "unknown"),
        "contact": data.get("order_contact", ""),
    }
    orders.append(order)
    ORDERS_FILE.write_text(
        json.dumps(orders, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    logger.info(f"Order #{order['id']} saved")

async def _notify_admin(data: dict, bot=None):
    if not ADMIN_CHAT_ID:
        return
    text = (
        f"*Новый заказ!*\n\n"
        f"*Название:* {data.get('order_name', '?')}\n"
        f"*Описание:* {data.get('order_descr', '?')[:200]}\n"
        f"*Бюджет:* ${data.get('order_budget', '?')}\n"
        f"*Контакт:* {data.get('order_contact', '?')}\n"
        f"*Время:* {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    )
    try:
        if bot:
            await bot.send_message(chat_id=ADMIN_CHAT_ID, text=text, parse_mode="Markdown")
        else:
            app = Application.builder().token(BOT_TOKEN).build()
            await app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=text, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Admin notify failed: {e}")

async def order_contact(update: Update, context):
    context.user_data["order_contact"] = update.message.text
    await _save_order(context.user_data)
    await _notify_admin(context.user_data, context.bot)
    await update.message.reply_text(
        "Спасибо! Заявка принята. Я отвечу в ближайшее время.\n\n"
        "/start — главное меню"
    )
    return ConversationHandler.END

def run_bot():
    if not BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set")
        return
    app = Application.builder().token(BOT_TOKEN).build()
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("order", order_start)],
        states={
            STATE_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, order_name)],
            STATE_DESCR: [MessageHandler(filters.TEXT & ~filters.COMMAND, order_descr)],
            STATE_BUDGET: [CallbackQueryHandler(order_budget)],
            STATE_CONTACT: [MessageHandler(filters.TEXT & ~filters.COMMAND, order_contact)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("services", services))
    app.add_handler(CommandHandler("pricing", pricing))
    app.add_handler(CommandHandler("portfolio", portfolio))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("contact", contact))
    app.add_handler(CommandHandler("demos", demos))
    app.add_handler(conv_handler)
    logger.info("Service bot started. Press Ctrl+C to stop.")
    app.run_polling()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_bot()
