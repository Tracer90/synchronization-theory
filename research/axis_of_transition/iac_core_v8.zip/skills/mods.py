"""
mods.py — Mod Engine: кастомизация и пресеты

Позволяет менять схемы этапов, темы, правила генерации.
Моды сохраняются как пресеты — пользователь может создавать,
переключаться и делиться.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

MODS_FILE = Path("data/mods.json")


def _load_mods() -> Dict:
    if MODS_FILE.exists():
        try:
            return json.loads(MODS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {
        "active_preset": "default",
        "presets": {
            "default": {
                "name": "Default",
                "description": "Стандартный 6-этапный цикл",
                "stage_schema": ["trigger", "conflict", "meta_rule", "new_model", "action", "feedback"],
                "stage_names": {
                    "trigger": "Триггер",
                    "conflict": "Конфликт",
                    "meta_rule": "Мета-правило",
                    "new_model": "Новая модель",
                    "action": "Действие",
                    "feedback": "Обратная связь",
                },
                "generation_rules": {
                    "max_meta_rules": 3,
                    "include_examples": True,
                    "include_ethical_check": True,
                    "verbosity": "medium",
                },
                "theme": {
                    "primary_color": "#6C5CE7",
                    "background_color": "#0A0A1A",
                    "surface_color": "#1A1A2E",
                    "text_color": "#E0E0E0",
                    "accent_color": "#00D2FF",
                    "font_family": "system",
                    "border_radius": "8px",
                    "animation_speed": 50,
                },
            },
            "fast": {
                "name": "Fast",
                "description": "Быстрый 4-этапный цикл для оперативных решений",
                "stage_schema": ["trigger", "meta_rule", "action", "feedback"],
                "stage_names": {},
                "generation_rules": {
                    "max_meta_rules": 2,
                    "include_examples": False,
                    "include_ethical_check": False,
                    "verbosity": "low",
                },
                "theme": {
                    "primary_color": "#FF6B6B",
                    "background_color": "#0D0D0D",
                    "surface_color": "#1F1F1F",
                    "text_color": "#FFFFFF",
                    "accent_color": "#FFD93D",
                    "font_family": "system",
                    "border_radius": "4px",
                    "animation_speed": 80,
                },
            },
            "deep": {
                "name": "Deep",
                "description": "Глубокий 8-этапный цикл с паузой и рефлексией",
                "stage_schema": [
                    "trigger", "pause", "conflict", "meta_rule",
                    "reflection", "new_model", "action", "feedback"
                ],
                "stage_names": {},
                "generation_rules": {
                    "max_meta_rules": 5,
                    "include_examples": True,
                    "include_ethical_check": True,
                    "verbosity": "high",
                },
                "theme": {
                    "primary_color": "#A29BFE",
                    "background_color": "#0C0C1D",
                    "surface_color": "#1E1E3A",
                    "text_color": "#E8E8F0",
                    "accent_color": "#74B9FF",
                    "font_family": "system",
                    "border_radius": "12px",
                    "animation_speed": 30,
                },
            },
        },
        "custom_invariants": [],
    }


def _save_mods(mods: Dict):
    MODS_FILE.parent.mkdir(exist_ok=True)
    MODS_FILE.write_text(json.dumps(mods, ensure_ascii=False, indent=2), encoding="utf-8")


_MODS = _load_mods()


# ----------------------------------------------------------------
# Tool-функции
# ----------------------------------------------------------------

def tool_mods_preset(action: str = "list", preset_name: str = "") -> str:
    """
    Управление пресетами.
    
    Args:
        action: "list" | "activate" | "save" | "delete"
        preset_name: имя пресета
    
    Returns:
        JSON
    """
    if action == "list":
        presets = _MODS.get("presets", {})
        active = _MODS.get("active_preset", "default")
        return json.dumps({
            "active": active,
            "presets": {
                name: {"name": p.get("name", name), "stages": len(p.get("stage_schema", []))}
                for name, p in presets.items()
            },
        }, ensure_ascii=False, indent=2)

    if action == "activate" and preset_name in _MODS.get("presets", {}):
        _MODS["active_preset"] = preset_name
        _save_mods(_MODS)
        preset = _MODS["presets"][preset_name]
        return json.dumps({
            "status": "activated",
            "preset": preset_name,
            "name": preset.get("name", preset_name),
            "stages": len(preset.get("stage_schema", [])),
        }, ensure_ascii=False, indent=2)

    if action == "save":
        _MODS["presets"][_MODS["active_preset"]] = _MODS["presets"].get(
            _MODS["active_preset"], {"stage_schema": []}
        )
        _save_mods(_MODS)
        return json.dumps({"status": "saved", "preset": _MODS["active_preset"]})

    if action == "delete" and preset_name not in ("default",):
        _MODS["presets"].pop(preset_name, None)
        if _MODS["active_preset"] == preset_name:
            _MODS["active_preset"] = "default"
        _save_mods(_MODS)
        return json.dumps({"status": "deleted", "preset": preset_name})

    return json.dumps({"error": "invalid action or preset not found"})


def tool_mods_stages(action: str = "get", stages_json: str = "") -> str:
    """
    Get/set схему этапов активного пресета.
    
    Args:
        action: "get" | "set"
        stages_json: JSON-массив названий этапов
    
    Returns:
        JSON
    """
    preset_name = _MODS.get("active_preset", "default")
    preset = _MODS["presets"].setdefault(preset_name, {"stage_schema": [], "stage_names": {}, "generation_rules": {}, "theme": {}})

    if action == "get":
        return json.dumps({
            "preset": preset_name,
            "stage_schema": preset.get("stage_schema", []),
            "stage_names": preset.get("stage_names", {}),
        }, ensure_ascii=False, indent=2)

    if action == "set" and stages_json:
        try:
            stages = json.loads(stages_json)
            preset["stage_schema"] = stages
            _save_mods(_MODS)
            return json.dumps({"status": "updated", "stages": len(stages), "schema": stages})
        except:
            return json.dumps({"error": "invalid JSON array"})

    return json.dumps({"error": "invalid action"})


def tool_mods_theme(action: str = "get", theme_json: str = "") -> str:
    """
    Get/set тему активного пресета.
    
    Args:
        action: "get" | "set" | "reset"
        theme_json: JSON-объект темы
    
    Returns:
        JSON
    """
    preset_name = _MODS.get("active_preset", "default")
    preset = _MODS["presets"].setdefault(preset_name, {"stage_schema": [], "stage_names": {}, "generation_rules": {}, "theme": {}})

    if action == "get":
        return json.dumps({
            "preset": preset_name,
            "theme": preset.get("theme", {}),
        }, ensure_ascii=False, indent=2)

    if action == "set" and theme_json:
        try:
            theme = json.loads(theme_json)
            preset["theme"] = theme
            _save_mods(_MODS)
            return json.dumps({"status": "updated", "theme": theme})
        except:
            return json.dumps({"error": "invalid JSON"})

    if action == "reset":
        default_theme = _MODS["presets"]["default"]["theme"]
        preset["theme"] = dict(default_theme)
        _save_mods(_MODS)
        return json.dumps({"status": "reset_to_default"})

    return json.dumps({"error": "invalid action"})


def tool_mods_rules(action: str = "get", rules_json: str = "") -> str:
    """
    Get/set правила генерации для активного пресета.
    
    Args:
        action: "get" | "set"
        rules_json: JSON-объект правил
    
    Returns:
        JSON
    """
    preset_name = _MODS.get("active_preset", "default")
    preset = _MODS["presets"].setdefault(preset_name, {"stage_schema": [], "stage_names": {}, "generation_rules": {}, "theme": {}})

    if action == "get":
        return json.dumps({
            "preset": preset_name,
            "generation_rules": preset.get("generation_rules", {}),
        }, ensure_ascii=False, indent=2)

    if action == "set" and rules_json:
        try:
            rules = json.loads(rules_json)
            preset["generation_rules"] = rules
            _save_mods(_MODS)
            return json.dumps({"status": "updated", "rules": rules})
        except:
            return json.dumps({"error": "invalid JSON"})

    return json.dumps({"error": "invalid action"})


def tool_mods_invariant(action: str = "list", invariant_json: str = "") -> str:
    """
    Управление пользовательскими инвариантами.
    
    Args:
        action: "list" | "add" | "remove"
        invariant_json: JSON-объект инварианта
    
    Returns:
        JSON
    """
    if action == "list":
        return json.dumps({
            "total": len(_MODS.get("custom_invariants", [])),
            "invariants": _MODS.get("custom_invariants", []),
        }, ensure_ascii=False, indent=2)

    if action == "add" and invariant_json:
        try:
            inv = json.loads(invariant_json)
            inv.setdefault("id", f"custom_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            inv.setdefault("created", datetime.now().isoformat())
            _MODS.setdefault("custom_invariants", [])
            _MODS["custom_invariants"].append(inv)
            _save_mods(_MODS)
            return json.dumps({"status": "added", "id": inv["id"]})
        except:
            return json.dumps({"error": "invalid JSON"})

    if action == "remove":
        inv_id = invariant_json.strip()
        _MODS["custom_invariants"] = [
            i for i in _MODS.get("custom_invariants", [])
            if i.get("id") != inv_id
        ]
        _save_mods(_MODS)
        return json.dumps({"status": "removed", "id": inv_id})

    return json.dumps({"error": "invalid action"})


def tool_mods_create_preset(name: str, stages_json: str, theme_json: str = "{}", rules_json: str = "{}") -> str:
    """
    Создать новый пресет.
    
    Args:
        name: имя пресета
        stages_json: JSON-массив этапов
        theme_json: JSON-объект темы (опционально)
        rules_json: JSON-объект правил (опционально)
    
    Returns:
        JSON
    """
    try:
        stages = json.loads(stages_json)
        theme = json.loads(theme_json) if theme_json else {}
        rules = json.loads(rules_json) if rules_json else {}
    except:
        return json.dumps({"error": "invalid JSON in one of the arguments"})

    key = name.lower().replace(" ", "_")
    _MODS["presets"][key] = {
        "name": name,
        "description": f"Пользовательский пресет: {name}",
        "stage_schema": stages,
        "stage_names": {},
        "generation_rules": rules or {"max_meta_rules": 3, "include_examples": True, "include_ethical_check": True, "verbosity": "medium"},
        "theme": theme or dict(_MODS["presets"]["default"]["theme"]),
    }
    _save_mods(_MODS)
    return json.dumps({"status": "created", "key": key, "name": name})


def tool_mods_status() -> str:
    """Полный статус Mod Engine."""
    active = _MODS.get("active_preset", "default")
    preset = _MODS.get("presets", {}).get(active, {})
    return json.dumps({
        "active_preset": active,
        "preset_name": preset.get("name", active),
        "total_presets": len(_MODS.get("presets", {})),
        "total_invariants": len(_MODS.get("custom_invariants", [])),
        "stages": preset.get("stage_schema", []),
        "rules": preset.get("generation_rules", {}),
        "theme_colors": {
            k: v for k, v in preset.get("theme", {}).items()
            if k in ("primary_color", "background_color", "accent_color")
        },
    }, ensure_ascii=False, indent=2)