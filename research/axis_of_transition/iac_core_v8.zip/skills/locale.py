"""
locale.py — Localization: поддержка языков (RU/EN)

Минимальная реализация. Словарь расширяем через добавление ключей.
"""

import json
from pathlib import Path
from typing import Dict, Optional

LOCALE_FILE = Path("data/locale.json")

# ----------------------------------------------------------------
# Словарь локализации
# ----------------------------------------------------------------

_BUILTIN_DICT: Dict[str, Dict[str, str]] = {
    "ru": {
        # Система
        "system_name": "IAC — Инвариантное Адаптивное Ядро",
        "system_desc": "Само-согласованная машина поиска инвариантов",

        # Цикл
        "trigger": "Триггер",
        "conflict": "Конфликт",
        "meta_rule": "Мета-правило",
        "new_model": "Новая модель",
        "action": "Действие",
        "feedback": "Обратная связь",
        "sync": "Синхронизация",
        "reflection": "Рефлексия",
        "evolution": "Эволюция",

        # Ядро
        "representation": "Представление",
        "transformation": "Трансформация",
        "meta_transformation": "Мета-трансформация",
        "invariant": "Инвариант",
        "constraint": "Ограничение",
        "compression": "Сжатие",
        "prediction": "Прогноз",
        "verification": "Проверка",
        "falsification": "Фальсификация",

        # Модули
        "field_interface": "Интерфейс поля",
        "translation_engine": "Машина перевода",
        "negative_intelligence": "Негативный интеллект",
        "positive_intelligence": "Позитивный интеллект",
        "mod_engine": "Машина модов",
        "sync_engine": "Машина синхронизации",
        "sde_pipeline": "Конвейер научного открытия",

        # Метрики
        "sync_error": "Ошибка синхронизации",
        "cognitive_strain": "Когнитивное напряжение",
        "self_consistency": "Само-согласованность",
        "resonance": "Резонанс",

        # Состояния
        "synced": "Синхронизирован",
        "drifting": "Дрейф",
        "desynced": "Расхождение",
        "critical": "Критическое расхождение",
        "stable": "Стабильно",
        "evolving": "Эволюционирует",

        # UI
        "settings": "Настройки",
        "language": "Язык",
        "theme": "Тема",
        "mods": "Моды",
        "presets": "Пресеты",
        "library": "Библиотека",
        "history": "История",
        "export": "Экспорт",
        "import": "Импорт",
        "save": "Сохранить",
        "cancel": "Отмена",
        "apply": "Применить",
        "reset": "Сброс",
        "search": "Поиск",
        "analyze": "Анализировать",
        "generate": "Сгенерировать",

        # Действия
        "scanning_field": "Сканирование поля...",
        "detecting_conflicts": "Обнаружение конфликтов...",
        "generating_meta_rules": "Генерация мета-правил...",
        "updating_model": "Обновление модели...",
        "verifying": "Проверка...",
        "syncing": "Синхронизация...",

        # Сообщения
        "no_conflicts": "Конфликтов не обнаружено",
        "conflict_resolved": "Конфликт разрешён",
        "model_updated": "Модель обновлена",
        "ready": "Готов",
        "error": "Ошибка",
        "thinking": "Думаю...",
    },

    "en": {
        # System
        "system_name": "IAC — Invariant Adaptive Core",
        "system_desc": "Self-consistent invariant discovery machine",

        # Cycle
        "trigger": "Trigger",
        "conflict": "Conflict",
        "meta_rule": "Meta-Rule",
        "new_model": "New Model",
        "action": "Action",
        "feedback": "Feedback",
        "sync": "Sync",
        "reflection": "Reflection",
        "evolution": "Evolution",

        # Core
        "representation": "Representation",
        "transformation": "Transformation",
        "meta_transformation": "Meta-Transformation",
        "invariant": "Invariant",
        "constraint": "Constraint",
        "compression": "Compression",
        "prediction": "Prediction",
        "verification": "Verification",
        "falsification": "Falsification",

        # Modules
        "field_interface": "Field Interface",
        "translation_engine": "Translation Engine",
        "negative_intelligence": "Negative Intelligence",
        "positive_intelligence": "Positive Intelligence",
        "mod_engine": "Mod Engine",
        "sync_engine": "Sync Engine",
        "sde_pipeline": "Scientific Discovery Pipeline",

        # Metrics
        "sync_error": "Sync Error",
        "cognitive_strain": "Cognitive Strain",
        "self_consistency": "Self-Consistency",
        "resonance": "Resonance",

        # States
        "synced": "Synced",
        "drifting": "Drifting",
        "desynced": "Desynced",
        "critical": "Critical",
        "stable": "Stable",
        "evolving": "Evolving",

        # UI
        "settings": "Settings",
        "language": "Language",
        "theme": "Theme",
        "mods": "Mods",
        "presets": "Presets",
        "library": "Library",
        "history": "History",
        "export": "Export",
        "import": "Import",
        "save": "Save",
        "cancel": "Cancel",
        "apply": "Apply",
        "reset": "Reset",
        "search": "Search",
        "analyze": "Analyze",
        "generate": "Generate",

        # Actions
        "scanning_field": "Scanning field...",
        "detecting_conflicts": "Detecting conflicts...",
        "generating_meta_rules": "Generating meta-rules...",
        "updating_model": "Updating model...",
        "verifying": "Verifying...",
        "syncing": "Syncing...",

        # Messages
        "no_conflicts": "No conflicts detected",
        "conflict_resolved": "Conflict resolved",
        "model_updated": "Model updated",
        "ready": "Ready",
        "error": "Error",
        "thinking": "Thinking...",
    },
}

_DICT: dict = {}
_CURRENT_LANG = "ru"


def _load_locale():
    global _DICT, _CURRENT_LANG
    _DICT = dict(_BUILTIN_DICT)
    if LOCALE_FILE.exists():
        try:
            data = json.loads(LOCALE_FILE.read_text(encoding="utf-8"))
            for lang, entries in data.get("dictionary", {}).items():
                if lang not in _DICT:
                    _DICT[lang] = {}
                _DICT[lang].update(entries)
            _CURRENT_LANG = data.get("current_language", "ru")
        except:
            pass


def _save_locale():
    LOCALE_FILE.parent.mkdir(exist_ok=True)
    user_entries = {k: v for k, v in _DICT.items() if k not in _BUILTIN_DICT}
    LOCALE_FILE.write_text(json.dumps({
        "current_language": _CURRENT_LANG,
        "dictionary": user_entries,
    }, ensure_ascii=False, indent=2), encoding="utf-8")


_load_locale()


def translate(key: str, language: Optional[str] = None) -> str:
    """Перевести ключ на указанный язык (или текущий)."""
    lang = language or _CURRENT_LANG
    return _DICT.get(lang, {}).get(key, key)


# ----------------------------------------------------------------
# Tool-функции
# ----------------------------------------------------------------

def tool_locale_lang(language: str = "") -> str:
    """
    Get/set язык интерфейса.
    
    Args:
        language: "ru" | "en" (пустая строка = показать текущий)
    
    Returns:
        JSON: текущий язык
    """
    global _CURRENT_LANG
    lang = language.strip().lower()
    if lang in _DICT:
        _CURRENT_LANG = lang
        _save_locale()

    return json.dumps({
        "current": _CURRENT_LANG,
        "available": sorted(_DICT.keys()),
        "entry_count": len(_DICT.get(_CURRENT_LANG, {})),
    }, ensure_ascii=False, indent=2)


def tool_locale_t(key: str) -> str:
    """
    Перевести ключ на текущий язык.
    
    Args:
        key: ключ из словаря
    
    Returns:
        Перевод
    """
    return translate(key)


def tool_locale_add(language: str, entries_json: str) -> str:
    """
    Добавить записи в словарь локализации.
    
    Args:
        language: код языка
        entries_json: JSON-объект {ключ: перевод}
    
    Returns:
        JSON: результат
    """
    lang = language.strip().lower()
    try:
        entries = json.loads(entries_json)
        if lang not in _DICT:
            _DICT[lang] = {}
        _DICT[lang].update(entries)
        _save_locale()
        return json.dumps({"status": "added", "language": lang, "count": len(entries)})
    except:
        return json.dumps({"error": "invalid JSON"})


def tool_locale_list(language: str = "") -> str:
    """
    Показать словарь для языка.
    
    Args:
        language: код языка (пустая строка = все языки)
    
    Returns:
        JSON
    """
    if language:
        lang = language.strip().lower()
        entries = _DICT.get(lang, {})
        return json.dumps({"language": lang, "entries": len(entries), "dictionary": entries},
                         ensure_ascii=False, indent=2)

    return json.dumps({
        "current": _CURRENT_LANG,
        "languages": {k: len(v) for k, v in _DICT.items()},
    }, ensure_ascii=False, indent=2)


def tool_locale_status() -> str:
    """Статус локализации."""
    return json.dumps({
        "current_language": _CURRENT_LANG,
        "supported_languages": sorted(_DICT.keys()),
        "entries_per_language": {k: len(v) for k, v in _DICT.items()},
        "total_entries": sum(len(v) for v in _DICT.values()),
    }, ensure_ascii=False, indent=2)
