"""
sde_hypothesis.py — Hypothesis Generator for Scientific Discovery Engine
Converts patterns into formal, falsifiable hypotheses.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import Counter, defaultdict

SDE_GRAPH_FILE = Path("sde_hypothesis_graph.json")


def _load_sde_graph() -> Dict:
    if SDE_GRAPH_FILE.exists():
        try:
            return json.loads(SDE_GRAPH_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"nodes": {}, "edges": []}


def _save_sde_graph(graph: Dict):
    SDE_GRAPH_FILE.write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")


def _pattern_to_hypothesis(pattern: Dict, pattern_type: str) -> Dict:
    """Convert extracted pattern to formal hypothesis."""
    pid = pattern.get("id", f"pat_{pattern_type}_{datetime.now().strftime('%H%M%S')}")
    
    templates = {
        "recurrence": {
            "formal": "∀t: |SE(t) - SE(t-τ)| < ε → deterministic_dynamics(τ)",
            "natural": f"Sync error exhibits recurrence with period ~{pattern.get('avg_diagonal_line', '?')} cycles",
            "prediction": "Future sync states predictable from past within epsilon"
        },
        "mutual_info": {
            "formal": "I(Tag; SyncScore) > 0 → Tag predicts SyncState",
            "natural": f"Action tag '{pattern.get('tag', '?')}' predicts sync quality",
            "prediction": f"Actions tagged '{pattern.get('tag', '?')}' yield sync_error {pattern.get('avg_sync', '?')}"
        },
        "topology": {
            "formal": "∃ cycle C in TagGraph: ∀t∈C, SE(t) ≈ constant",
            "natural": f"Action sequence {pattern.get('cycle', '?')} forms stable sync cycle",
            "prediction": "Repeating this sequence maintains sync stability"
        },
        "symmetry": {
            "formal": "∃ subseq S: S repeats with frequency > chance",
            "natural": f"Subsequence {pattern.get('pattern', '?')} repeats {pattern.get('count', '?')} times",
            "prediction": "This subsequence will recur in future cycles"
        },
        "conservation": {
            "formal": "d/dt Q(t) ≈ 0 where Q = {pattern.get('quantity', '?')}",
            "natural": f"Quantity '{pattern.get('quantity', '?')}' is conserved (variance {pattern.get('avg_variance', '?')})",
            "prediction": "This quantity will remain stable under current dynamics"
        }
    }
    
    tpl = templates.get(pattern_type, templates["recurrence"])
    
    return {
        "id": pid,
        "formal": tpl["formal"],
        "natural": tpl["natural"],
        "pattern_type": pattern_type,
        "source_pattern": pattern,
        "domain": ["system_dynamics"],
        "generative_model": f"lambda params: simulate_{pattern_type}(params)",
        "falsifiable_predictions": [
            {
                "condition": "continue current dynamics",
                "prediction": tpl["prediction"],
                "precision": 0.1,
                "test_method": "observe_next_N_cycles"
            }
        ],
        "invariant_candidates": [f"{pattern_type}_invariant"],
        "complexity_estimate": len(tpl["formal"]),
        "prior_plausibility": 0.5,
        "created_at": datetime.now().isoformat(),
        "falsification_attempts": 0,
        "passed_tests": 0,
        "cross_domain_support": 1
    }


def _analogical_transfer(hypothesis: Dict, target_domains: List[str]) -> List[Dict]:
    """Generate analogical hypotheses for other domains."""
    analogical = []
    analogies = {
        "system_dynamics": {
            "biology": "homeostasis",
            "computation": "fixed_point_iteration",
            "thermodynamics": "steady_state",
            "control_theory": "limit_cycle",
            "evolution": "evolutionary_stable_strategy"
        }
    }
    
    source_domain = hypothesis.get("domain", ["system_dynamics"])[0]
    if source_domain in analogies:
        for target, concept in analogies[source_domain].items():
            if target in target_domains:
                analogical.append({
                    "id": f"{hypothesis['id']}_analogy_{target}",
                    "formal": hypothesis["formal"].replace("SE", concept).replace("Sync", concept.capitalize()),
                    "natural": f"Analogy: {hypothesis['natural']} → {concept} in {target}",
                    "pattern_type": f"analogy_{hypothesis.get('pattern_type', 'recurrence')}",
                    "source_hypothesis": hypothesis["id"],
                    "domain": [target],
                    "generative_model": hypothesis["generative_model"],
                    "falsifiable_predictions": hypothesis["falsifiable_predictions"],
                    "invariant_candidates": hypothesis["invariant_candidates"],
                    "complexity_estimate": hypothesis["complexity_estimate"] + 10,
                    "prior_plausibility": 0.4,
                    "created_at": datetime.now().isoformat(),
                    "falsification_attempts": 0,
                    "passed_tests": 0,
                    "cross_domain_support": 1
                })
    return analogical


def _compositional_combination(h1: Dict, h2: Dict) -> Optional[Dict]:
    """Combine two hypotheses into a composite."""
    # Simple composition: if h1 predicts X and h2 predicts Y, compose
    if h1["id"] == h2["id"]:
        return None
    
    return {
        "id": f"comp_{h1['id'][:8]}_{h2['id'][:8]}",
        "formal": f"({h1['formal']}) ∧ ({h2['formal']})",
        "natural": f"Composition: {h1['natural']} AND {h2['natural']}",
        "pattern_type": "composition",
        "source_hypotheses": [h1["id"], h2["id"]],
        "domain": list(set(h1.get("domain", []) + h2.get("domain", []))),
        "generative_model": f"lambda params: {h1['generative_model']}(params) and {h2['generative_model']}(params)",
        "falsifiable_predictions": h1["falsifiable_predictions"] + h2["falsifiable_predictions"],
        "invariant_candidates": h1["invariant_candidates"] + h2["invariant_candidates"],
        "complexity_estimate": h1["complexity_estimate"] + h2["complexity_estimate"],
        "prior_plausibility": min(h1["prior_plausibility"], h2["prior_plausibility"]) * 0.8,
        "created_at": datetime.now().isoformat(),
        "falsification_attempts": 0,
        "passed_tests": 0,
        "cross_domain_support": max(h1.get("cross_domain_support", 1), h2.get("cross_domain_support", 1))
    }


def tool_sde_generate_hypotheses(patterns_json: str = "", target_domains: str = "biology,computation,thermodynamics,control_theory,evolution") -> str:
    """
    Generate formal hypotheses from extracted patterns.
    
    Args:
        patterns_json: JSON string from sde_extract_patterns (or empty to auto-load)
        target_domains: Comma-separated domains for analogical transfer
    
    Returns:
        JSON list of generated hypotheses
    """
    if patterns_json:
        patterns = json.loads(patterns_json)
    else:
        # Auto-extract
        import skills
        patterns = json.loads(skills.REGISTRY["sde_extract_patterns"]("200"))
    
    domains = [d.strip() for d in target_domains.split(",")]
    hypotheses = []
    
    # Inductive: pattern → hypothesis
    if "recurrence_analysis" in patterns and patterns["recurrence_analysis"].get("determinism", 0) > 0.5:
        ra = patterns["recurrence_analysis"]
        ra["id"] = "recurrence_determinism"
        ra["pattern_type"] = "recurrence"
        hypotheses.append(_pattern_to_hypothesis(ra, "recurrence"))
    
    if "mutual_information_network" in patterns:
        mi = patterns["mutual_information_network"]
        if mi.get("most_predictive_low_sync"):
            mi["id"] = "mi_predictive_tag"
            mi["pattern_type"] = "mutual_info"
            hypotheses.append(_pattern_to_hypothesis(mi, "mutual_info"))
    
    if "topological_features" in patterns and patterns["topological_features"].get("detected_cycles", 0) > 0:
        tf = patterns["topological_features"]
        tf["id"] = "topology_cycle"
        tf["pattern_type"] = "topology"
        hypotheses.append(_pattern_to_hypothesis(tf, "topology"))
    
    if "symmetries" in patterns:
        for i, sym in enumerate(patterns["symmetries"][:3]):
            sym["id"] = f"symmetry_{i}"
            sym["pattern_type"] = "symmetry"
            hypotheses.append(_pattern_to_hypothesis(sym, "symmetry"))
    
    if "conservation_laws" in patterns:
        for i, cl in enumerate(patterns["conservation_laws"][:3]):
            cl["id"] = f"conservation_{i}"
            cl["pattern_type"] = "conservation"
            hypotheses.append(_pattern_to_hypothesis(cl, "conservation"))
    
    # Analogical transfer
    for h in list(hypotheses):
        hypotheses.extend(_analogical_transfer(h, domains))
    
    # Compositional
    for i in range(len(hypotheses)):
        for j in range(i+1, min(i+3, len(hypotheses))):
            comp = _compositional_combination(hypotheses[i], hypotheses[j])
            if comp:
                hypotheses.append(comp)
    
    # Add to graph
    graph = _load_sde_graph()
    for h in hypotheses:
        graph["nodes"][h["id"]] = h
    _save_sde_graph(graph)
    
    return json.dumps({
        "generated": len(hypotheses),
        "hypotheses": hypotheses
    }, ensure_ascii=False, indent=2)


# ===== SEQUENCE GENERATION (IAC-INV-019) =====

def _parse_sequence(text: str, markers: list = None) -> List[str]:
    """Extract steps from instruction text."""
    if not markers:
        marker_patterns = [
            r'\b(?:затем|потом|далее|сначала|после|шаг|step|then|next|after|first)\b',
            r'\b(?:->|=>|→)\b',
            r'\b(?:1\.|2\.|3\.|4\.|5\.|6\.|7\.|8\.)\s',
        ]
        markers = []
        for pat in marker_patterns:
            for m in re.finditer(pat, text, re.IGNORECASE):
                markers.append({"marker": m.group(0), "position": m.start()})

    if not markers:
        sentences = re.split(r'[.!?;]\s+', text)
        return [s.strip() for s in sentences if len(s.strip()) > 10]

    sorted_markers = sorted(markers, key=lambda x: x["position"])
    steps = []
    for i, m in enumerate(sorted_markers):
        start = m["position"]
        end = sorted_markers[i + 1]["position"] if i + 1 < len(sorted_markers) else len(text)
        steps.append(text[start:end].strip())

    return steps


def _generate_permutations(steps: List[str], max_count: int = 10) -> List[List[str]]:
    """Generate alternative step orderings (limited permutations)."""
    if len(steps) <= 1:
        return [steps]
    if len(steps) > 6:
        steps = steps[:6]

    n = len(steps)
    indices = list(range(n))
    permutations = []

    from itertools import permutations as permute
    for p in permute(indices):
        if len(permutations) >= max_count:
            break
        if p != tuple(indices):
            permutations.append([steps[i] for i in p])

    return permutations[:max_count]


def _score_sequence(steps: List[str], original: List[str]) -> float:
    """Score alternative sequence: lower = more likely correct."""
    score = 0.0
    for i, step in enumerate(steps):
        sl = step.lower()
        if any(k in sl for k in ["результат", "итог", "output", "result"]):
            score += 0.1
        ref_match = re.search(r'(?:step|шаг|этап)\s*(\d+)', sl, re.IGNORECASE)
        if ref_match and int(ref_match.group(1)) > i + 1:
            score += 0.2

    for a, b in zip(steps, original[:len(steps)]):
        if a != b:
            score += 0.05

    return round(min(1.0, score), 3)


def tool_sde_generate_sequences(text: str, max_permutations: int = 10) -> str:
    """
    Generate alternative instruction sequences (IAC-INV-019).
    Takes instruction text, extracts steps, generates alternative orderings.
    """
    if not text or len(text) < 30:
        return json.dumps({"error": "insufficient_text"})

    steps = _parse_sequence(text)
    if len(steps) < 2:
        return json.dumps({"original_sequence": steps, "alternatives": []})

    alternatives = _generate_permutations(steps, max_permutations)
    scored = [{
        "sequence": alt,
        "score": _score_sequence(alt, steps),
        "changes_from_original": sum(1 for a, b in zip(alt, steps) if a != b),
    } for alt in alternatives]
    scored.sort(key=lambda x: x["score"])

    return json.dumps({
        "step_count": len(steps),
        "original_sequence": [{"index": i + 1, "step": s[:200]} for i, s in enumerate(steps)],
        "alternatives_count": len(scored),
        "best_alternative": scored[0] if scored else None,
        "alternatives": scored[:5],
    }, ensure_ascii=False, indent=2)


def tool_sde_generate_graph_transforms(graph_json: str, target_metric: str = "density") -> str:
    """
    Generate graph transformations to improve topological consistency (IAC-INV-023).
    
    Args:
        graph_json: JSON graph {nodes: [...], edges: [...]}
        target_metric: "density" | "connectivity" | "balance"
    
    Returns:
        JSON: suggested transformations
    """
    try:
        graph = json.loads(graph_json)
    except:
        return json.dumps({"error": "invalid_graph_json"})

    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    if not nodes:
        return json.dumps({"error": "no_nodes"})

    node_ids = set(n.get("id", "") for n in nodes if n.get("id"))

    # Build adjacency
    adj = defaultdict(set)
    for e in edges:
        adj[e.get("from", "")].add(e.get("to", ""))
        adj[e.get("to", "")].add(e.get("from", ""))

    # Find disconnected nodes
    disconnected = [nid for nid in node_ids if not adj.get(nid)]

    # Find potential new edges (co-occurring nodes with shared properties)
    transforms = []

    if disconnected:
        for d in disconnected:
            # Suggest connecting to most connected node
            most_connected = max(node_ids - {d}, key=lambda x: len(adj.get(x, set())), default=None)
            if most_connected:
                transforms.append({
                    "type": "add_edge",
                    "from": d,
                    "to": most_connected,
                    "reason": "connect_isolated_node",
                    "score": 0.7,
                })

    # Suggest edge removal for extremely high-degree nodes
    for nid, neighbors in adj.items():
        if len(neighbors) > len(node_ids) * 0.5:  # Connected to >50% of nodes — might be noise
            transforms.append({
                "type": "consider_prune",
                "node": nid,
                "current_degree": len(neighbors),
                "reason": "overconnected_hub",
                "score": 0.3,
            })

    density = (2 * len(edges)) / max(1, len(node_ids) * (len(node_ids) - 1)) if len(node_ids) > 1 else 0

    return json.dumps({
        "node_count": len(node_ids),
        "edge_count": len(edges),
        "current_density": round(density, 4),
        "disconnected_nodes": len(disconnected),
        "suggested_transforms": transforms[:10],
    }, ensure_ascii=False, indent=2)