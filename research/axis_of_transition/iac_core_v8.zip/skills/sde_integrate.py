"""
sde_integrate.py — Architecture Integration for Scientific Discovery Engine
Safely integrates validated invariants as architectural primitives.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

ARCH_INVARIANTS_FILE = Path("architectural_invariants.json")
SKILLS_DIR = Path("skills")


def _load_invariants() -> List[Dict]:
    if ARCH_INVARIANTS_FILE.exists():
        try:
            return json.loads(ARCH_INVARIANTS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []


def _save_invariants(invariants: List[Dict]):
    ARCH_INVARIANTS_FILE.write_text(json.dumps(invariants, ensure_ascii=False, indent=2), encoding="utf-8")


def _generate_skill_file(invariant: Dict) -> str:
    """Generate a complete skill Python file from invariant."""
    impl = invariant.get("implementation", {})
    skill_name = impl.get("skill_name", f"invariant_{invariant.get('type', 'unknown').lower()}")
    functions = impl.get("functions", [])
    description = impl.get("description", "")
    core_logic = impl.get("core_logic", "# TODO: implement")
    
    # Build function stubs
    func_stubs = []
    for f in functions:
        func_stubs.append(f'''
def {f.split('(')[0].replace('def ', '')}({f.split('(')[1].split(')')[0]}):
    """
    {description}
    """
    # {core_logic}
    return {{"status": "stub", "function": "{f.split('(')[0].replace('def ', '')}", "invariant": "{invariant.get('statement', '')[:60]}"}}
''')
    
    content = f'''"""
{skill_name} — Auto-generated from architectural invariant
Invariant: {invariant.get('statement', '')}
Type: {invariant.get('type', 'UNKNOWN')}
Domains: {invariant.get('domains', [])}
Posterior: {invariant.get('posterior_plausibility', 0):.3f}
Generated: {invariant.get('extracted_at', '')}
"""

import json
from typing import Any, List, Dict, Callable, Tuple

{"".join(func_stubs)}

# Auto-registration via skills/__init__.py
# Functions with tool_ prefix are automatically registered
'''
    
    return content


def _validate_skill(skill_content: str) -> Dict:
    """Validate generated skill for syntax and safety."""
    issues = []
    
    # Check for dangerous patterns
    dangerous = ["exec(", "eval(", "__import__", "subprocess", "os.system", "open(", "write("]
    for d in dangerous:
        if d in skill_content:
            issues.append(f"Potentially unsafe pattern: {d}")
    
    # Check for tool_ prefix
    tool_funcs = re.findall(r'def (tool_\w+)', skill_content)
    if not tool_funcs:
        issues.append("No tool_ functions found")
    
    # Try to compile
    try:
        compile(skill_content, "<generated_skill>", "exec")
    except SyntaxError as e:
        issues.append(f"Syntax error: {e}")
    
    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "tool_functions": tool_funcs
    }


def _safe_write_skill(skill_name: str, content: str) -> Dict:
    """Write skill file with backup and validation."""
    skill_file = SKILLS_DIR / f"{skill_name}.py"
    
    # Backup existing
    if skill_file.exists():
        backup = SKILLS_DIR / f"{skill_name}.py.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        skill_file.rename(backup)
    
    # Write new
    try:
        skill_file.write_text(content, encoding="utf-8")
        return {"written": True, "path": str(skill_file)}
    except Exception as e:
        return {"written": False, "error": str(e)}


def tool_sde_integrate_invariant(invariant_id: str = "", dry_run: bool = True) -> str:
    """
    Integrate validated invariant into architecture as skill.
    
    Args:
        invariant_id: Specific invariant to integrate (or empty for all ready)
        dry_run: If True, only validate without writing
    
    Returns:
        JSON with integration results
    """
    invariants = _load_invariants()
    
    # Filter ready invariants
    ready = [inv for inv in invariants if inv.get("status") == "active"]
    
    if invariant_id:
        ready = [inv for inv in ready if inv.get("statement", "").startswith(invariant_id)]
    
    if not ready:
        return json.dumps({"error": "no_ready_invariants"})
    
    results = []
    for inv in ready:
        # Generate skill
        skill_content = _generate_skill_file(inv)
        
        # Validate
        validation = _validate_skill(skill_content)
        
        result = {
            "invariant": inv.get("statement", "")[:60],
            "type": inv.get("type", "UNKNOWN"),
            "skill_name": inv.get("implementation", {}).get("skill_name", "unknown"),
            "validation": validation,
            "dry_run": dry_run
        }
        
        if not dry_run and validation["valid"]:
            write_result = _safe_write_skill(inv.get("implementation", {}).get("skill_name", ""), skill_content)
            result["write_result"] = write_result
            
            # Update invariant status
            inv["status"] = "integrated"
            inv["integrated_at"] = datetime.now().isoformat()
            inv["skill_file"] = write_result.get("path", "")
        elif dry_run:
            result["note"] = "Dry run - not written. Set dry_run=false to integrate."
        
        results.append(result)
    
    if not dry_run:
        _save_invariants(invariants)
    
    return json.dumps({
        "processed": len(ready),
        "integrated": sum(1 for r in results if r.get("write_result", {}).get("written", False)),
        "results": results
    }, ensure_ascii=False, indent=2)


def tool_sde_integration_status() -> str:
    """Show integration pipeline status."""
    invariants = _load_invariants()
    
    status_counts = {}
    for inv in invariants:
        s = inv.get("status", "unknown")
        status_counts[s] = status_counts.get(s, 0) + 1
    
    # Check existing skills
    existing_skills = []
    for f in SKILLS_DIR.glob("*.py"):
        if not f.name.startswith("_") and f.name != "sde_integrate.py":
            existing_skills.append(f.stem)
    
    return json.dumps({
        "invariants": len(invariants),
        "by_status": status_counts,
        "existing_skills": existing_skills,
        "skills_dir": str(SKILLS_DIR),
        "invariants_file": str(ARCH_INVARIANTS_FILE)
    }, ensure_ascii=False, indent=2)