from core.structure_classifier import StructureClassifier
from core.statistical_verifier import StatisticalVerifier
from core.somatic import SomaticPracticesEngine

class PresentationEngine:
    def __init__(self):
        self.structure_classifier = StructureClassifier()
        self.verifier = StatisticalVerifier()
        self.somatic = SomaticPracticesEngine()

    def present(self, data, mode='auto'):
        structure_type = self.structure_classifier.classify(data)
        
        # Определение режима презентации
        if mode == 'auto':
            mode = self._recommend_mode(data, structure_type)
            
        # Применение фазовых переходов
        if 'phase_transition' in self.structure_classifier.detect_patterns(data):
            data = self._apply_phase_transition(data)
            
        # Обработка разных типов структур
        if structure_type == 'narrative':
            return self._present_narrative(data, mode)
        elif structure_type == 'instruction':
            return self._present_instruction(data, mode)
        elif structure_type == 'diagram':
            return self._present_diagram(data, mode)
        elif structure_type == 'torus':
            return self._present_torus(data)
        else:
            return data

    def _recommend_mode(self, data, structure_type):
        # Автоматический выбор режима на основе плотности данных
        density_score = self.verifier.calculate_density(data)
        if density_score > 0.7:
            return 'simplified'
        elif density_score < 0.3:
            return 'detailed'
        else:
            return 'balanced'

    def _apply_phase_transition(self, data):
        # Резкое изменение уровня сложности
        simplified_part = self._simplify_complex_concepts(data[:len(data)//2])
        detailed_part = self._add_depth(data[len(data)//2:])
        return simplified_part + detailed_part

    def _present_torus(self, data):
        # Замыкание информации в циклическую структуру
        opening = data[0]
        core = data[1:-1]
        closing = self._create_closure(opening, data[-1])
        return [opening] + core + [closing]

    def _create_closure(self, start, end):
        # Создание точки съёма с возвратом к началу
        return f"{end} (возвращаясь к '{start}' с новым пониманием)"

    def _present_narrative(self, data, mode):
        # Реализация мицелиальной структуры
        main_branch = data[0]
        branches = [f"- {branch}" for branch in data[1:]]
        return [main_branch] + branches

    def _present_instruction(self, data, mode):
        # Добавление точек съёма
        return [f"★ {item}" if i % 3 == 0 else item 
                for i, item in enumerate(data)]

    def _present_diagram(self, data, mode):
        # Генерация mermaid-диаграмм
        return f"```mermaid\ngraph LR\n{data}\n```"