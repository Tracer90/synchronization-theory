"""
Astronomy Skill: NumberAnalyzer for astronomical cycles
"""
import json
import math


def tool_number_analyzer(number: str) -> str:
    """
    Analyze a number for astronomical significance.
    
    Args:
        number: The number to analyze (as string to support large numbers)
    
    Returns:
        JSON: analysis result
    """
    try:
        num = float(number)
    except ValueError:
        return json.dumps({"error": "Invalid number"})
    
    # Known astronomical cycles in days
    cycles = {
        "lunar_month": 29.53059,
        "solar_year": 365.2422,
        "jupiter_year": 4332.59,
        "venus_year": 224.701,
        "mars_year": 686.971,
    }
    
    # Check if the number is close to a known cycle
    results = []
    for name, days in cycles.items():
        ratio = num / days
        if 0.95 < ratio < 1.05:  # within 5%
            results.append({
                "cycle": name,
                "days": days,
                "ratio": ratio,
                "match": "close"
            })
        elif ratio.is_integer() or (1/ratio).is_integer():
            results.append({
                "cycle": name,
                "days": days,
                "ratio": ratio,
                "match": "harmonic"
            })
    
    return json.dumps({
        "number": number,
        "analysis": results
    })