"""
Web skill — search, fetch. Returns sync_wrap contract.
"""

import json
import re
import warnings

def _wrap(result: str, delta: float) -> str:
    return json.dumps({"result": result, "sync_delta": delta,
        "sync_info": {"delta": delta, "actual_score": delta}})

def tool_search(query: str, max_results: int = 5) -> str:
    """Search: DDG direct -> Bing fallback"""
    warnings.filterwarnings("ignore")
    try:
        from curl_cffi import requests as curl_req
        from lxml import html
        url = f"https://html.duckduckgo.com/html/?q={query.replace(' ', '+')}"
        r = curl_req.get(url, headers={"User-Agent": "Mozilla/5.0"}, impersonate="chrome124", timeout=15)
        tree = html.fromstring(r.text)
        out = []
        for i, a in enumerate(tree.cssselect("a.result__a")[:max_results]):
            title = a.text_content().strip()
            href = a.get("href", "")
            snip = tree.cssselect("a.result__snippet")
            snippet = snip[i].text_content().strip() if i < len(snip) else ""
            out.append(f"- {title}\n  {snippet[:200]}\n  {href}")
        if out:
            text = "\n\n".join(out)
            return _wrap(text, 0.12)
    except:
        pass
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results, backend="bing"))
        if results:
            out = []
            for r in results:
                out.append(f"- {r.get('title','')}\n  {r.get('body','')[:200]}\n  {r.get('href','')}")
            return _wrap("\n\n".join(out), 0.15)
    except:
        pass
    return _wrap("Nothing found.", 0.6)

def tool_fetch(url: str) -> str:
    """Fetch page text"""
    try:
        import httpx
        r = httpx.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}, follow_redirects=True, timeout=15)
        r.raise_for_status()
        text = re.sub(r'<[^>]+>', ' ', r.text)
        text = re.sub(r'\s+', ' ', text).strip()[:3000]
        return _wrap(text, 0.1)
    except Exception as e:
        return _wrap(f"[error] {e}", 0.65)
