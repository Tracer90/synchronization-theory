"""
skills/ — dynamic skill loader.
Any .py file with tool_* functions auto-registers.
"""

import ast
import importlib
import inspect
import pkgutil
import traceback
from pathlib import Path

REGISTRY = {}
HELP_LINES = []
LOADED_MODULES = []
FAILED_MODULES = []
SKILL_DIR = Path(__file__).parent


def _check_syntax(filepath: Path) -> tuple:
    try:
        ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))
        return True, ""
    except SyntaxError as e:
        return False, f"SyntaxError at {e.lineno}:{e.offset}: {e.msg}"


for importer, mod_name, is_pkg in pkgutil.iter_modules([str(SKILL_DIR)]):
    if mod_name.startswith("_"):
        continue

    filepath = SKILL_DIR / f"{mod_name}.py"
    ok, err = _check_syntax(filepath) if filepath.exists() else (True, "")
    if not ok:
        FAILED_MODULES.append({"module": mod_name, "reason": err})
        continue

    try:
        module = importlib.import_module(f".{mod_name}", __package__)
        tool_count = 0
        for name, func in inspect.getmembers(module, inspect.isfunction):
            if name.startswith("tool_"):
                tool_name = name[5:]
                REGISTRY[tool_name] = func
                tool_count += 1
                doc = inspect.getdoc(func) or ""
                first_line = doc.split("\n")[0].strip()
                if first_line:
                    HELP_LINES.append(f"{tool_name} — {first_line}")
        LOADED_MODULES.append({"module": mod_name, "tools": tool_count})
    except Exception:
        FAILED_MODULES.append({
            "module": mod_name,
            "reason": traceback.format_exc().strip().split("\n")[-1],
        })

HELP = "\n".join(sorted(HELP_LINES))
LOAD_REPORT = {
    "loaded": LOADED_MODULES,
    "failed": FAILED_MODULES,
    "total_loaded": len(LOADED_MODULES),
    "total_failed": len(FAILED_MODULES),
    "total_tools": len(REGISTRY),
}
