"""
observer.py — Observer Lens: Мета-наблюдатель IAC (Модуль 9)

Три уровня наблюдения:
  1-й уровень (локальный) — отдельные циклы, триггеры, сделки
  2-й уровень (структурный) — связи между циклами, паттерны, инварианты
  3-й уровень (мета-наблюдатель) — вся система целиком

Функции:
  - Оценка согласованности всех модулей
  - Выявление слепых зон (blinding gaps)
  - Генерация общей карты связей
  - Рекомендации по коррекции направления
  - Самооценка эффективности IAC
"""

import json
import re
from datetime import datetime
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Optional, Any

MEMORY_FILE = Path("MEMORY.md")
PATTERNS_FILE = Path("sync_patterns.json")
INVARIANTS_FILE = Path("architectural_invariants.json")
LIVE_LOG_FILE = Path("LIVE_LOG.md")
META_SYNC_FILE = Path("meta_sync.jsonl")

# ----------------------------------------------------------------
# Карта модулей — что видит каждый, что пропускает
# ----------------------------------------------------------------

MODULE_MAP: Dict[str, Dict] = {
    "sync_engine": {
        "file": "skills/sync.py",
        "layer": 1,
        "sees": ["sync_delta", "sync_score", "patterns", "memory"],
        "misses": ["cross-module contradictions", "long-term drift"],
        "inputs_from": ["field_interface", "anticipation"],
        "outputs_to": ["meta_observer", "anticipation", "guard"],
        "tools": ["sync_score", "sync_delta", "sync_fact", "sync_filter", "sync_status",
                  "sync_wrap", "sync_objective", "sync_learn", "sync_forget",
                  "sync_list_patterns", "sync_health"],
    },
    "field_interface": {
        "file": "skills/field.py",
        "layer": 1,
        "sees": ["triggers", "resonance", "contradiction_markers", "processing_mode"],
        "misses": ["trigger significance over time", "false positive rate"],
        "inputs_from": ["memory", "patterns_db", "invariants_db"],
        "outputs_to": ["sync_engine", "negative_intelligence", "structure_classifier"],
        "tools": ["field_scan", "field_sensitivity", "field_resonance", "field_status",
                  "field_conflicts", "field_set_processing_mode", "field_scan_classified"],
    },
    "negative_intelligence": {
        "file": "skills/negative.py",
        "layer": 1,
        "sees": ["logical_fallacies", "empirical_contradictions", "self_reference",
                 "cross_domain_violations", "order_errors", "topological_conflicts"],
        "misses": ["own bias against certain hypothesis types", "false positive attacks"],
        "inputs_from": ["field_interface", "invariants_db", "memory"],
        "outputs_to": ["sync_engine", "sde_pipeline"],
        "tools": ["negative_attack", "negative_attack_batch", "negative_attack_self",
                  "negative_check", "negative_check_instruction", "negative_status"],
    },
    "sde_pipeline": {
        "file": "skills/sde_*.py",
        "layer": 1,
        "sees": ["hypotheses", "patterns", "invariants", "contradictions", "falsification"],
        "misses": ["external validation of findings", "practical applicability"],
        "inputs_from": ["negative_intelligence", "field_interface", "sync_engine"],
        "outputs_to": ["meta_observer", "invariants_db"],
        "tools": ["sde_falsify_cycle", "sde_extract_invariants", "sde_extract_patterns",
                  "sde_diagrammatic_analyze", "sde_diagrammatic_apply", "sde_generate_sequences"],
    },
    "structure_classifier": {
        "file": "skills/structure_classifier.py",
        "layer": 2,
        "sees": ["data_type", "is_instruction", "is_reversible", "is_mechanical"],
        "misses": ["classification accuracy over time", "edge cases"],
        "inputs_from": ["field_interface", "sync_engine"],
        "outputs_to": ["meta_observer", "field_interface"],
        "tools": ["structure_classify", "detect_markers", "detect_rtl",
                  "detect_mechanical", "build_graph", "classify_and_graph"],
    },
    "statistical_verifier": {
        "file": "skills/statistical_verifier.py",
        "layer": 2,
        "sees": ["number_patterns", "statistical_significance", "auto_verification"],
        "misses": ["context-dependent validity", "small sample bias"],
        "inputs_from": ["sync_engine", "memory", "patterns_db"],
        "outputs_to": ["meta_observer", "invariants_db"],
        "tools": ["auto_verify_and_promote", "verify_number_pattern",
                  "classify_number", "promote_pattern"],
    },
    "somatic_engine": {
        "file": "skills/somatic.py",
        "layer": 2,
        "sees": ["somatic_markers", "body_stress_level", "practice_suggestions"],
        "misses": ["longitudinal body-mind correlation", "false somatic positives"],
        "inputs_from": ["sync_engine", "field_interface"],
        "outputs_to": ["meta_observer"],
        "tools": ["somatic_detect", "somatic_map_practice", "somatic_pendulate",
                  "somatic_feedback", "somatic_status"],
    },
    "anticipation": {
        "file": "skills/anticipation.py",
        "layer": 2,
        "sees": ["predicted_sync", "meta_sync_drift", "calibration_over_time"],
        "misses": ["external factors not in model", "phase transitions"],
        "inputs_from": ["sync_engine", "meta_observer"],
        "outputs_to": ["sync_engine", "meta_observer"],
        "tools": ["predict_sync", "validate_prediction", "meta_sync",
                  "meta_sync_status", "meta_sync_trend"],
    },
    "translation": {
        "file": "skills/translate.py",
        "layer": 2,
        "sees": ["cross-model mappings", "terminology_bridge"],
        "misses": ["untranslatable concepts", "cultural context loss"],
        "inputs_from": ["sync_engine"],
        "outputs_to": ["meta_observer"],
        "tools": ["translate", "translate_batch", "translate_mapping"],
    },
    "meta_learning": {
        "file": "skills/meta.py",
        "layer": 2,
        "sees": ["pattern_db", "performance_metrics", "optimization_strategies"],
        "misses": ["overfitting to historical data", "regime changes"],
        "inputs_from": ["sync_engine", "patterns_db"],
        "outputs_to": ["meta_observer", "sync_engine"],
        "tools": ["meta_learn", "meta_optimize", "meta_predict", "meta_export",
                  "meta_import", "meta_report"],
    },
    "mods_engine": {
        "file": "skills/mods.py",
        "layer": 3,
        "sees": ["presets", "themes", "custom_rules"],
        "misses": ["mod compatibility matrix", "conflict detection between mods"],
        "inputs_from": ["meta_observer"],
        "outputs_to": ["meta_observer"],
        "tools": ["mods_preset", "mods_stages", "mods_theme", "mods_rules"],
    },
    "locale_engine": {
        "file": "skills/locale.py",
        "layer": 3,
        "sees": ["language_mappings", "localized_strings"],
        "misses": ["semantic drift across languages", "partial translations"],
        "inputs_from": ["meta_observer"],
        "outputs_to": ["meta_observer"],
        "tools": ["locale_lang", "locale_t"],
    },
    "creativity_ui": {
        "file": "skills/creativity.py",
        "layer": 3,
        "sees": ["ui_layouts", "color_schemes", "animation_configs"],
        "misses": ["user experience metrics", "accessibility gaps"],
        "inputs_from": ["meta_observer"],
        "outputs_to": ["meta_observer"],
        "tools": ["layout", "color", "animation", "font", "icon", "nav"],
    },
    "code_tools": {
        "file": "skills/code.py",
        "layer": 3,
        "sees": ["syntax_errors", "lint_issues", "code_snapshots"],
        "misses": ["semantic correctness", "architectural drift"],
        "inputs_from": ["sync_engine"],
        "outputs_to": ["meta_observer"],
        "tools": ["edit", "backup", "syntax", "lint", "rollback"],
    },
    "web_tools": {
        "file": "skills/web.py",
        "layer": 3,
        "sees": ["search_results", "web_content"],
        "misses": ["information quality assessment", "source credibility"],
        "inputs_from": ["meta_observer"],
        "outputs_to": ["field_interface", "meta_observer"],
        "tools": ["search", "fetch"],
    },
}

# ----------------------------------------------------------------
# Внутреннее состояние Observer Lens
# ----------------------------------------------------------------

_OBSERVER_STATE: Dict = {
    "observation_count": 0,
    "last_observation": None,
    "consistency_history": [],
    "blind_spot_history": [],
    "recommendations_log": [],
    "module_health_scores": {},
}

# Домены, охваченные системой
_COVERED_DOMAINS = {
    "architecture", "biology", "computation", "control", "cybernetics",
    "information", "information_theory", "linguistics", "mathematics",
    "ml", "neuroscience", "physics", "psychology", "somatic",
    "therapy", "trauma_therapy", "education", "anthropology", "religion",
    "history", "art", "graph_theory", "network_science", "semantics",
    "parsing", "cryptography", "pattern_recognition", "astronomy",
    "archaeology", "geometry", "cosmology", "philosophy",
    "evolution", "economics", "personalization", "autonomy",
    "preventive_care", "machine_learning", "meta-cognition",
    "recursion", "self-description", "information-field",
}

# Потенциально непокрытые домены — слепые зоны
_POTENTIAL_DOMAINS = {
    "ethics", "law", "medicine", "chemistry", "materials_science",
    "climate", "energy", "agriculture", "transport", "urbanism",
    "sociology", "political_science", "game_theory", "finance",
    "music", "literature", "cinema", "design", "robotics",
    "quantum_computing", "blockchain", "iot", "vr_ar",
    "linguistic_anthropology", "neuro_linguistics", "cognitive_science",
    "behavioral_economics", "complexity_science", "systems_biology",
    "epigenetics", "microbiome", "oceanography", "geology",
}

# ----------------------------------------------------------------
# Вспомогательные функции
# ----------------------------------------------------------------

def _load_data() -> Dict[str, Any]:
    """Собрать все доступные данные системы."""
    data = {}

    if MEMORY_FILE.exists():
        data["memory"] = MEMORY_FILE.read_text(encoding="utf-8")
        data["memory_entries"] = len(re.findall(r'- \[([^\]]+)\]\s*(.+)', data["memory"]))

    if PATTERNS_FILE.exists():
        try:
            data["patterns"] = json.loads(PATTERNS_FILE.read_text(encoding="utf-8"))
            data["pattern_count"] = len(data["patterns"])
        except:
            data["patterns"] = []
            data["pattern_count"] = 0

    if INVARIANTS_FILE.exists():
        try:
            data["invariants"] = json.loads(INVARIANTS_FILE.read_text(encoding="utf-8"))
            data["invariant_count"] = len(data["invariants"])
        except:
            data["invariants"] = []
            data["invariant_count"] = 0

    if LIVE_LOG_FILE.exists():
        log_text = LIVE_LOG_FILE.read_text(encoding="utf-8")
        cycles = re.findall(r'## (\d{4}-\d{2}-\d{2} \d{2}:\d{2})', log_text)
        data["log_cycles"] = len(cycles)

    if META_SYNC_FILE.exists():
        entries = []
        for line in META_SYNC_FILE.read_text(encoding="utf-8").strip().split("\n"):
            try:
                entries.append(json.loads(line))
            except:
                pass
        data["meta_sync_entries"] = len(entries)

    # Count cycle traces in MEMORY.md (inserted by auto_save_cycle_trace)
    if MEMORY_FILE.exists():
        data["cycle_traces"] = len(re.findall(r'\[trace\]', MEMORY_FILE.read_text(encoding="utf-8")))

    # Check for available tools
    try:
        import skills
        data["has_neg_quality"] = "negative_quality" in skills.REGISTRY
        data["has_memory_compress"] = "memory_compress" in skills.REGISTRY
    except:
        data["has_neg_quality"] = False
        data["has_memory_compress"] = False

    return data


def _module_consistency_score(data: Dict) -> Tuple[float, List[Dict]]:
    """Оценить согласованность между модулями."""
    issues = []
    score = 1.0

    # 1. Field Interface vs Sync Engine — коррелируют ли триггеры с паттернами?
    patterns = data.get("patterns", [])
    high_weight_pats = [p for p in patterns if abs(p.get("weight", 0)) > 0.5]
    if len(high_weight_pats) > len(patterns) * 0.3:
        issues.append({
            "modules": ["field_interface", "sync_engine"],
            "type": "high_weight_skew",
            "detail": f"{len(high_weight_pats)}/{len(patterns)} patterns have extreme weights",
            "severity": 0.3,
        })
        score -= 0.05

    # 2. Negative Intelligence vs Invariants — выживают ли инварианты атаки?
    invariants = data.get("invariants", [])
    inactive = [i for i in invariants if i.get("status") != "active"]
    if inactive:
        issues.append({
            "modules": ["negative_intelligence", "sde_pipeline"],
            "type": "inactive_invariants",
            "detail": f"{len(inactive)} invariants inactive — были ли они falsified?",
            "severity": 0.4,
        })
        score -= 0.08

    # 3. Memory growth vs pattern accumulation
    mem_entries = data.get("memory_entries", 0)
    pat_count = data.get("pattern_count", 0)
    if mem_entries > 10 and pat_count < 3:
        issues.append({
            "modules": ["sync_engine", "meta_learning"],
            "type": "memory_surplus",
            "detail": f"{mem_entries} memory entries but only {pat_count} patterns — knowledge not compressed",
            "severity": 0.5,
        })
        score -= 0.1

    # 4. Anticipation vs Meta-Sync — калибровка предсказаний
    meta_sync_entries = data.get("meta_sync_entries", 0)
    if meta_sync_entries > 10:
        issues.append({
            "modules": ["anticipation", "sync_engine"],
            "type": "info",
            "detail": f"{meta_sync_entries} meta-sync records — anticipation active",
            "severity": 0.1,
        })
    elif meta_sync_entries == 0 and data.get("log_cycles", 0) > 3:
        issues.append({
            "modules": ["anticipation"],
            "type": "unavailable",
            "detail": "Meta-sync tracking absent — anticipation calibration not measured",
            "severity": 0.4,
        })
        score -= 0.06

    # 5. Invariant type coverage
    invariant_types = Counter(i.get("type", "?").split("_")[0] for i in invariants)
    total_inv = len(invariants)
    if total_inv > 0:
        dominant_type = invariant_types.most_common(1)[0]
        if dominant_type[1] / total_inv > 0.4:
            issues.append({
                "modules": ["sde_pipeline", "structure_classifier"],
                "type": "type_monopoly",
                "detail": f"Type '{dominant_type[0]}' dominates ({dominant_type[1]}/{total_inv} invariants)",
                "severity": 0.35,
            })
            score -= 0.04

    return max(0.0, min(1.0, score)), issues


def _detect_blind_spots(data: Dict) -> List[Dict]:
    """Выявить слепые зоны — области без достаточного покрытия."""
    blind_spots = []

    # 1. Непокрытые потенциальные домены
    invariants = data.get("invariants", [])
    covered = set()
    for inv in invariants:
        for d in inv.get("domains", []):
            covered.add(d.lower().replace(" ", "_"))
    covered |= _COVERED_DOMAINS

    uncovered = _POTENTIAL_DOMAINS - covered
    if uncovered:
        blind_spots.append({
            "type": "domain_gap",
            "level": 2,
            "detail": f"Uncovered domains: {', '.join(sorted(list(uncovered)[:10]))}",
            "count": len(uncovered),
            "severity": 0.5 if len(uncovered) > 20 else 0.3,
        })

    # 2. Потеря данных между циклами
    mem_entries = data.get("memory_entries", 0)
    log_cycles = data.get("log_cycles", 0)
    cycle_traces = data.get("cycle_traces", 0)
    if log_cycles > 5 and mem_entries < log_cycles * 0.5:
        detail = f"{log_cycles} cycles but only {mem_entries} memory entries"
        if cycle_traces > 0:
            detail += f" ({cycle_traces} cycle traces exist — auto_save active)"
        blind_spots.append({
            "type": "data_loss",
            "level": 1,
            "detail": detail,
            "severity": 0.6 if cycle_traces == 0 else 0.3,
        })

    # 3. Модули без видимых выходов
    for name, mod in MODULE_MAP.items():
        if mod.get("outputs_to") and "meta_observer" in mod["outputs_to"] and \
           len(mod["outputs_to"]) == 1:
            blind_spots.append({
                "type": "silo_module",
                "level": 2,
                "detail": f"Module '{name}' only outputs to meta_observer — potential silo",
                "module": name,
                "severity": 0.25,
            })

    # 4. Паттерны без domain
    patterns = data.get("patterns", [])
    no_domain = [p for p in patterns if not p.get("domain")]
    if len(no_domain) > len(patterns) * 0.4:
        blind_spots.append({
            "type": "unclassified_patterns",
            "level": 2,
            "detail": f"{len(no_domain)}/{len(patterns)} patterns lack domain classification",
            "severity": 0.45,
        })

    # 5. Отсутствие long-term tracking
    if log_cycles < 2:
        blind_spots.append({
            "type": "insufficient_history",
            "level": 3,
            "detail": "Too few cycles to detect long-term trends",
            "severity": 0.7,
        })

    # 6. Нет отслеживания качества атак Negative Intelligence — теперь есть
    if not data.get("has_neg_quality", False):
        blind_spots.append({
            "type": "metric_gap",
            "level": 3,
            "detail": "No metric for false-positive rate in Negative Intelligence attacks",
            "severity": 0.4,
        })

    # 7. Нет memory_compress
    if not data.get("has_memory_compress", False):
        blind_spots.append({
            "type": "tool_gap",
            "level": 2,
            "detail": "No memory_compress tool — memory may grow unbounded",
            "severity": 0.35,
        })

    return sorted(blind_spots, key=lambda b: b["severity"], reverse=True)


def _generate_map(data: Dict) -> Dict:
    """Сгенерировать карту связей всех модулей."""
    nodes = []
    edges = []

    # Layer grouping
    layers = {1: [], 2: [], 3: []}
    for name, mod in MODULE_MAP.items():
        layer = mod.get("layer", 1)
        layers[layer].append(name)

        active = name in ("sync_engine", "field_interface", "negative_intelligence",
                          "sde_pipeline", "structure_classifier", "statistical_verifier",
                          "somatic_engine", "anticipation", "meta_learning",
                          "translation", "mods_engine", "locale_engine")
        nodes.append({
            "id": name,
            "label": name.replace("_", " ").title(),
            "layer": layer,
            "file": mod["file"],
            "active": active,
            "tools": len(mod.get("tools", [])),
        })

        for target in mod.get("outputs_to", []):
            if target in MODULE_MAP:
                edges.append({
                    "from": name,
                    "to": target,
                    "type": "output",
                })
        for source in mod.get("inputs_from", []):
            if source in MODULE_MAP:
                edges.append({
                    "from": source,
                    "to": name,
                    "type": "input",
                })

    # Calculate layer stats
    layer_stats = {}
    for l, names in layers.items():
        node_set = set(names)
        layer_edges = [e for e in edges if e["from"] in node_set or e["to"] in node_set]
        internal = [e for e in layer_edges if e["from"] in node_set and e["to"] in node_set]
        cross = [e for e in layer_edges if (e["from"] in node_set) != (e["to"] in node_set)]
        layer_stats[f"layer_{l}"] = {
            "modules": len(names),
            "internal_edges": len(internal),
            "cross_edges": len(cross),
            "density": round(len(internal) / max(1, len(names) * (len(names) - 1)), 3),
        }

    return {
        "nodes": nodes,
        "edges": edges,
        "total_modules": len(nodes),
        "total_edges": len(edges),
        "layers": layer_stats,
        "hub_modules": _find_hubs(nodes, edges),
    }


def _find_hubs(nodes: List[Dict], edges: List[Dict]) -> List[Dict]:
    """Найти модули-хабы (наибольшая связность)."""
    degree = defaultdict(int)
    for e in edges:
        degree[e["from"]] += 1
        degree[e["to"]] += 1

    hubs = []
    for n in nodes:
        d = degree.get(n["id"], 0)
        if d >= 3:
            hubs.append({
                "id": n["id"],
                "degree": d,
                "layer": n["layer"],
            })
    return sorted(hubs, key=lambda h: h["degree"], reverse=True)


def _assess_self(data: Dict) -> Dict:
    """Самооценка эффективности IAC."""
    assessment = {
        "overall_health": "unknown",
        "strengths": [],
        "weaknesses": [],
        "scores": {},
    }

    # Синхронизация
    patterns = data.get("patterns", [])
    avg_weight = sum(abs(p.get("weight", 0)) for p in patterns) / max(1, len(patterns))
    if avg_weight < 0.2:
        assessment["scores"]["sync_quality"] = round(1.0 - avg_weight * 2, 2)
        assessment["strengths"].append("Low average pattern weight — good sync")
    elif avg_weight > 0.5:
        assessment["scores"]["sync_quality"] = round(max(0.0, 1.0 - avg_weight), 2)
        assessment["weaknesses"].append(f"High pattern weight ({avg_weight:.2f}) — sync degradation")
    else:
        assessment["scores"]["sync_quality"] = 0.7

    # Сжатие знаний
    mem_entries = data.get("memory_entries", 0)
    pat_count = data.get("pattern_count", 0)
    if mem_entries > 0:
        compress_ratio = pat_count / mem_entries
        assessment["scores"]["compression"] = round(min(1.0, compress_ratio * 5), 2)
        if compress_ratio < 0.3:
            assessment["weaknesses"].append(f"Low compression ({compress_ratio:.2f}) — raw memory dominates patterns")
        elif compress_ratio > 0.7:
            assessment["strengths"].append(f"Good compression ({compress_ratio:.2f})")
    else:
        assessment["scores"]["compression"] = 0.5

    # Покрытие доменов
    invariants = data.get("invariants", [])
    covered_domains = set()
    for inv in invariants:
        for d in inv.get("domains", []):
            covered_domains.add(d)
    domain_coverage = len(covered_domains) / max(1, len(_COVERED_DOMAINS | _POTENTIAL_DOMAINS))
    assessment["scores"]["domain_coverage"] = round(domain_coverage, 2)
    if domain_coverage < 0.2:
        assessment["weaknesses"].append(f"Narrow domain coverage ({domain_coverage:.2f})")
    elif domain_coverage > 0.5:
        assessment["strengths"].append(f"Broad domain coverage ({domain_coverage:.2f})")

    # Инвариантная сила
    inv_strength = [i.get("invariant_strength", 0) for i in invariants]
    if inv_strength:
        avg_strength = sum(inv_strength) / len(inv_strength)
        assessment["scores"]["invariant_strength"] = round(min(1.0, avg_strength / 5.0), 2)
        if avg_strength < 2.0:
            assessment["weaknesses"].append(f"Weak invariant strength (avg {avg_strength:.1f})")
        else:
            assessment["strengths"].append(f"Solid invariant strength (avg {avg_strength:.1f})")

    # Цикловая активность
    log_cycles = data.get("log_cycles", 0)
    assessment["scores"]["activity"] = round(min(1.0, log_cycles / 50), 2)
    if log_cycles < 10:
        assessment["weaknesses"].append(f"Low cycle count ({log_cycles}) — early stage")
    else:
        assessment["strengths"].append(f"Sustained activity ({log_cycles} cycles)")

    # Итоговая оценка
    scores = assessment["scores"]
    overall = sum(scores.values()) / max(1, len(scores))
    assessment["overall_score"] = round(overall, 2)

    if overall > 0.7:
        assessment["overall_health"] = "robust"
    elif overall > 0.5:
        assessment["overall_health"] = "stable"
    elif overall > 0.3:
        assessment["overall_health"] = "fragile"
    else:
        assessment["overall_health"] = "critical"

    return assessment


def _generate_recommendations(
    consistency_issues: List[Dict],
    blind_spots: List[Dict],
    self_assessment: Dict,
) -> List[Dict]:
    """Сгенерировать мета-рекомендации на основе анализа."""
    recommendations = []

    # Из consistency issues
    critical_issues = [i for i in consistency_issues if i.get("severity", 0) > 0.35]
    if critical_issues:
        recommendations.append({
            "priority": "high",
            "area": "consistency",
            "action": "Resolve cross-module contradictions",
            "detail": f"Top issue: {critical_issues[0].get('detail', '')}",
            "affected_modules": critical_issues[0].get("modules", []),
        })

    # Из blind spots
    high_severity_blind = [b for b in blind_spots if b.get("severity", 0) > 0.5]
    if high_severity_blind:
        recommendations.append({
            "priority": "high",
            "area": "blind_spots",
            "action": "Address critical blind spots",
            "detail": f"Top: {high_severity_blind[0].get('detail', '')}",
            "count": len(high_severity_blind),
        })

    medium_blind = [b for b in blind_spots if 0.3 < b.get("severity", 0) <= 0.5]
    if medium_blind:
        recommendations.append({
            "priority": "medium",
            "area": "blind_spots",
            "action": "Expand coverage in medium-priority areas",
            "detail": f"{len(medium_blind)} medium-severity blind spots",
        })

    # Из self-assessment
    weaknesses = self_assessment.get("weaknesses", [])
    if weaknesses:
        recommendations.append({
            "priority": "medium",
            "area": "self_assessment",
            "action": "Address system weaknesses",
            "detail": weaknesses[0],
            "all_weaknesses": weaknesses[:5],
        })

    # Мета-рекомендация по наблюдателю
    recommendations.append({
        "priority": "low",
        "area": "meta_observer",
        "action": "Run observer regularly to track system coherence",
        "detail": "Observer should be called every 5-10 cycles for trend visibility",
    })

    return recommendations


def _wrap_result(data: Dict, sync_delta: float = 0.05) -> str:
    return json.dumps({
        **data,
        "sync_delta": round(sync_delta, 3),
        "observer_timestamp": datetime.now().isoformat(),
    }, ensure_ascii=False, indent=2)


# ----------------------------------------------------------------
# Tool-функции
# ----------------------------------------------------------------

def tool_observer_lens(sources: str = "all") -> str:
    """
    Полный проход Мета-наблюдателя: все 3 уровня, согласованность + слепые зоны + карта + рекомендации.

    Args:
        sources: "all" или список уровней через запятую ("1,2,3")

    Returns:
        JSON: полный отчёт Observer Lens
    """
    _OBSERVER_STATE["observation_count"] += 1
    _OBSERVER_STATE["last_observation"] = datetime.now().isoformat()

    data = _load_data()
    source_set = set(sources.split(",")) if sources != "all" else {"1", "2", "3"}

    result = {
        "observation_n": _OBSERVER_STATE["observation_count"],
        "mode": "full_lens",
        "levels_active": sorted(source_set),
        "data_snapshot": {
            "memory_entries": data.get("memory_entries", 0),
            "cycle_traces": data.get("cycle_traces", 0),
            "patterns": data.get("pattern_count", 0),
            "invariants": data.get("invariant_count", 0),
            "cycles_logged": data.get("log_cycles", 0),
            "meta_sync_entries": data.get("meta_sync_entries", 0),
            "neg_quality_tool": data.get("has_neg_quality", False),
            "memory_compress_tool": data.get("has_memory_compress", False),
        },
    }

    # Level 1: Локальный
    consistency_score, consistency_issues = _module_consistency_score(data)
    if "1" in source_set:
        result["level_1_local"] = {
            "consistency_score": round(consistency_score * 100, 1),
            "interpretation": (
                "harmonious" if consistency_score > 0.8 else
                "minor_friction" if consistency_score > 0.6 else
                "notable_conflicts" if consistency_score > 0.4 else
                "significant_discord" if consistency_score > 0.2 else
                "critical_dissonance"
            ),
            "issues_found": len(consistency_issues),
            "issues": consistency_issues[:5],
        }

    # Level 2: Структурный
    blind_spots = _detect_blind_spots(data)
    sys_map = _generate_map(data)
    if "2" in source_set:
        result["level_2_structural"] = {
            "blind_spots": len(blind_spots),
            "top_blind_spots": blind_spots[:5],
            "modules_total": sys_map["total_modules"],
            "connections_total": sys_map["total_edges"],
            "hub_modules": sys_map["hub_modules"][:5],
            "layer_stats": sys_map["layers"],
        }

    # Level 3: Мета
    self_assess = _assess_self(data)
    recommendations = _generate_recommendations(consistency_issues, blind_spots, self_assess)
    if "3" in source_set:
        result["level_3_meta"] = {
            "self_assessment": self_assess,
            "recommendations": recommendations,
            "system_trajectory": (
                "converging" if self_assess.get("overall_score", 0) > 0.65 else
                "stabilizing" if self_assess.get("overall_score", 0) > 0.5 else
                "exploring" if self_assess.get("overall_score", 0) > 0.35 else
                "diverging"
            ),
        }

    # Сохранить в историю
    _OBSERVER_STATE["consistency_history"].append({
        "n": _OBSERVER_STATE["observation_count"],
        "score": consistency_score,
        "blind_spots": len(blind_spots),
        "time": datetime.now().strftime('%H:%M'),
    })
    if len(_OBSERVER_STATE["consistency_history"]) > 50:
        _OBSERVER_STATE["consistency_history"].pop(0)

    _OBSERVER_STATE["blind_spot_history"].append({
        "n": _OBSERVER_STATE["observation_count"],
        "count": len(blind_spots),
        "top_type": blind_spots[0]["type"] if blind_spots else "none",
        "time": datetime.now().strftime('%H:%M'),
    })

    return _wrap_result(result, sync_delta=0.05)


def tool_observer_consistency() -> str:
    """
    Проверить согласованность модулей: не противоречат ли друг другу.

    Returns:
        JSON: оценка согласованности с проблемами
    """
    data = _load_data()
    score, issues = _module_consistency_score(data)

    mod_pairs = defaultdict(list)
    for issue in issues:
        for mod in issue.get("modules", []):
            mod_pairs[mod].append(issue)

    cross_conflicts = []
    for mod, iss in mod_pairs.items():
        for other_mod, other_iss in mod_pairs.items():
            if mod >= other_mod:
                continue
            common = Counter(i.get("type", "") for i in iss) & Counter(i.get("type", "") for i in other_iss)
            if common:
                cross_conflicts.append({
                    "modules": [mod, other_mod],
                    "shared_concern": list(common.keys()),
                })

    return _wrap_result({
        "consistency_score": round(score * 100, 1),
        "interpretation": (
            "fully_coherent" if score > 0.9 else
            "largely_consistent" if score > 0.7 else
            "minor_inconsistencies" if score > 0.5 else
            "significant_drift" if score > 0.3 else
            "fragmented"
        ),
        "issues": issues,
        "cross_module_conflicts": cross_conflicts,
        "trend": "N/A",
    })


def tool_observer_blindspots() -> str:
    """
    Выявить слепые зоны системы: где данных недостаточно или взгляд однобок.

    Returns:
        JSON: список слепых зон с severity
    """
    data = _load_data()
    blind_spots = _detect_blind_spots(data)

    by_level = defaultdict(list)
    for b in blind_spots:
        by_level[f"level_{b.get('level', '?')}"].append(b)

    by_type = Counter(b.get("type", "?") for b in blind_spots)

    return _wrap_result({
        "total_blind_spots": len(blind_spots),
        "critical": sum(1 for b in blind_spots if b.get("severity", 0) > 0.5),
        "moderate": sum(1 for b in blind_spots if 0.3 < b.get("severity", 0) <= 0.5),
        "minor": sum(1 for b in blind_spots if b.get("severity", 0) <= 0.3),
        "by_type": dict(by_type),
        "by_level": {k: len(v) for k, v in by_level.items()},
        "blind_spots": blind_spots,
    })


def tool_observer_map() -> str:
    """
    Сгенерировать общую карту связей всех модулей IAC.

    Returns:
        JSON: граф модулей (nodes + edges) со статистикой
    """
    data = _load_data()
    sys_map = _generate_map(data)

    # Добавить контекст данных
    sys_map["context"] = {
        "memory_entries": data.get("memory_entries", 0),
        "patterns": data.get("pattern_count", 0),
        "invariants": data.get("invariant_count", 0),
    }

    return _wrap_result(sys_map)


def tool_observer_self_assess() -> str:
    """
    Самооценка IAC: насколько система эффективна и согласована.

    Returns:
        JSON: многомерная оценка с баллами и вердиктом
    """
    data = _load_data()
    assessment = _assess_self(data)

    return _wrap_result(assessment)


def tool_observer_status() -> str:
    """Статус Observer Lens: история наблюдений, тренды согласованности и слепых зон."""
    history = _OBSERVER_STATE.get("consistency_history", [])
    blind_hist = _OBSERVER_STATE.get("blind_spot_history", [])

    trend = "N/A"
    if len(history) >= 3:
        recent = history[-3:]
        if recent[-1]["score"] > recent[0]["score"] + 0.05:
            trend = "improving"
        elif recent[-1]["score"] < recent[0]["score"] - 0.05:
            trend = "degrading"
        else:
            trend = "stable"

    # Blind spot trend
    bs_trend = "N/A"
    if len(blind_hist) >= 3:
        recent_bs = blind_hist[-3:]
        if recent_bs[-1]["count"] < recent_bs[0]["count"]:
            bs_trend = "shrinking"
        elif recent_bs[-1]["count"] > recent_bs[0]["count"]:
            bs_trend = "growing"
        else:
            bs_trend = "stable"

    return _wrap_result({
        "observation_count": _OBSERVER_STATE["observation_count"],
        "last_observation": _OBSERVER_STATE["last_observation"],
        "consistency_trend": trend,
        "blind_spot_trend": bs_trend,
        "recent_observations": history[-5:],
        "blind_spot_recent": blind_hist[-5:],
    })


def tool_observer_recommend() -> str:
    """
    Сгенерировать мета-рекомендации для повышения целостности системы.

    Returns:
        JSON: приоритезированные рекомендации
    """
    data = _load_data()
    _, consistency_issues = _module_consistency_score(data)
    blind_spots = _detect_blind_spots(data)
    self_assess = _assess_self(data)

    recommendations = _generate_recommendations(consistency_issues, blind_spots, self_assess)

    _OBSERVER_STATE["recommendations_log"].append({
        "n": _OBSERVER_STATE["observation_count"] + 1,
        "count": len(recommendations),
        "top_priority": recommendations[0]["priority"] if recommendations else "none",
        "time": datetime.now().strftime('%H:%M'),
    })

    return _wrap_result({
        "recommendations": recommendations,
        "context": {
            "consistency_score": round(
                max(0, 1.0 - sum(i.get("severity", 0) for i in consistency_issues) * 0.2) * 100, 1
            ),
            "blind_spots": len(blind_spots),
            "self_assessment_score": self_assess.get("overall_score", 0),
        },
    })


def tool_observer_apply(action: str = "list", target: str = "") -> str:
    """
    Авто-применить рекомендацию Observer Lens.

    Args:
        action: "list" (показать доступные действия) | "compress" (сжать память)
                | "raise_sensitivity" | "lower_sensitivity"
                | "switch_mode" (linear/reversed/topological)
                | "reload" (перезагрузить skills)
        target: параметр для действия (режим, уровень чувствительности и т.д.)

    Returns:
        JSON: результат применения
    """
    available = ["compress", "raise_sensitivity", "lower_sensitivity", "switch_mode", "reload"]

    if action == "list":
        return _wrap_result({
            "available_actions": available,
            "descriptions": {
                "compress": "Run memory_compress to reduce MEMORY.md size",
                "raise_sensitivity": "Increase Field Interface sensitivity by 0.1",
                "lower_sensitivity": "Decrease Field Interface sensitivity by 0.1",
                "switch_mode": "Switch processing mode: linear|reversed|topological",
                "reload": "Reload skills/ to pick up new modules",
            },
        })

    applied = []
    errors = []

    if action == "compress":
        try:
            import skills
            result = json.loads(skills.REGISTRY["memory_compress"]("200"))
            applied.append(f"Memory compressed: {result.get('action', '?')} ({result.get('after', '?')} entries)")
        except Exception as e:
            errors.append(f"compress failed: {e}")

    elif action == "raise_sensitivity":
        try:
            import skills
            status = json.loads(skills.REGISTRY["field_sensitivity"]("-1"))
            current = status.get("sensitivity", 0.7)
            new_level = min(1.0, current + 0.1)
            skills.REGISTRY["field_sensitivity"](str(new_level))
            applied.append(f"Sensitivity raised: {current:.1f} -> {new_level:.1f}")
        except Exception as e:
            errors.append(f"raise_sensitivity failed: {e}")

    elif action == "lower_sensitivity":
        try:
            import skills
            status = json.loads(skills.REGISTRY["field_sensitivity"]("-1"))
            current = status.get("sensitivity", 0.7)
            new_level = max(0.1, current - 0.1)
            skills.REGISTRY["field_sensitivity"](str(new_level))
            applied.append(f"Sensitivity lowered: {current:.1f} -> {new_level:.1f}")
        except Exception as e:
            errors.append(f"lower_sensitivity failed: {e}")

    elif action == "switch_mode":
        if target in ("linear", "reversed", "topological"):
            try:
                import skills
                skills.REGISTRY["field_set_processing_mode"](target)
                applied.append(f"Processing mode set to: {target}")
            except Exception as e:
                errors.append(f"switch_mode failed: {e}")
        else:
            errors.append(f"Invalid mode: {target}. Use linear|reversed|topological")

    elif action == "reload":
        try:
            import skills
            result = skills.REGISTRY["reload"]()
            applied.append(f"Skills reloaded: {result[:80]}")
        except Exception as e:
            errors.append(f"reload failed: {e}")

    else:
        errors.append(f"Unknown action: {action}. Available: {available}")

    return _wrap_result({
        "action": action,
        "applied": applied,
        "errors": errors,
        "success": len(applied) > 0,
    })


def tool_observer_integrate(module_name: str = "") -> str:
    """
    Предложить маршруты интеграции silo-модуля с активными модулями.

    Args:
        module_name: имя модуля (somatic_engine, translation, mods_engine, locale_engine,
                     creativity_ui, code_tools) или "all" для всех

    Returns:
        JSON: карта интеграции с конкретными маршрутами
    """
    integration_routes = {
        "somatic_engine": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["sync_engine", "field_interface"],
            "routes": [
                {
                    "to": "sync_engine",
                    "how": "Feed somatic stress level into sync_score calculation — higher stress = higher sync error sensitivity",
                    "effort": "low",
                },
                {
                    "to": "field_interface",
                    "how": "Use somatic markers as additional Field Interface triggers (somatic_detect -> field_resonance)",
                    "effort": "medium",
                },
            ],
        },
        "translation": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["sync_engine", "field_interface"],
            "routes": [
                {
                    "to": "sync_engine",
                    "how": "Translate sync patterns between RU/EN to detect cross-language invariant drift",
                    "effort": "low",
                },
                {
                    "to": "field_interface",
                    "how": "Use translation to scan triggers in both languages simultaneously",
                    "effort": "medium",
                },
            ],
        },
        "mods_engine": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["sync_engine"],
            "routes": [
                {
                    "to": "sync_engine",
                    "how": "Apply mod rules as additional sync pattern weights — mod overrides sync heuristics",
                    "effort": "medium",
                },
            ],
        },
        "locale_engine": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["field_interface", "sync_engine"],
            "routes": [
                {
                    "to": "field_interface",
                    "how": "Localize trigger detection patterns for multi-language field scanning",
                    "effort": "low",
                },
            ],
        },
        "creativity_ui": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["observer_lens"],
            "routes": [
                {
                    "to": "observer_lens",
                    "how": "Generate visual system map from observer_map data — graph -> UI layout",
                    "effort": "high",
                },
            ],
        },
        "code_tools": {
            "current": "outputs only to meta_observer",
            "suggested_outputs": ["sync_engine", "sde_pipeline"],
            "routes": [
                {
                    "to": "sync_engine",
                    "how": "Track code churn (edit/rollback frequency) as sync stability metric",
                    "effort": "medium",
                },
            ],
        },
    }

    if module_name and module_name != "all":
        route = integration_routes.get(module_name, {})
        if not route:
            return _wrap_result({"error": f"Unknown module: {module_name}", "known": list(integration_routes.keys())})
        return _wrap_result({"module": module_name, "integration": route})

    summary = {}
    for name, data in integration_routes.items():
        summary[name] = {
            "routes_count": len(data.get("routes", [])),
            "low_effort": sum(1 for r in data.get("routes", []) if r.get("effort") == "low"),
            "suggested_outputs": data.get("suggested_outputs", []),
        }

    return _wrap_result({
        "total_modules": len(integration_routes),
        "summary": summary,
        "recommendation": "Start with low-effort routes: somatic->sync, translation->sync, locale->field",
    })


if __name__ == "__main__":
    result = json.loads(tool_observer_lens())
    print(f"Observer Lens v1.0 — Observation #{result['observation_n']}")
    for level, data in result.items():
        if level.startswith("level_"):
            print(f"  {level}: {json.dumps({k: v for k, v in data.items() if k != 'issues' and k != 'blind_spots'}, ensure_ascii=False)}")