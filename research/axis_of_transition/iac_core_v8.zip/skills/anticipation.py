"""
anticipation.py — Anticipation Engine (Feedforward Model)
Predicts synchronization error BEFORE action. Enables proactive adaptation.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List
from urllib.request import Request, urlopen
from urllib.error import URLError

OLLAMA_GEN = "http://localhost:11434/api/generate"
MODEL = "qwen2.5-coder:7b"

MEMORY_FILE = Path("MEMORY.md")
SYNC_PATTERNS_FILE = Path("sync_patterns.json")


def _load_patterns() -> List[dict]:
    if SYNC_PATTERNS_FILE.exists():
        try:
            return json.loads(SYNC_PATTERNS_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return []


def _load_memory_entries(limit: int = 50) -> List[dict]:
    """Load recent memory entries with sync scores."""
    if not MEMORY_FILE.exists():
        return []
    content = MEMORY_FILE.read_text(encoding="utf-8")
    lines = content.strip().split("\n")
    entries = []
    for line in lines[-limit:]:
        m = re.match(r'- \[(.*?)\]\s*(?:\[(.*?)\])?\s*(.*?)\s*\{sync:\s*([\d.]+).*?\}', line)
        if m:
            entries.append({
                "timestamp": m.group(1),
                "tag": m.group(2) or "",
                "content": m.group(3).strip(),
                "sync_score": float(m.group(4))
            })
    return entries


def _ask_llm(prompt: str) -> str:
    """Query local LLM."""
    try:
        data = json.dumps({"model": MODEL, "prompt": prompt, "stream": False}).encode()
        req = Request(OLLAMA_GEN, data=data, headers={"Content-Type": "application/json"})
        resp = json.loads(urlopen(req, timeout=30).read().decode())
        return re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', resp.get("response", "")).strip()
    except:
        return ""


def _extract_json(text: str) -> Optional[dict]:
    """Extract JSON from LLM response."""
    if not text:
        return None
    # Try direct parse
    try:
        return json.loads(text)
    except:
        pass
    # Try to find JSON block
    m = re.search(r'\{.*\}', text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group())
        except:
            pass
    return None


def tool_predict_sync(action: str, context: str = "", horizon: int = 1) -> str:
    """
    Predict synchronization error for an action BEFORE execution.
    
    Args:
        action: The action to predict (e.g., "!search quantum thermodynamics")
        context: Current system context (optional)
        horizon: Prediction horizon in cycles (default 1)
    
    Returns:
        JSON with predicted_sync_score, confidence, reasoning, risk_factors
    """
    # Load relevant history
    memory = _load_memory_entries(30)
    patterns = _load_patterns()
    
    # Build context for prediction
    recent_actions = []
    for e in memory[-10:]:
        if e["tag"] in ("search", "code", "pattern", "reflection", "error"):
            recent_actions.append(f"{e['tag']}: {e['content'][:80]} (SE={e['sync_score']:.2f})")
    
    # Find similar past actions
    similar = []
    action_lower = action.lower()
    for e in memory:
        if any(word in e["content"].lower() for word in action_lower.split() if len(word) > 3):
            similar.append(f"{e['tag']}: {e['content'][:80]} → SE={e['sync_score']:.2f}")
    similar = similar[:5]
    
    # Cross-domain pattern hints
    pattern_hints = []
    for p in patterns[-10:]:
        if p.get("pattern", "").lower() in action_lower:
            pattern_hints.append(f"Pattern '{p['pattern'][:40]}': weight={p['weight']:.2f}, domain={p.get('domain','')}")
    
    prompt = f"""Predict synchronization error for this action.

ACTION: {action}
CONTEXT: {context or "current cycle"}
HORIZON: {horizon} cycle(s)

RECENT ACTION HISTORY (tag: content → sync_error):
{chr(10).join(recent_actions) if recent_actions else "(none)"}

SIMILAR PAST ACTIONS:
{chr(10).join(similar) if similar else "(none)"}

LEARNED PATTERNS:
{chr(10).join(pattern_hints) if pattern_hints else "(none)"}

SYNC ERROR SCALE: 0.0=synced, 0.1=slight_drift, 0.3=notable_desync, 0.5=significant_desync, 0.7=critical_desync, 1.0=total_desync

Consider:
- Action type (search=low risk, edit=high risk, write=medium)
- Historical SE for similar actions
- Pattern weights (positive = worse sync)
- Current system state (context)

Output ONLY JSON:
{{
  "predicted_sync_score": 0.XX,
  "confidence": 0.XX,
  "reasoning": "brief explanation",
  "risk_factors": ["factor1", "factor2"],
  "recommended_mitigation": "suggested precaution or alternative"
}}"""
    
    response = _ask_llm(prompt)
    result = _extract_json(response)
    
    if result is None:
        # Fallback heuristic
        action_type = action.split()[0].lstrip("!") if action else "unknown"
        base_se = {
            "search": 0.15, "fetch": 0.15, "read": 0.1,
            "write": 0.25, "edit": 0.4, "lint": 0.15, "syntax": 0.15,
            "plan": 0.1, "stats": 0.1, "mode": 0.05,
            "sync_score": 0.1, "sync_filter": 0.1, "sync_fact": 0.1,
            "sync_learn": 0.2, "sync_list_patterns": 0.1, "patterns": 0.1,
            "grep": 0.15, "list": 0.1, "reload": 0.1, "backup": 0.1,
            "rollback": 0.2, "auto_learn": 0.1, "memory_query": 0.15,
            "memory_stats": 0.1, "memory_compress": 0.2
        }.get(action_type, 0.3)
        
        result = {
            "predicted_sync_score": round(base_se, 2),
            "confidence": 0.5,
            "reasoning": f"Heuristic fallback for {action_type}",
            "risk_factors": ["llm_unavailable"],
            "recommended_mitigation": "Monitor actual sync, adjust if delta > 0.3"
        }
    
    # Store prediction for later validation
    prediction_record = {
        "timestamp": datetime.now().strftime('%d.%m %H:%M'),
        "action": action[:100],
        "context": context[:200] if context else "",
        "predicted_se": result["predicted_sync_score"],
        "confidence": result["confidence"],
        "horizon": horizon
    }
    
    # Save to a predictions log
    pred_file = Path("sync_predictions.jsonl")
    with open(pred_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(prediction_record, ensure_ascii=False) + "\n")
    
    return json.dumps(result, ensure_ascii=False)


def tool_validate_prediction(action: str, actual_se: float) -> str:
    """
    Validate a previous prediction against actual sync error.
    Updates prediction log with actual result.
    """
    pred_file = Path("sync_predictions.jsonl")
    if not pred_file.exists():
        return json.dumps({"error": "no predictions log"})
    
    lines = pred_file.read_text(encoding="utf-8").strip().split("\n")
    if not lines:
        return json.dumps({"error": "empty log"})
    
    # Find most recent prediction for this action
    last_pred = None
    for line in reversed(lines):
        try:
            p = json.loads(line)
            if p.get("action", "").startswith(action.split()[0]):
                last_pred = p
                break
        except:
            continue
    
    if not last_pred:
        return json.dumps({"error": "no matching prediction found"})
    
    predicted = last_pred["predicted_se"]
    delta = round(abs(predicted - actual_se), 3)
    direction = "overestimated" if predicted > actual_se else "underestimated" if predicted < actual_se else "accurate"
    
    # Calculate meta-sync (prediction accuracy)
    meta_sync = 1.0 - min(1.0, delta * 2)  # 0 delta = 1.0 meta-sync
    
    result = {
        "action": action[:60],
        "predicted_se": predicted,
        "actual_se": actual_se,
        "delta": delta,
        "direction": direction,
        "meta_sync_score": round(meta_sync, 3),
        "meta_sync_interpretation": "accurate" if meta_sync > 0.8 else "moderate" if meta_sync > 0.5 else "poor"
    }
    
    # Update the log entry with actual
    last_pred_file = Path("sync_predictions.jsonl")
    # We append validation instead of modifying
    val_record = {
        "timestamp": datetime.now().strftime('%d.%m %H:%M'),
        "type": "validation",
        "original_action": last_pred["action"],
        "predicted_se": predicted,
        "actual_se": actual_se,
        "meta_sync": meta_sync
    }
    with open(pred_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(val_record, ensure_ascii=False) + "\n")
    
    return json.dumps(result, ensure_ascii=False)


def tool_simulate_trajectory(actions: str, steps: int = 3) -> str:
    """
    Simulate multi-step sync trajectory for a sequence of actions.
    
    Args:
        actions: Pipe-separated actions (e.g., "!search x|!edit y|!lint z")
        steps: Number of steps to simulate (max 5)
    
    Returns:
        JSON with trajectory predictions
    """
    action_list = [a.strip() for a in actions.split("|")][:steps]
    
    trajectory = []
    cumulative_context = ""
    
    for i, action in enumerate(action_list):
        # Predict each step with accumulating context
        pred_json = tool_predict_sync(action, cumulative_context, horizon=1)
        pred = json.loads(pred_json)
        
        trajectory.append({
            "step": i + 1,
            "action": action[:60],
            "predicted_se": pred["predicted_sync_score"],
            "confidence": pred["confidence"],
            "risk_factors": pred.get("risk_factors", [])
        })
        
        # Update context with predicted outcome
        cumulative_context += f" Step {i+1}: {action} → pred_SE={pred['predicted_sync_score']:.2f}"
    
    # Overall trajectory metrics
    avg_se = sum(t["predicted_se"] for t in trajectory) / len(trajectory) if trajectory else 0
    max_se = max(t["predicted_se"] for t in trajectory) if trajectory else 0
    risk_steps = sum(1 for t in trajectory if t["predicted_se"] > 0.5)
    
    return json.dumps({
        "trajectory": trajectory,
        "summary": {
            "steps": len(trajectory),
            "avg_predicted_se": round(avg_se, 3),
            "max_predicted_se": round(max_se, 3),
            "high_risk_steps": risk_steps,
            "overall_risk": "high" if max_se > 0.7 or risk_steps > 1 else "medium" if max_se > 0.4 else "low"
        }
    }, ensure_ascii=False)


def tool_anticipation_status() -> str:
    """Show anticipation engine status and prediction accuracy."""
    pred_file = Path("sync_predictions.jsonl")
    if not pred_file.exists():
        return json.dumps({"status": "no_predictions_logged"})
    
    lines = pred_file.read_text(encoding="utf-8").strip().split("\n")
    predictions = []
    validations = []
    
    for line in lines:
        try:
            p = json.loads(line)
            if p.get("type") == "validation":
                validations.append(p)
            else:
                predictions.append(p)
        except:
            continue
    
    if not validations:
        return json.dumps({
            "total_predictions": len(predictions),
            "validated": 0,
            "meta_sync_avg": None,
            "status": "awaiting_validation"
        })
    
    meta_sync_scores = [v["meta_sync"] for v in validations]
    avg_meta_sync = sum(meta_sync_scores) / len(meta_sync_scores)
    
    # By action type
    by_action = {}
    for v in validations:
        atype = v["original_action"].split()[0].lstrip("!")
        if atype not in by_action:
            by_action[atype] = []
        by_action[atype].append(v["meta_sync"])
    
    action_accuracy = {a: round(sum(s)/len(s), 3) for a, s in by_action.items()}
    
    return json.dumps({
        "total_predictions": len(predictions),
        "validated": len(validations),
        "avg_meta_sync": round(avg_meta_sync, 3),
        "meta_sync_interpretation": "good" if avg_meta_sync > 0.7 else "moderate" if avg_meta_sync > 0.5 else "poor",
        "by_action_type": action_accuracy,
        "recent_validations": validations[-5:]
    }, ensure_ascii=False, indent=2)


def tool_suggest_action(current_se: float, context: str = "") -> str:
    """
    Suggest optimal next action based on predicted sync trajectories.
    Uses simulation to find lowest-risk high-value action.
    """
    # Candidate actions by current sync state
    candidates = {
        "low_se (<0.2)": ["!search <topic>", "!edit <file>", "!write <file>", "!patterns --invariants"],
        "medium_se (0.2-0.5)": ["!search <topic>", "!read <file>", "!plan", "!sync_status"],
        "high_se (0.5-0.7)": ["!plan", "!sync_status", "!memory_query", "!list skills/"],
        "critical_se (>0.7)": ["!plan", "!mode free", "!rollback <file>", "!stats"]
    }
    
    if current_se < 0.2:
        cat = "low_se (<0.2)"
    elif current_se < 0.5:
        cat = "medium_se (0.2-0.5)"
    elif current_se < 0.7:
        cat = "high_se (0.5-0.7)"
    else:
        cat = "critical_se (>0.7)"
    
    actions = candidates[cat]
    
    # Simulate each candidate
    best_action = None
    best_score = 1.0
    
    for action in actions[:3]:  # Limit simulations
        sim = json.loads(tool_simulate_trajectory(action, steps=2))
        score = sim["summary"]["avg_predicted_se"]
        if score < best_score:
            best_score = score
            best_action = action
    
    suggestion = best_action or actions[0]
    
    return json.dumps({
        "current_sync_category": cat,
        "current_se": current_se,
        "candidates": actions,
        "recommended": suggestion,
        "predicted_trajectory_se": round(best_score, 3),
        "reasoning": f"Selected from {cat} candidates via 2-step simulation"
    }, ensure_ascii=False)