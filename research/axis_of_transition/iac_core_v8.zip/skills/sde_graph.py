"""
sde_graph.py — Hypothesis Graph for Scientific Discovery Engine
Structures hypothesis space with logical relations.
"""

import json
import math
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Any, Optional
from collections import defaultdict, Counter

SDE_GRAPH_FILE = Path("sde_hypothesis_graph.json")


def _load_graph() -> Dict:
    if SDE_GRAPH_FILE.exists():
        try:
            return json.loads(SDE_GRAPH_FILE.read_text(encoding="utf-8"))
        except:
            pass
    return {"nodes": {}, "edges": []}


def _save_graph(graph: Dict):
    SDE_GRAPH_FILE.write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")


def _infer_relations(new_hyp: Dict, graph: Dict):
    """Automatically infer logical relations between hypotheses."""
    nid = new_hyp["id"]
    formal = new_hyp.get("formal", "")
    
    for existing_id, existing in graph["nodes"].items():
        if existing_id == nid:
            continue
        
        e_formal = existing.get("formal", "")
        
        # IMPLIES: check if formal of new contains structure that implies existing
        # Simple heuristic: if new has all variables of existing + more
        new_vars = set(re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]*\b', formal))
        old_vars = set(re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]*\b', e_formal))
        
        if old_vars.issubset(new_vars) and len(new_vars) > len(old_vars):
            graph["edges"].append({"from": nid, "relation": "GENERALIZES", "to": existing_id})
            graph["edges"].append({"from": existing_id, "relation": "SPECIALIZES", "to": nid})
        
        # CONTRADICTS: if they make opposite predictions
        # Check falsifiable predictions for conflicts
        new_preds = new_hyp.get("falsifiable_predictions", [])
        old_preds = existing.get("falsifiable_predictions", [])
        
        for np in new_preds:
            for op in old_preds:
                np_text = str(np.get("prediction", "")).lower()
                op_text = str(op.get("prediction", "")).lower()
                if any(neg in np_text for neg in ["not", "never", "false", "fail", "low"]) and \
                   any(pos in op_text for pos in ["high", "true", "success", "always"]):
                    if np_text.replace("not ", "").replace("low", "high") == op_text:
                        graph["edges"].append({"from": nid, "relation": "CONTRADICTS", "to": existing_id})
                        graph["edges"].append({"from": existing_id, "relation": "CONTRADICTS", "to": nid})
        
        # ANALOGOUS: same pattern type, different domain
        if new_hyp.get("pattern_type") == existing.get("pattern_type") and \
           new_hyp.get("domain") != existing.get("domain"):
            graph["edges"].append({"from": nid, "relation": "ANALOGOUS", "to": existing_id})
            graph["edges"].append({"from": existing_id, "relation": "ANALOGOUS", "to": nid})


def tool_sde_add_hypothesis(hypothesis_json: str) -> str:
    """Add hypothesis to graph with automatic relation inference."""
    hyp = json.loads(hypothesis_json)
    graph = _load_graph()
    
    if hyp["id"] in graph["nodes"]:
        # Update existing
        graph["nodes"][hyp["id"]].update(hyp)
        graph["nodes"][hyp["id"]]["updated_at"] = datetime.now().isoformat()
    else:
        graph["nodes"][hyp["id"]] = hyp
        hyp["created_at"] = datetime.now().isoformat()
        _infer_relations(hyp, graph)
    
    _save_graph(graph)
    
    return json.dumps({
        "added": hyp["id"],
        "total_nodes": len(graph["nodes"]),
        "total_edges": len(graph["edges"])
    }, ensure_ascii=False)


def tool_sde_graph_status() -> str:
    """Show graph statistics."""
    graph = _load_graph()
    
    relations = Counter(e["relation"] for e in graph["edges"])
    domains = Counter()
    pattern_types = Counter()
    
    for n in graph["nodes"].values():
        for d in n.get("domain", []):
            domains[d] += 1
        pattern_types[n.get("pattern_type", "unknown")] += 1
    
    # Find contradiction cliques
    contradiction_pairs = [(e["from"], e["to"]) for e in graph["edges"] if e["relation"] == "CONTRADICTS"]
    
    return json.dumps({
        "nodes": len(graph["nodes"]),
        "edges": len(graph["edges"]),
        "relations": dict(relations),
        "domains": dict(domains),
        "pattern_types": dict(pattern_types),
        "contradiction_pairs": len(contradiction_pairs),
        "contradiction_details": contradiction_pairs[:10]
    }, ensure_ascii=False, indent=2)


def tool_sde_find_maximal_invariants() -> str:
    """Find hypotheses with no generalizations (maximally general)."""
    graph = _load_graph()
    
    # Nodes that are not specialized by any other
    specialized = {e["to"] for e in graph["edges"] if e["relation"] == "SPECIALIZES"}
    maximal = [n for nid, n in graph["nodes"].items() if nid not in specialized]
    
    # Sort by cross-domain support and simplicity
    maximal.sort(key=lambda x: (-x.get("cross_domain_support", 1), x.get("complexity_estimate", 999)))
    
    return json.dumps({
        "maximal_invariants": len(maximal),
        "invariants": maximal[:10]
    }, ensure_ascii=False, indent=2)


def tool_sde_find_contradiction_cliques() -> str:
    """Find mutually contradictory hypothesis sets."""
    graph = _load_graph()
    
    # Build contradiction adjacency
    adj = defaultdict(set)
    for e in graph["edges"]:
        if e["relation"] == "CONTRADICTS":
            adj[e["from"]].add(e["to"])
            adj[e["to"]].add(e["from"])
    
    # Find maximal cliques (Bron–Kerbosch simplified)
    cliques = []
    nodes = list(adj.keys())
    
    def bron_kerbosch(r: Set, p: Set, x: Set):
        if not p and not x:
            if len(r) > 1:
                cliques.append(r)
            return
        for v in list(p):
            bron_kerbosch(r | {v}, p & adj[v], x & adj[v])
            p.remove(v)
            x.add(v)
    
    bron_kerbosch(set(), set(nodes), set())
    
    # Filter: only maximal cliques
    maximal_cliques = []
    for c in cliques:
        if not any(c < other for other in cliques):
            maximal_cliques.append(c)
    
    return json.dumps({
        "contradiction_cliques": len(maximal_cliques),
        "cliques": [{"hypotheses": list(c), "size": len(c)} for c in maximal_cliques[:10]]
    }, ensure_ascii=False, indent=2)


def tool_sde_find_analogy_chains() -> str:
    """Find chains of analogies across domains."""
    graph = _load_graph()
    
    # Build analogy graph
    adj = defaultdict(set)
    for e in graph["edges"]:
        if e["relation"] == "ANALOGOUS":
            adj[e["from"]].add(e["to"])
    
    # Find connected components
    visited = set()
    chains = []
    
    for node in graph["nodes"]:
        if node not in visited and node in adj:
            component = []
            stack = [node]
            while stack:
                n = stack.pop()
                if n not in visited:
                    visited.add(n)
                    component.append(n)
                    stack.extend(adj[n] - visited)
            if len(component) > 1:
                chains.append(component)
    
    # Annotate with domains
    chain_details = []
    for chain in chains:
        domains = set()
        for n in chain:
            domains.update(graph["nodes"][n].get("domain", []))
        chain_details.append({
            "hypotheses": chain,
            "length": len(chain),
            "domains": list(domains),
            "domain_count": len(domains)
        })
    
    return json.dumps({
        "analogy_chains": len(chains),
        "chains": chain_details
    }, ensure_ascii=False, indent=2)


def tool_sde_falsification_frontier(threshold: float = 0.5) -> str:
    """Find hypotheses with untested, precise, unique predictions."""
    graph = _load_graph()
    
    frontier = []
    for nid, hyp in graph["nodes"].items():
        if hyp.get("falsification_attempts", 0) >= 10:
            continue  # Already well-tested
        
        predictions = hyp.get("falsifiable_predictions", [])
        for pred in predictions:
            precision = pred.get("precision", 1.0)
            if precision <= threshold:
                frontier.append({
                    "hypothesis_id": nid,
                    "hypothesis": hyp.get("natural", ""),
                    "prediction": pred.get("prediction", ""),
                    "precision": precision,
                    "test_method": pred.get("test_method", ""),
                    "prior": hyp.get("prior_plausibility", 0.5),
                    "cross_domain": hyp.get("cross_domain_support", 1)
                })
    
    # Sort by: high prior, high precision (low number), high cross-domain
    frontier.sort(key=lambda x: (-x["prior"], x["precision"], -x["cross_domain"]))
    
    return json.dumps({
        "frontier_size": len(frontier),
        "frontier": frontier[:20]
    }, ensure_ascii=False, indent=2)


# ===== DIAGRAMMATIC MODE PROTOCOL (IAC-INV-023) =====

def tool_sde_diagrammatic_analyze(text: str) -> str:
    """
    Diagrammatic Mode: convert text to graph, apply IAC triad, find conflicts.
    
    Protocol:
    1. Text → Graph (nodes=entities, edges=relations)
    2. Apply IAC triad: Node A (subject 1), Node B (subject 2), Edge (observer/variable)
    3. Conflict = structural anomaly in graph
    4. Meta-rule = graph transformation
    
    Args:
        text: Input text describing relationships
    
    Returns:
        JSON: {graph, conflicts, meta_rules, consistency_score}
    """
    if not text or len(text) < 30:
        return json.dumps({"error": "insufficient_text"})

    # 1. Build graph from text
    tokens = re.findall(r'\b[a-zа-яё]{3,}\b', text.lower())
    stopwords = {
        'the', 'and', 'for', 'that', 'this', 'with', 'from', 'have', 'are',
        'это', 'что', 'как', 'для', 'или', 'так', 'уже', 'ещё', 'быть', 'есть',
        'was', 'were', 'been', 'has', 'had', 'not', 'but', 'all',
    }
    filtered = [t for t in tokens if t not in stopwords]
    freq = Counter(filtered).most_common(20)

    nodes = {}
    for i, (word, count) in enumerate(freq):
        nodes[word] = {
            "id": word,
            "label": word,
            "frequency": count,
            "index": i,
        }

    edges = []
    window = 5
    token_list = [t for t in filtered if t in nodes]
    for i in range(len(token_list)):
        for j in range(i + 1, min(i + window, len(token_list))):
            if token_list[i] != token_list[j]:
                edges.append({
                    "from": token_list[i],
                    "to": token_list[j],
                    "relation": "cooccurrence",
                    "weight": round(1.0 / (j - i), 3),
                })

    graph = {"nodes": nodes, "edges": edges}

    # 2. Find IAC triad conflicts
    conflicts = _find_triad_conflicts(graph)
    consistency = round(max(0.0, 1.0 - len(conflicts) * 0.1), 3)

    # 3. Generate meta-rules (graph transformations)
    meta_rules = _generate_graph_meta_rules(graph, conflicts)

    return json.dumps({
        "graph": {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "nodes": list(nodes.keys())[:15],
        },
        "triad_conflicts": len(conflicts),
        "conflicts": conflicts[:10],
        "meta_rules": meta_rules[:5],
        "consistency_score": consistency,
        "recommendation": (
            "apply_meta_rules" if conflicts else "graph_consistent"
        ),
    }, ensure_ascii=False, indent=2)


def _find_triad_conflicts(graph: Dict) -> List[Dict]:
    """Apply IAC triad: Node A, Node B, Path — find structural conflicts."""
    nodes = graph.get("nodes", {})
    edges = graph.get("edges", [])
    node_ids = list(nodes.keys())

    adj = defaultdict(set)
    for e in edges:
        adj[e["from"]].add(e["to"])
        adj[e["to"]].add(e["from"])

    conflicts = []

    # For each pair of nodes, check triad completeness
    for i, a in enumerate(node_ids):
        for j, b in enumerate(node_ids[i + 1:5], i + 1):  # Limit pairs for performance
            # Triad: A, B, and the edge/path between them
            direct = b in adj.get(a, set())
            # Check if there's a path through a common neighbor
            common_neighbors = adj.get(a, set()) & adj.get(b, set())

            if not direct and not common_neighbors:
                conflicts.append({
                    "type": "missing_path",
                    "subject_a": a,
                    "subject_b": b,
                    "triad_complete": False,
                    "issue": f"No path between '{a}' and '{b}' — structurally disconnected",
                })
            elif not direct and common_neighbors:
                conflicts.append({
                    "type": "indirect_only",
                    "subject_a": a,
                    "subject_b": b,
                    "triad_complete": True,
                    "via_nodes": list(common_neighbors),
                    "issue": f"'{a}' and '{b}' connected only through {list(common_neighbors)[:3]}",
                })

    return conflicts


def _generate_graph_meta_rules(graph: Dict, conflicts: List[Dict]) -> List[Dict]:
    """Generate meta-rules: graph transformations to resolve conflicts."""
    meta_rules = []

    for c in conflicts:
        if c["type"] == "missing_path":
            meta_rules.append({
                "action": "add_edge",
                "from": c["subject_a"],
                "to": c["subject_b"],
                "relation": "suggested",
                "reason": c["issue"],
                "expected_effect": "create_direct_path",
            })
        elif c["type"] == "indirect_only":
            meta_rules.append({
                "action": "strengthen_direct",
                "from": c["subject_a"],
                "to": c["subject_b"],
                "via": c.get("via_nodes", []),
                "reason": f"Add direct edge to bypass {'/'.join(c.get('via_nodes', [])[:2])}",
                "expected_effect": "reduce_path_length",
            })

    return meta_rules


def tool_sde_diagrammatic_apply(text: str) -> str:
    """
    Full Diagrammatic Mode cycle: analyze → generate meta-rules → suggest actions.
    Returns structured action plan.
    """
    result = json.loads(tool_sde_diagrammatic_analyze(text))
    meta_rules = result.get("meta_rules", [])
    conflicts = result.get("conflicts", [])

    actions = []
    for rule in meta_rules:
        actions.append({
            "step": len(actions) + 1,
            "action": rule["action"],
            "params": {k: v for k, v in rule.items() if k not in ("action", "reason")},
            "rationale": rule.get("reason", ""),
        })

    return json.dumps({
        "analysis": result,
        "action_plan": {
            "total_actions": len(actions),
            "actions": actions,
            "priority": (
                "high" if result.get("consistency_score", 1.0) < 0.5 else
                "medium" if result.get("consistency_score", 1.0) < 0.8 else
                "low"
            ),
        },
    }, ensure_ascii=False, indent=2)