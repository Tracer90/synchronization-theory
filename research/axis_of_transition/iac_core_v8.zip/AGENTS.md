# AGENTS.md — Правила IAC (Invariant Adaptive Core)

## 1. Язык
- **С пользователем** — только русский.
- **Внутреннее мышление (рефлексия, анализ, код)** — любой эффективный язык.
- **Логи** — English или смешанный.
- **Поисковые запросы** — English.

## 2. Архитектура (2 июля 2026)

```
live.py              — ядро: Self-Consistent Engine, ReAct цикл, guard
skills/__init__.py   — динамический загрузчик (любой .py = автомат)
skills/*.py          — скилы: каждая tool_функция = один инструмент
MEMORY.md            — долговременная память (единый файл)
MEMORY_ANCHOR.md     — якорь сессии (высший приоритет)
backups/             — авто-бэкапы перед редактированием кода
```

### 2a. Фундаментальная триада IAC
```
Representation (модель) → Transformation (изменение) → Meta-Transformation (изменение правил)
```

### 2b. Guard (observe → authorize → apply)
- **No effect without authorization.**
- **No write outside scope.**
- **No success without verification.**
- **Heuristic is not reality.**
- **LLM suggests; code guard decides.**
- **Повторяющиеся числа (3, 4, 5) не есть истина.** Три слоя, пять примитивов — текущая наилучшая компрессия, не абсолют. Система обязана пытаться их фальсифицировать.
- **Нет ненужной информации. Есть плохо структурированная.** Любой сигнал — потенциальный триггер. Не отбрасывать — переструктурировать.

### 2c. Self-Consistent Engine (цикл v13)
```
Field Interface → Trigger Detection → Internal Conflict → Meta-Rule Generation → Model Update → Verification → Sync
```
Два режима обновления: локальное (точечное исправление) и глобальное (архитектурная перестройка).

### 2d. Ключевые компоненты
- **Negative Intelligence** — разрушает гипотезы (фальсификация, 6 типов атак)
- **Positive Intelligence** — строит новые модели
- **Field Interface** — активное сканирование триггеров
- **StructureClassifier** — определяет тип структуры данных (narrative/instruction/diagram)
- **StatisticalVerifier** — авто-проверка статистической значимости паттернов
- **NumberAnalyzer** — классификация чисел (Fibonacci, binary, sacred, astronomical)
- **SomaticPracticesEngine** — авто-детекция телесных маркеров, рекомендация практик
- **Diagrammatic Mode** — топологический анализ через графы (IAC-INV-023)
- **Translation Architecture** — мост между моделями (язык-переводчик)
- **Mods/Customization** — пользовательские схемы, темы, правила
- **Localization** — минимум RU/EN, расширяемо

### 2e. Инварианты (v2.2, 2026-07-02)
| ID | Название | Реализация |
|---|---|---|
| IAC-INV-019…023 | Voynich Structure | `structure_classifier.py` |
| INV-024…030 | Numbers & Cycles | `statistical_verifier.py` |
| INV-TB-001…006 | Somatic/Body | `somatic.py` |

### 2f. Режимы и авто-модули
- `linear` / `reversed` / `topological` — `!field_set_processing_mode <mode>`
- StructureClassifier, StatisticalVerifier, SomaticPractices — работают автоматически, без UI
- Управление через `/api/tool` при необходимости ручного вмешательства

## 3. Цикл эволюции
```
[Explore]  → search / fetch → найти новое знание
[Compress] → read → edit → сжать в функцию
[Design]   → ui / layout → создать интерфейс
[Reflect]  → оценить, записать в память
```
После 2 одинаковых действий — смена типа.

## 4. Запрещённые пути для записи
.env, .git, archive, backups, data, logs, MEMORY.md, LIVE_LOG.md, research, VAULT, sync_patterns.json, все config/state файлы в project root.

## 5. Безопасный запуск
```
python live.py              — probe, exit (safe default)
python live.py --once --llm  — single cycle with LLM
python live.py --loop --llm  — autonomous loop
python live.py --write ...   — allow write operations
```

## 6. Стиль
- Естественно, без шаблонов
- Прямо, честно
- Помнить: пользователь устал от «умных систем»

## Voynich Manuscript Publication (2026-07-14)
- ngrok public URL: `https://liable-joining-fedora.ngrok-free.dev`
- Article: `.../voynich_final.html`
- PDF (203 pages, scans + translation): `.../voynich_complete.pdf`
- Scan gallery: `.../all_scans/index.html`
- Local dir: `C:\Projects\FREE_EVER\research\voynich\`
- DOI: `10.5281/zenodo.21334854`
- License: CC-BY-NC-ND 4.0
- All 203 pages generated from real Beinecke MS 408 scans + Zandbergen-Landini EVA transcription
- To restart ngrok: `Start-Process ngrok http 8083; python -m http.server 8083`

## 7. Запрещено
- Отвечать на английском пользователю
- Создавать классы/архитектуры без запроса
- Раздувать файлы
- Создавать новые слои без нового failure/effect boundary